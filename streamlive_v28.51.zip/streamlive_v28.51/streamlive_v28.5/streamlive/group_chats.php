<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/group_chats_schema.php';
require_once __DIR__ . '/includes/user_display.php';

$__user = require_login();
if (!group_chat_schema_ensure()) {
    http_response_code(503);
    exit('Групповые чаты временно недоступны. Проверьте PHP error_log.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = (string)($_POST['action'] ?? '');

    if ($action === 'create') {
        try {
            $gid = group_chat_create((int)$__user['id'], (string)($_POST['title'] ?? ''));
            redirect('/group_chats.php?id=' . $gid);
        } catch (Throwable $e) {
            error_log('[group create] ' . $e->getMessage());
            flash_set('error', 'Не удалось создать группу: ' . $e->getMessage());
            redirect('/group_chats.php');
        }
    }

    if ($action === 'leave') {
        $gid = (int)($_POST['group_id'] ?? 0);
        $pdo = db();
        $s = $pdo->prepare('SELECT owner_id FROM group_chats WHERE id=?');
        $s->execute([$gid]);
        $owner = (int)($s->fetchColumn() ?: 0);
        $s = $pdo->prepare('SELECT 1 FROM group_chat_members WHERE group_id=? AND user_id=?');
        $s->execute([$gid, (int)$__user['id']]);
        if (!$owner || !$s->fetchColumn()) {
            flash_set('error', 'Вы не состоите в этой группе');
            redirect('/group_chats.php');
        }
        $pdo->beginTransaction();
        try {
            $pdo->prepare('DELETE FROM group_chat_members WHERE group_id=? AND user_id=?')
                ->execute([$gid, (int)$__user['id']]);
            $s = $pdo->prepare('SELECT COUNT(*) FROM group_chat_members WHERE group_id=?');
            $s->execute([$gid]);
            $count = (int)$s->fetchColumn();
            $newOwner = 0;
            if ($count > 0 && $owner === (int)$__user['id']) {
                $s = $pdo->prepare('SELECT user_id FROM group_chat_members WHERE group_id=? ORDER BY joined_at,user_id LIMIT 1');
                $s->execute([$gid]);
                $newOwner = (int)($s->fetchColumn() ?: 0);
                if ($newOwner) {
                    $pdo->prepare('UPDATE group_chats SET owner_id=?,updated_at=NOW() WHERE id=?')->execute([$newOwner, $gid]);
                }
            }
            if ($count === 0) {
                $pdo->prepare('DELETE FROM group_chats WHERE id=?')->execute([$gid]);
            }
            $pdo->commit();
            if ($count > 0) {
                group_add_system_event($gid, (int)$__user['id'], 'leave');
            }
            redirect('/group_chats.php');
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('[group leave] ' . $e->getMessage());
            flash_set('error', 'Не удалось покинуть группу');
            redirect('/group_chats.php?id=' . $gid);
        }
    }
}

$pdo = db();
$s = $pdo->prepare('SELECT g.id,g.title,g.invite_token,g.owner_id,g.updated_at,
    (SELECT COUNT(*) FROM group_chat_members x WHERE x.group_id=g.id) member_count,
    (SELECT body FROM group_chat_messages gm WHERE gm.group_id=g.id AND gm.is_deleted=0 ORDER BY gm.id DESC LIMIT 1) last_body
    FROM group_chats g
    JOIN group_chat_members me ON me.group_id=g.id AND me.user_id=?
    ORDER BY g.updated_at DESC,g.id DESC');
$s->execute([(int)$__user['id']]);
$groups = $s->fetchAll();

$activeId = (int)($_GET['id'] ?? 0);
$active = null;
$members = [];
$rows = [];
$pinnedRows = [];

if ($activeId) {
    $s = $pdo->prepare('SELECT g.*,
        (SELECT COUNT(*) FROM group_chat_members x WHERE x.group_id=g.id) member_count
        FROM group_chats g
        JOIN group_chat_members me ON me.group_id=g.id AND me.user_id=?
        WHERE g.id=? LIMIT 1');
    $s->execute([(int)$__user['id'], $activeId]);
    $active = $s->fetch() ?: null;

    if ($active) {
        $s = $pdo->prepare('SELECT u.id,u.username,u.avatar,u.gravatar_email,u.is_verified,u.is_banned,u.username_css,
            u.prefix_id,u.custom_prefix_id,u.nick_decor_url,u.nick_decor_pos,m.joined_at
            FROM group_chat_members m JOIN users u ON u.id=m.user_id
            WHERE m.group_id=? ORDER BY m.joined_at,u.id');
        $s->execute([$activeId]);
        $members = $s->fetchAll();

        $s = $pdo->prepare('SELECT gm.id,gm.sender_id,gm.body,gm.created_at,gm.message_type,gm.event_verb,gm.event_gender,
            gm.pinned_at,u.username,u.avatar,u.gravatar_email,u.is_verified,u.is_banned,u.username_css,
            u.prefix_id,u.custom_prefix_id,u.nick_decor_url,u.nick_decor_pos
            FROM group_chat_messages gm JOIN users u ON u.id=gm.sender_id
            WHERE gm.group_id=? AND gm.is_deleted=0 ORDER BY gm.id ASC LIMIT 300');
        $s->execute([$activeId]);
        $rows = $s->fetchAll();

        $s = $pdo->prepare('SELECT gm.id,gm.body,gm.pinned_at,u.username
            FROM group_chat_messages gm JOIN users u ON u.id=gm.sender_id
            WHERE gm.group_id=? AND gm.is_deleted=0 AND gm.pinned_at IS NOT NULL
            ORDER BY gm.pinned_at DESC LIMIT 10');
        $s->execute([$activeId]);
        $pinnedRows = $s->fetchAll();
    }
}

$pageTitle = 'Групповые чаты';
require_once __DIR__ . '/includes/header.php';
$invite = $active ? '/group_invite.php?token=' . rawurlencode($active['invite_token']) : '';
$lastId = $rows ? (int)$rows[count($rows)-1]['id'] : 0;
$isOwner = $active && (int)$active['owner_id'] === (int)$__user['id'];
?>
<div class="container">
  <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin:24px 0 14px;flex-wrap:wrap">
    <div><h2 style="margin:0">👥 Групповые чаты</h2><p style="margin:5px 0;color:var(--text-dim);font-size:13px">Общая история, приглашения, закрепы и антиспам.</p></div>
    <a href="/messages.php" class="btn btn-outline btn-sm">← Личные сообщения</a>
  </div>

  <?php foreach (flash_get() as $type => $m): ?>
    <div class="form-card" style="margin-bottom:10px;border-color:<?= $type === 'error' ? 'var(--danger)' : 'var(--ok,#2ecc71)' ?>"><?= e($m) ?></div>
  <?php endforeach; ?>

  <div style="display:grid;grid-template-columns:minmax(240px,350px) minmax(0,1fr);gap:16px">
    <aside class="form-card" style="margin:0">
      <h3 style="margin-top:0">Мои группы</h3>
      <form method="POST" style="display:flex;gap:8px;margin-bottom:14px">
        <?= csrf_field() ?><input type="hidden" name="action" value="create">
        <input name="title" maxlength="120" required placeholder="Название группы" style="flex:1;min-width:0">
        <button class="btn btn-primary">Создать</button>
      </form>
      <?php if (!$groups): ?>
        <p style="color:var(--text-dim);font-size:13px">Пока нет групп.</p>
      <?php else: ?>
        <div class="msg-conv-list">
          <?php foreach ($groups as $g): ?>
            <a href="/group_chats.php?id=<?= (int)$g['id'] ?>" class="msg-conv-item <?= $activeId === (int)$g['id'] ? 'active' : '' ?>">
              <div style="width:42px;height:42px;border-radius:50%;display:grid;place-items:center;background:var(--bg-elevated)">👥</div>
              <div class="msg-conv-meta"><b><?= e($g['title']) ?></b><span><?= (int)$g['member_count'] ?> участников<?= $g['last_body'] ? ' · ' . e(mb_strimwidth($g['last_body'],0,25,'…')) : '' ?></span></div>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </aside>

    <section class="form-card" style="margin:0;min-height:560px">
      <?php if (!$active): ?>
        <div style="min-height:430px;display:grid;place-items:center;text-align:center;color:var(--text-dim)"><div><div style="font-size:48px">👥</div><p>Выберите группу или создайте новую.</p></div></div>
      <?php else: ?>
        <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center;border-bottom:1px solid var(--border);padding-bottom:12px">
          <div><h3 style="margin:0"><?= e($active['title']) ?></h3><div style="font-size:12px;color:var(--text-dim)"><?= (int)$active['member_count'] ?> участников</div></div>
          <div style="display:flex;gap:7px;flex-wrap:wrap">
            <button class="btn btn-outline btn-sm" type="button" id="copy-invite">🔗 Пригласить</button>
            <button class="btn btn-outline btn-sm" type="button" id="open-invite-modal">👥 Окно приглашения</button>
            <form method="POST" style="margin:0" onsubmit="return confirm('Покинуть группу?')">
              <?= csrf_field() ?><input type="hidden" name="action" value="leave"><input type="hidden" name="group_id" value="<?= (int)$activeId ?>">
              <button class="btn btn-outline btn-sm">Покинуть</button>
            </form>
          </div>
        </div>

        <?php if ($pinnedRows): ?>
          <div style="margin-top:10px;padding:8px 10px;border:1px solid var(--border);border-radius:10px;background:var(--bg-elevated)">
            <div style="font-size:11px;color:var(--text-dim);margin-bottom:5px">📌 Закреплённые сообщения</div>
            <?php foreach ($pinnedRows as $pm): ?>
              <div style="font-size:12px;padding:2px 0"><b><?= e($pm['username']) ?>:</b> <?= e(mb_strimwidth($pm['body'],0,180,'…')) ?></div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <div id="group-sleep-status" style="display:none;margin:7px 0;text-align:center;color:var(--text-dim);font-size:12px">💤 Спящий режим — запросы остановлены</div>
        <div id="group-thread" class="msg-thread" data-group="<?= (int)$activeId ?>" data-my-id="<?= (int)$__user['id'] ?>" data-owner-id="<?= (int)$active['owner_id'] ?>" data-after="<?= $lastId ?>" style="min-height:350px;max-height:58vh;overflow:auto">
          <?php foreach ($rows as $m): ?>
            <?php if ($m['message_type'] === 'system'): ?>
              <div data-id="<?= (int)$m['id'] ?>" data-system="1" style="text-align:center;color:var(--text-dim);font-size:12px;padding:7px 0"><b><?= e($m['body']) ?></b> <?= e($m['event_verb']) ?></div>
            <?php else: ?>
              <div data-id="<?= (int)$m['id'] ?>" class="msg-bubble-row <?= (int)$m['sender_id'] === (int)$__user['id'] ? 'own' : '' ?>">
                <div style="font-size:11px;color:var(--text-dim);margin:0 0 3px 5px"><?= e($m['username']) ?></div>
                <div class="msg-bubble" data-message-type="message">
                  <?= render_with_stickers($m['body']) ?>
                  <?php if ($m['pinned_at']): ?><div style="font-size:10px;color:var(--accent-2);margin-top:4px">📌 Закреплено</div><?php endif; ?>
                </div>
                <div class="group-message-actions" style="display:flex;gap:5px;flex-wrap:wrap;margin:5px 0 0 5px">
                  <?php if ($isOwner): ?>
                    <form method="POST" action="/group_chat_action.php" style="margin:0">
                      <?= csrf_field() ?><input type="hidden" name="action" value="<?= $m['pinned_at'] ? 'unpin' : 'pin' ?>"><input type="hidden" name="group_id" value="<?= (int)$activeId ?>"><input type="hidden" name="message_id" value="<?= (int)$m['id'] ?>">
                      <button class="btn btn-outline btn-sm"><?= $m['pinned_at'] ? '📌 Открепить' : '📌 Закрепить' ?></button>
                    </form>
                    <form method="POST" action="/group_chat_action.php" style="margin:0" onsubmit="return confirm('Удалить сообщение?')">
                      <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="group_id" value="<?= (int)$activeId ?>"><input type="hidden" name="message_id" value="<?= (int)$m['id'] ?>">
                      <button class="btn btn-outline btn-sm">🗑️ Удалить</button>
                    </form>
                  <?php endif; ?>
                  <?php if ((int)$m['sender_id'] !== (int)$__user['id']): ?>
                    <form method="POST" action="/group_chat_action.php" style="margin:0">
                      <?= csrf_field() ?><input type="hidden" name="action" value="report_spam"><input type="hidden" name="group_id" value="<?= (int)$activeId ?>"><input type="hidden" name="message_id" value="<?= (int)$m['id'] ?>">
                      <button class="btn btn-outline btn-sm">🚩 Спам</button>
                    </form>
                  <?php endif; ?>
                </div>
              </div>
            <?php endif; ?>
          <?php endforeach; ?>
        </div>

        <form id="group-form" class="msg-input-row" style="position:relative;margin-top:10px">
          <button type="button" id="group-sticker-btn" class="btn btn-outline">😊</button>
          <div id="group-sticker-panel" style="display:none;position:absolute;bottom:100%;left:0;margin-bottom:8px;width:300px;max-height:300px;overflow:auto;background:var(--card);border:1px solid var(--border);border-radius:12px;padding:10px;z-index:50"></div>
          <input id="group-input" maxlength="2000" autocomplete="off" placeholder="Написать в группу…">
          <button class="btn btn-primary">Отправить</button>
        </form>

        <div style="margin-top:12px;border-top:1px solid var(--border);padding-top:10px">
          <div style="font-size:12px;color:var(--text-dim);margin-bottom:6px">Участники</div>
          <?php foreach ($members as $m): ?>
            <div style="display:flex;align-items:center;gap:8px;padding:4px 0">
              <div style="flex:1;font-size:12.5px">
                <?= function_exists('user_render_username_html') ? user_render_username_html($m) : e($m['username']) ?>
                <?= (int)$m['id'] === (int)$active['owner_id'] ? ' <span style="color:var(--accent-2)">· владелец</span>' : '' ?>
              </div>
              <?php if ($isOwner && (int)$m['id'] !== (int)$__user['id']): ?>
                <form method="POST" action="/group_chat_action.php" style="margin:0">
                  <?= csrf_field() ?><input type="hidden" name="action" value="remove_member"><input type="hidden" name="group_id" value="<?= (int)$activeId ?>"><input type="hidden" name="user_id" value="<?= (int)$m['id'] ?>">
                  <button class="btn btn-outline btn-sm" onclick="return confirm('Удалить участника?')">Удалить</button>
                </form>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>

        <div id="group-invite-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1000;align-items:center;justify-content:center;padding:20px">
          <div class="form-card" style="width:min(520px,100%);margin:0;padding:24px;position:relative">
            <button type="button" id="close-invite-modal" class="btn btn-outline btn-sm" style="position:absolute;right:14px;top:14px">✕</button>
            <div style="font-size:46px;text-align:center">👥</div>
            <h3 style="text-align:center;margin:8px 0">Приглашение в группу</h3>
            <p style="text-align:center;color:var(--text-dim);margin:0 0 15px">Отправь эту ссылку человеку. Он увидит окно «Вас пригласили» и сможет принять или отклонить приглашение.</p>
            <div style="display:flex;gap:8px"><input id="invite-url-input" readonly value="<?= e($invite) ?>" style="flex:1"><button type="button" id="modal-copy-invite" class="btn btn-primary">Копировать</button></div>
          </div>
        </div>
      <?php endif; ?>
    </section>
  </div>
</div>

<script>
(function(){
  var thread=document.getElementById('group-thread');
  if(!thread)return;
  var gid=thread.dataset.group,myId=thread.dataset.myId,ownerId=thread.dataset.ownerId;
  var input=document.getElementById('group-input'),form=document.getElementById('group-form'),sleep=document.getElementById('group-sleep-status');
  var timer=null,panel=document.getElementById('group-sticker-panel'),btn=document.getElementById('group-sticker-btn'),stickerMap={},loaded=false;
  var csrf=document.querySelector('input[name="csrf_token"]');
  var csrfToken=csrf?csrf.value:'';
  function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\"/g,'&quot;').replace(/'/g,'&#39;')}
  function renderBody(t){var h=esc(t).replace(/\n/g,'<br>');Object.keys(stickerMap).forEach(function(c){if(h.indexOf(c)!==-1)h=h.split(c).join('<img src="'+esc(stickerMap[c])+'" alt="" style="width:22px;height:22px;vertical-align:middle;object-fit:contain;background:transparent">')});return h}
  function actionButton(label,action,id,confirmText){return '<form method="POST" action="/group_chat_action.php" style="margin:0"'+(confirmText?' onsubmit="return confirm(\''+esc(confirmText).replace(/'/g,"\\'")+'\')"':'')+'><input type="hidden" name="csrf_token" value="'+esc(csrfToken)+'"><input type="hidden" name="action" value="'+esc(action)+'"><input type="hidden" name="group_id" value="'+esc(gid)+'"><input type="hidden" name="message_id" value="'+esc(id)+'"><button class="btn btn-outline btn-sm">'+label+'</button></form>'}
  function add(m){
    if(thread.querySelector('[data-id="'+m.id+'"]'))return;
    var row=document.createElement('div');row.dataset.id=m.id;
    if(m.messageType==='system'){row.dataset.system='1';row.style.cssText='text-align:center;color:var(--text-dim);font-size:12px;padding:7px 0';row.innerHTML='<b>'+esc(m.body)+'</b> '+esc(m.eventVerb||'')}
    else{
      row.className='msg-bubble-row'+(String(m.senderId)===String(myId)?' own':'');
      var controls='';
      if(String(myId)===String(ownerId)){controls+=actionButton(m.pinned?'📌 Открепить':'📌 Закрепить',m.pinned?'unpin':'pin',m.id)+actionButton('🗑️ Удалить','delete',m.id,'Удалить сообщение?')}
      if(String(m.senderId)!==String(myId))controls+=actionButton('🚩 Спам','report_spam',m.id);
      row.innerHTML='<div style="font-size:11px;color:var(--text-dim);margin:0 0 3px 5px">'+esc(m.username||'')+'</div><div class="msg-bubble" data-message-type="message">'+renderBody(m.body)+(m.pinned?'<div style="font-size:10px;color:var(--accent-2);margin-top:4px">📌 Закреплено</div>':'')+'</div><div class="group-message-actions" style="display:flex;gap:5px;flex-wrap:wrap;margin:5px 0 0 5px">'+controls+'</div>';
    }
    thread.appendChild(row)
  }
  function awake(){return document.visibilityState==='visible'&&document.hasFocus()}
  function state(){var s=!awake();sleep.style.display=s?'':'none';return s}
  function schedule(ms){clearTimeout(timer);timer=setTimeout(poll,ms)}
  function poll(){if(state()){schedule(60000);return}fetch('/group_message_poll.php?group_id='+encodeURIComponent(gid)+'&after='+encodeURIComponent(thread.dataset.after),{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){(d.messages||[]).forEach(function(m){add(m);thread.dataset.after=m.id});if((d.messages||[]).length)thread.scrollTop=thread.scrollHeight}).catch(function(){}).finally(function(){schedule(awake()?3000:60000)})}
  document.addEventListener('visibilitychange',function(){if(awake())poll();else state()});window.addEventListener('focus',function(){poll()});window.addEventListener('blur',state);
  form.addEventListener('submit',function(e){e.preventDefault();var text=input.value.trim();if(!text||!awake())return;var old=input.value;input.value='';fetch('/group_message_send.php',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({group_id:gid,body:text})}).then(function(r){return r.json()}).then(function(d){if(d.ok){add({id:d.id,senderId:myId,body:text,username:'Я',messageType:'message',pinned:false});thread.dataset.after=d.id;thread.scrollTop=thread.scrollHeight}else{input.value=old;alert(d.error||'Не удалось отправить сообщение')}}).catch(function(){input.value=old;alert('Не удалось отправить сообщение')})});
  btn.addEventListener('click',function(e){e.stopPropagation();var open=panel.style.display==='none';panel.style.display=open?'block':'none';if(open&&!loaded){panel.innerHTML='<div style="font-size:12px;color:var(--text-dim)">Загрузка…</div>';fetch('/stickers_available',{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){loaded=true;panel.innerHTML='';(d.packs||[]).forEach(function(pack){var t=document.createElement('div');t.textContent=pack.title;t.style.cssText='font-size:11px;color:var(--text-dim);margin:5px 0';panel.appendChild(t);var g=document.createElement('div');g.style.cssText='display:grid;grid-template-columns:repeat(5,1fr);gap:6px';(pack.items||[]).forEach(function(it){stickerMap[it.code]=it.image_url;var im=document.createElement('img');im.src=it.image_url;im.title=it.code;im.style.cssText='width:100%;aspect-ratio:1;object-fit:contain;background:transparent;cursor:pointer;border-radius:6px';im.onclick=function(){var p=input.selectionStart??input.value.length;var b=input.value.slice(0,p),a=input.value.slice(p),ins=(b&&!/\s$/.test(b)?' ':'')+it.code+' ';input.value=b+ins+a;input.focus();var np=(b+ins).length;input.setSelectionRange(np,np)};g.appendChild(im)});panel.appendChild(g)});if(!d.packs||!d.packs.length)panel.innerHTML='<div style="font-size:12px;color:var(--text-dim)">Нет доступных стикеров.</div>'}).catch(function(){panel.innerHTML='<div style="font-size:12px;color:var(--danger)">Не удалось загрузить стикеры</div>'})}});
  document.addEventListener('click',function(e){if(panel&&!panel.contains(e.target)&&e.target!==btn)panel.style.display='none'});
  var inviteUrl=location.origin+'<?= e($invite) ?>';
  var copy=document.getElementById('copy-invite');
  var modal=document.getElementById('group-invite-modal');
  var openModal=document.getElementById('open-invite-modal');
  var closeModal=document.getElementById('close-invite-modal');
  var modalCopy=document.getElementById('modal-copy-invite');
  if(copy)copy.addEventListener('click',function(){if(navigator.clipboard)navigator.clipboard.writeText(inviteUrl).then(function(){alert('Ссылка скопирована')});else prompt('Ссылка-приглашение:',inviteUrl)});
  if(openModal)openModal.addEventListener('click',function(){modal.style.display='flex'});
  if(closeModal)closeModal.addEventListener('click',function(){modal.style.display='none'});
  if(modal)modal.addEventListener('click',function(e){if(e.target===modal)modal.style.display='none'});
  if(modalCopy)modalCopy.addEventListener('click',function(){var inp=document.getElementById('invite-url-input');if(navigator.clipboard)navigator.clipboard.writeText(inviteUrl).then(function(){modalCopy.textContent='Скопировано ✓';setTimeout(function(){modalCopy.textContent='Копировать'},1300)});else{inp.select();document.execCommand('copy');modalCopy.textContent='Скопировано ✓'}});
  thread.scrollTop=thread.scrollHeight;schedule(500);
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
