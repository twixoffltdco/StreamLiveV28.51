<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: public, max-age=30');
require_once dirname(__DIR__) . '/includes/functions.php';
$videos = [];
$channels = [];
try {
  $videos = db()->query(
    "SELECT id, slug, title, thumbnail_url FROM videos
     WHERE (status='published' OR status='public' OR status IS NULL OR status='approved')
     ORDER BY id DESC LIMIT 40"
  )->fetchAll() ?: [];
} catch (Throwable $e) {
  try {
    $videos = db()->query('SELECT id, slug, title FROM videos ORDER BY id DESC LIMIT 40')->fetchAll() ?: [];
  } catch (Throwable $e2) {}
}
try {
  $channels = db()->query(
    "SELECT id, slug, title FROM channels WHERE (status='approved' OR status='public' OR status IS NULL) ORDER BY id DESC LIMIT 24"
  )->fetchAll() ?: [];
} catch (Throwable $e) {
  try {
    $channels = db()->query('SELECT id, slug, title FROM channels ORDER BY id DESC LIMIT 24')->fetchAll() ?: [];
  } catch (Throwable $e2) {}
}
echo json_encode(['ok' => true, 'videos' => $videos, 'channels' => $channels], JSON_UNESCAPED_UNICODE);
