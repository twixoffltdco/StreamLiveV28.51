<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
require_once dirname(__DIR__) . '/includes/functions.php';
if (is_file(dirname(__DIR__) . '/includes/auth.php')) require_once dirname(__DIR__) . '/includes/auth.php';
// Локальные монеты в расширении; на сервере только фиксируем активность
$u = function_exists('current_user') ? current_user() : null;
echo json_encode(['ok' => true, 'user' => $u ? (int)$u['id'] : null], JSON_UNESCAPED_UNICODE);
