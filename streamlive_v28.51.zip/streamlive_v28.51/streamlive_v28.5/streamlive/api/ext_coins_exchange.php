<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Origin: ' . (isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '*'));
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';
$user = current_user();
if (!$user) {
  echo json_encode(['ok' => false, 'error' => 'Войдите на сайте']);
  exit;
}
$code = 'SL-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
try {
  db()->exec("CREATE TABLE IF NOT EXISTS app_coin_exchanges (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    code VARCHAR(32) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  db()->prepare('INSERT INTO app_coin_exchanges (user_id, code) VALUES (?,?)')->execute([(int)$user['id'], $code]);
  try {
    db()->prepare('INSERT INTO promocodes (code, days, max_uses, uses, is_active) VALUES (?,?,1,0,1)')->execute([$code, 3]);
  } catch (Throwable $e) {}
} catch (Throwable $e) {
  echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
  exit;
}
echo json_encode(['ok' => true, 'code' => $code, 'spent' => 100], JSON_UNESCAPED_UNICODE);
