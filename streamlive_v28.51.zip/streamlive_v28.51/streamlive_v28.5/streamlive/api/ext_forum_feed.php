<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
require_once dirname(__DIR__) . '/includes/functions.php';
$threads = [];
try {
  $threads = db()->query(
    "SELECT t.id, t.title, u.username FROM forum_threads t
     LEFT JOIN users u ON u.id = t.user_id
     WHERE (t.is_deleted=0 OR t.is_deleted IS NULL)
       AND (t.mod_status='approved' OR t.mod_status IS NULL OR t.mod_status='')
     ORDER BY t.id DESC LIMIT 30"
  )->fetchAll() ?: [];
} catch (Throwable $e) {}
echo json_encode(['ok' => true, 'threads' => $threads], JSON_UNESCAPED_UNICODE);
