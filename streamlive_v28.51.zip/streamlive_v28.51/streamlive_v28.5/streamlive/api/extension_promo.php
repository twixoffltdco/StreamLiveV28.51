<?php
/**
 * Обмен монет расширения на промокод.
 * - Если код ещё НЕ активирован (used=0) → возвращаем тот же.
 * - Если уже активирован (used=1) → выдаём НОВЫЙ (после снова накопить 100 монет на клиенте).
 * Один активный неиспользованный код на аккаунт; история использованных сохраняется.
 */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  exit;
}

require_once dirname(__DIR__) . '/includes/functions.php';

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$username = trim((string)($input['username'] ?? ''));
if ($username === '' || !preg_match('/^[\w.\-]{2,32}$/u', $username)) {
  echo json_encode(['ok' => false, 'error' => 'Укажите корректный username']);
  exit;
}

try {
  db()->exec(
    "CREATE TABLE IF NOT EXISTS extension_promos (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      user_id INT UNSIGNED NOT NULL,
      username VARCHAR(64) NOT NULL,
      code VARCHAR(32) NOT NULL,
      used TINYINT(1) NOT NULL DEFAULT 0,
      used_at DATETIME NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_code (code),
      KEY idx_user_used (user_id, used)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
  );
} catch (Throwable $e) {
}
foreach ([
  'ALTER TABLE extension_promos ADD COLUMN used_at DATETIME NULL',
  'ALTER TABLE extension_promos DROP INDEX uq_user',
] as $sql) {
  try {
    db()->exec($sql);
  } catch (Throwable $e) {
  }
}

try {
  $st = db()->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
  $st->execute([$username]);
  $uid = (int)$st->fetchColumn();
  if ($uid <= 0) {
    echo json_encode(['ok' => false, 'error' => 'Пользователь не найден. Сначала зарегистрируйтесь на сайте.']);
    exit;
  }

  // 1) Есть неактивированный код — отдаём его
  $st = db()->prepare(
    'SELECT id, code FROM extension_promos WHERE user_id = ? AND used = 0 ORDER BY id DESC LIMIT 1'
  );
  $st->execute([$uid]);
  $open = $st->fetch();
  if ($open) {
    echo json_encode([
      'ok' => true,
      'code' => $open['code'],
      'note' => 'unused',
      'message' => 'Код ещё не активирован — используйте этот',
    ]);
    exit;
  }

  // 2) Все старые активированы (или не было) — новый код
  $code = 'SL' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
  // на всякий уникальность
  for ($i = 0; $i < 5; $i++) {
    try {
      db()->prepare('INSERT INTO extension_promos (user_id, username, code, used) VALUES (?,?,?,0)')
        ->execute([$uid, $username, $code]);
      echo json_encode([
        'ok' => true,
        'code' => $code,
        'note' => 'new',
        'message' => 'Новый промокод (предыдущий уже был активирован)',
      ]);
      exit;
    } catch (Throwable $e) {
      $code = 'SL' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
    }
  }
  echo json_encode(['ok' => false, 'error' => 'Не удалось выдать код, попробуйте позже']);
} catch (Throwable $e) {
  echo json_encode(['ok' => false, 'error' => 'Ошибка сервера. Попробуйте позже.']);
}
