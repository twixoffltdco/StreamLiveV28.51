<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/contacts.php';
$u=current_user();
if(!$u){http_response_code(401);echo json_encode(['ok'=>false,'error'=>'login']);exit;}
$uid=(int)$u['id'];
$action=(string)($_GET['action']??'state');
if($_SERVER['REQUEST_METHOD']==='POST'){
  $j=json_decode(file_get_contents('php://input')?:'{}',true); if(!is_array($j))$j=[];
  $action=(string)($j['action']??'location');
}
function earth_json(array $d):void{echo json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
if($action==='share'){
  $sharing=!empty($j['sharing'])?1:0;
  try{db()->prepare('UPDATE earth_locations SET sharing=? WHERE user_id=?')->execute([$sharing,$uid]);}catch(Throwable $e){earth_json(['ok'=>false,'error'=>'db']);}
  earth_json(['ok'=>true,'sharing'=>(bool)$sharing]);
}
if($action==='location'){
  $lat=(float)($j['lat']??999);$lon=(float)($j['lon']??999);
  if($lat < -90 || $lat > 90 || $lon < -180 || $lon > 180) earth_json(['ok'=>false,'error'=>'coords']);
  try{
    $st=db()->prepare('SELECT updated_at FROM earth_locations WHERE user_id=? LIMIT 1');$st->execute([$uid]);$last=$st->fetchColumn();
    if($last && strtotime((string)$last) > time()-55){earth_json(['ok'=>true,'throttled'=>true,'sharing'=>true]);}
    db()->prepare('INSERT INTO earth_locations (user_id,lat,lon,accuracy,speed,heading,sharing,updated_at) VALUES (?,?,?,?,?,?,1,NOW()) ON DUPLICATE KEY UPDATE lat=VALUES(lat),lon=VALUES(lon),accuracy=VALUES(accuracy),speed=VALUES(speed),heading=VALUES(heading),sharing=1,updated_at=NOW()')->execute([$uid,$lat,$lon,max(0,(float)($j['accuracy']??0)),isset($j['speed'])&&$j['speed']!==null?max(0,(float)$j['speed']):null,isset($j['heading'])&&$j['heading']!==null?(float)$j['heading']:null]);
  }catch(Throwable $e){earth_json(['ok'=>false,'error'=>'db']);}
  earth_json(['ok'=>true,'throttled'=>false,'sharing'=>true]);
}
if($action==='conversation'){
  $peer=(int)($j['user_id']??0);if($peer<=0||$peer===$uid)earth_json(['ok'=>false,'error'=>'user']);
  try{if(!contacts_are_mutual($uid,$peer)||contacts_is_blocked_either($uid,$peer))earth_json(['ok'=>false,'error'=>'contact']);require_once dirname(__DIR__).'/includes/functions.php';$id=get_or_create_conversation($uid,$peer);earth_json(['ok'=>true,'conversation_id'=>$id]);}catch(Throwable $e){earth_json(['ok'=>false,'error'=>'db']);}
}
if($action==='message'){
  $conv=(int)($j['conversation_id']??0);$body=trim((string)($j['body']??''));if(!$conv||$body==='')earth_json(['ok'=>false,'error'=>'message']);
  if(mb_strlen($body)>2000)$body=mb_substr($body,0,2000);
  try{$st=db()->prepare('SELECT user_a_id,user_b_id FROM conversations WHERE id=? LIMIT 1');$st->execute([$conv]);$c=$st->fetch();if(!$c||((int)$c['user_a_id']!==$uid&&(int)$c['user_b_id']!==$uid))earth_json(['ok'=>false,'error'=>'conversation']);$peer=((int)$c['user_a_id']===$uid)?(int)$c['user_b_id']:(int)$c['user_a_id'];if(!contacts_are_mutual($uid,$peer)||contacts_is_blocked_either($uid,$peer))earth_json(['ok'=>false,'error'=>'contact']);db()->prepare('INSERT INTO messages (conversation_id,sender_id,body) VALUES (?,?,?)')->execute([$conv,$uid,$body]);$id=(int)db()->lastInsertId();earth_json(['ok'=>true,'id'=>$id]);}catch(Throwable $e){earth_json(['ok'=>false,'error'=>'db']);}
}
// state: only mutual contacts, only users who explicitly enabled sharing, only fresh points.
try{
  $st=db()->prepare("SELECT e.lat,e.lon,e.accuracy,e.speed,e.heading,e.sharing,e.updated_at FROM earth_locations e WHERE e.user_id=? LIMIT 1");$st->execute([$uid]);$me=$st->fetch()?:null;
  $st=db()->prepare("SELECT u.id,u.username,u.avatar,u.gravatar_email,e.lat,e.lon,e.accuracy,e.speed,e.heading,e.updated_at FROM users u JOIN user_contacts c1 ON c1.user_id=? AND c1.contact_user_id=u.id JOIN user_contacts c2 ON c2.user_id=u.id AND c2.contact_user_id=? JOIN earth_locations e ON e.user_id=u.id AND e.sharing=1 AND e.updated_at > (NOW() - INTERVAL 130 SECOND) LEFT JOIN user_blocks b1 ON b1.blocker_id=? AND b1.blocked_id=u.id LEFT JOIN user_blocks b2 ON b2.blocker_id=u.id AND b2.blocked_id=? WHERE u.id<>? AND (NULLIF(u.avatar,'') IS NOT NULL OR NULLIF(u.gravatar_email,'') IS NOT NULL) AND b1.blocked_id IS NULL AND b2.blocked_id IS NULL ORDER BY e.updated_at DESC LIMIT 100");$st->execute([$uid,$uid,$uid,$uid,$uid]);$rows=$st->fetchAll()?:[];$contacts=[];foreach($rows as $r){$contacts[]=['id'=>(int)$r['id'],'username'=>(string)$r['username'],'avatar'=>function_exists('user_avatar_url')?user_avatar_url($r,96):((string)$r['avatar']), 'lat'=>(float)$r['lat'],'lon'=>(float)$r['lon'],'accuracy'=>(float)$r['accuracy'],'speed'=>$r['speed']===null?null:(float)$r['speed'],'heading'=>$r['heading']===null?null:(float)$r['heading'],'updated_at'=>(string)$r['updated_at']];}
  earth_json(['ok'=>true,'sharing'=>(bool)($me['sharing']??false),'me'=>$me?['lat'=>(float)$me['lat'],'lon'=>(float)$me['lon'],'accuracy'=>(float)$me['accuracy'],'speed'=>$me['speed']===null?null:(float)$me['speed'],'heading'=>$me['heading']===null?null:(float)$me['heading']]:null,'contacts'=>$contacts]);
}catch(Throwable $e){earth_json(['ok'=>false,'error'=>'db']);}
