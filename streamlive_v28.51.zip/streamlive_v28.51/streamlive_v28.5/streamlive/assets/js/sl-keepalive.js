(function () {
  var url = '/api/ext_health.php';
  function beat() {
    try {
      fetch(url, { method: 'GET', cache: 'no-store', credentials: 'omit', keepalive: true }).catch(function () {});
    } catch (e) {}
  }
  beat();
  setInterval(beat, 45000);
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) beat();
  });
})();
