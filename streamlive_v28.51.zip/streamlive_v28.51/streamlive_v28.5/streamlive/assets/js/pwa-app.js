/* PWA install ОТКЛЮЧЁН. Используем расширение: /download/extension_app.php */
(function () {
  // глушим beforeinstallprompt, чтобы браузер не предлагал «Установить приложение»
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
  });
})();
