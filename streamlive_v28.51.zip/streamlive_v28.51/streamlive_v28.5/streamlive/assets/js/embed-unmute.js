/**
 * Общий unmute для ВСЕХ embed-страниц StreamLive.
 * Браузер блокирует автозвук — нужна кнопка/жест.
 * v=1
 */
(function () {
  if (window.__SL_EMBED_UNMUTE) return;
  window.__SL_EMBED_UNMUTE = true;

  function forceUnmute() {
    var ok = false;
    try {
      document.querySelectorAll('video, audio').forEach(function (v) {
        try {
          v.muted = false;
          v.defaultMuted = false;
          v.removeAttribute('muted');
          try { v.volume = 1; } catch (e) {}
          if (typeof v.play === 'function') {
            var p = v.play();
            if (p && p.catch) p.catch(function () {});
          }
          ok = true;
        } catch (e) {}
      });
    } catch (e) {}

    try {
      if (window.playerjs && typeof window.playerjs.api === 'function') {
        window.playerjs.api('unmute');
        window.playerjs.api('volume', 100);
        window.playerjs.api('play');
        ok = true;
      }
      if (window.PlayerjsAPI) {
        try { window.PlayerjsAPI('playerjs-container', 'unmute'); } catch (e) {}
        try { window.PlayerjsAPI('playerjs-container', 'volume', 100); } catch (e) {}
      }
    } catch (e) {}

    try {
      document.querySelectorAll('iframe').forEach(function (f) {
        try {
          if (!f.contentWindow) return;
          f.contentWindow.postMessage(JSON.stringify({ event: 'command', func: 'unMute', args: [] }), '*');
          f.contentWindow.postMessage(JSON.stringify({ event: 'command', func: 'setVolume', args: [100] }), '*');
          f.contentWindow.postMessage(JSON.stringify({ method: 'setVolume', value: 1 }), '*');
          f.contentWindow.postMessage({ type: 'player_control', action: 'unmute' }, '*');
          ok = true;
        } catch (e2) {}
      });
    } catch (e) {}

    return ok;
  }

  function ensureBtn() {
    var btn = document.getElementById('sl-embed-unmute');
    if (btn) return btn;
    btn = document.createElement('button');
    btn.id = 'sl-embed-unmute';
    btn.type = 'button';
    btn.textContent = '🔊 Включить звук';
    btn.setAttribute('aria-label', 'Включить звук');
    btn.style.cssText = [
      'position:fixed', 'left:50%', 'bottom:18px', 'transform:translateX(-50%)',
      'z-index:2147483646', 'padding:12px 22px', 'border:0', 'border-radius:24px',
      'background:#ff0025', 'color:#fff', 'font:700 15px system-ui,sans-serif',
      'cursor:pointer', 'box-shadow:0 8px 28px rgba(0,0,0,.5)'
    ].join(';');
    (document.body || document.documentElement).appendChild(btn);

    function onUnmute(e) {
      if (e) { e.preventDefault(); e.stopPropagation(); }
      var ok = forceUnmute();
      setTimeout(forceUnmute, 200);
      setTimeout(forceUnmute, 600);
      setTimeout(forceUnmute, 1200);
      btn.textContent = ok ? '🔊 Звук включён' : '🔊 Ещё раз';
      if (ok) setTimeout(function () { try { btn.style.display = 'none'; } catch (e) {} }, 900);
    }
    btn.addEventListener('click', onUnmute);
    return btn;
  }

  function boot() {
    ensureBtn();
    // не стартуем со звуком сами — только по кнопке (политика браузера)
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  // postMessage от родителя: unmute
  window.addEventListener('message', function (ev) {
    var d = ev.data;
    if (!d) return;
    if (d === 'unmute' || d === 'sl_unmute' || (d.type === 'player_control' && d.action === 'unmute') || d.func === 'unMute') {
      forceUnmute();
    }
  });

  window.slEmbedUnmute = forceUnmute;
})();
