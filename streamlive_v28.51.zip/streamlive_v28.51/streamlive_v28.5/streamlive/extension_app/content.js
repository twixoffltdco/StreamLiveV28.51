(function () {
  var p = new URLSearchParams(location.search);
  if (p.get('from_app') !== '1' && p.get('ext') !== '1') return;
  try { document.cookie = 'sl_native_app=1;path=/;max-age=1209600;SameSite=Lax'; } catch (e) {}
})();
