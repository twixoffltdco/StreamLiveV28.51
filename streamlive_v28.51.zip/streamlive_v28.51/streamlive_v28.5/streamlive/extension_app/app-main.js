(async function () {
  function baseUrl() {
    var u = (typeof STREAMLIVE_BASE_URL !== 'undefined' && STREAMLIVE_BASE_URL)
      ? String(STREAMLIVE_BASE_URL)
      : '';
    return u.replace(/\/$/, '');
  }

  function showSplash(name) {
    document.getElementById('stitle').textContent = name || 'App';
    document.getElementById('logo').textContent = (name || 'A').charAt(0).toUpperCase();
    document.getElementById('title').textContent = name || 'App';
  }

  async function api(path) {
    var base = baseUrl();
    if (!base) return { ok: false, offline: true, error: 'no_base_url' };
    try {
      var res = await fetch(base + path, {
        method: 'GET',
        mode: 'cors',
        credentials: 'omit',
        cache: 'no-store',
        headers: { 'Accept': 'application/json' }
      });
      var t = await res.text();
      try { return JSON.parse(t); } catch (e) { return { ok: false, error: 'json', status: res.status }; }
    } catch (e) {
      return { ok: false, offline: true, error: String(e.message || e) };
    }
  }

  function esc(s) {
    return String(s || '').replace(/[&<>"]/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c];
    });
  }

  function openSite(path) {
    var base = baseUrl();
    var join = path.indexOf('?') >= 0 ? '&' : '?';
    var url = base + path + join + 'from_app=1&ext=1';
    if (typeof chrome !== 'undefined' && chrome.tabs) {
      chrome.tabs.create({ url: url });
    } else {
      window.open(url, '_blank');
    }
  }

  function render(feed) {
    var box = document.getElementById('list');
    box.innerHTML = '';
    var videos = (feed && feed.videos) || [];
    if (!videos.length) {
      box.innerHTML = '<div class="item">Лента пуста · ' + esc(baseUrl()) + '</div>';
    }
    videos.slice(0, 25).forEach(function (v) {
      var a = document.createElement('a');
      a.className = 'item';
      a.href = '#';
      a.innerHTML = '<b>' + esc(v.title || 'Видео') + '</b>';
      a.onclick = function (e) {
        e.preventDefault();
        openSite('/video.php?slug=' + encodeURIComponent(v.slug || ''));
      };
      box.appendChild(a);
    });
  }

  function renderMore() {
    var box = document.getElementById('list');
    box.innerHTML = '';
    [
      ['Все видео', '/videos.php'],
      ['Каналы', '/channels.php'],
      ['Форум', '/forum.php'],
      ['Студия', '/studio.php'],
      ['Партнёры', '/partners.php']
    ].forEach(function (x) {
      var a = document.createElement('a');
      a.className = 'item';
      a.href = '#';
      a.textContent = x[0];
      a.onclick = function (e) { e.preventDefault(); openSite(x[1]); };
      box.appendChild(a);
    });
  }

  // coins
  function today() {
    var d = new Date();
    return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  }
  chrome.storage.local.get({ coins: 0, lastBonus: '' }, function (d) {
    document.getElementById('coins').textContent = '🪙 ' + (d.coins || 0);
  });
  document.getElementById('btnBonus').onclick = function () {
    chrome.storage.local.get({ coins: 0, lastBonus: '' }, function (d) {
      if (d.lastBonus === today()) return;
      var c = (d.coins || 0) + 5;
      chrome.storage.local.set({ coins: c, lastBonus: today() });
      document.getElementById('coins').textContent = '🪙 ' + c;
    });
  };

  document.getElementById('btnReload').onclick = function () { location.reload(); };
  document.getElementById('btnSite').onclick = function () { openSite('/'); };
  document.getElementById('btnRetry').onclick = function () { location.reload(); };

  document.querySelectorAll('.nav button').forEach(function (btn) {
    btn.onclick = function () {
      document.querySelectorAll('.nav button').forEach(function (b) { b.classList.remove('on'); });
      btn.classList.add('on');
      if (btn.getAttribute('data-p') === 'more') renderMore();
      else location.reload();
    };
  });

  var base = baseUrl();
  showSplash(base ? base.replace(/^https?:\/\//, '').split('/')[0] : 'App');

  // save base
  if (base && chrome.storage) {
    chrome.storage.sync.set({ baseUrl: base });
  }

  var health = await api('/api/ext_health.php');
  document.getElementById('splash').classList.add('hide');

  if (health.offline || health.ok === false) {
    document.getElementById('offline').classList.add('show');
    document.getElementById('errDetail').textContent = (health.error || '') + '\n' + base;
    return;
  }

  document.getElementById('app').classList.add('show');
  var meta = await api('/api/ext_app_meta.php');
  if (meta && meta.name) showSplash(meta.name);

  var feed = await api('/api/ext_app_feed.php');
  render(feed.ok === false ? { videos: [] } : feed);

  // ping
  try {
    fetch(base + '/api/native_ping.php', {
      method: 'POST',
      mode: 'cors',
      credentials: 'omit',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ device_id: 'popup', platform: 'extension', version: '2.4.0' })
    });
  } catch (e) {}
})();
