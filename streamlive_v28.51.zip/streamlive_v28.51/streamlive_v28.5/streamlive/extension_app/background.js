// Keepalive: пока открыта вкладка StreamLive — SW не «засыпает» зря
chrome.alarms.create('sl_keep', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(function (a) {
  if (a.name !== 'sl_keep') return;
  // просто трогаем storage — activity
  chrome.storage.local.set({ sl_ping: Date.now() });
});
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg && msg.type === 'sl_alive') {
    chrome.storage.local.set({ sl_last_tab: Date.now(), sl_origin: msg.origin || '' });
    sendResponse({ ok: true });
  }
  return true;
});
