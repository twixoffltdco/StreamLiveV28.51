<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
if (is_file(__DIR__ . '/includes/csrf_compat.php')) require_once __DIR__ . '/includes/csrf_compat.php';
require_once __DIR__ . '/includes/battle_pass.php';
$u = current_user();
if (!$u) { flash_set('error', 'Войдите, чтобы открыть Battle Pass'); redirect('/auth/login.php'); }
bp_ensure_schema();
// daily login task
bp_progress_task((int)$u['id'], 'login_daily', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'claim') {
  csrf_verify();
  $r = bp_claim_level((int)$u['id'], (int)($_POST['level_id'] ?? 0));
  flash_set($r['ok'] ? 'success' : 'error', $r['message'] ?? $r['error'] ?? '');
  redirect('/battle_pass.php');
}

$state = bp_user_state((int)$u['id']);
$pageTitle = 'Battle Pass';
require __DIR__ . '/includes/header.php';
$season = $state['season'];
$prog = $state['progress'] ?? ['xp'=>0,'level_num'=>0];
?>
<div class="container" style="max-width:720px;margin:20px auto;padding:0 12px">
  <h1>Battle Pass</h1>
  <?php if (!$season): ?>
    <p class="muted">Сейчас нет активного сезона. Загляни позже.</p>
  <?php else: ?>
    <div class="card" style="padding:16px;margin-bottom:16px">
      <h2 style="margin:0 0 6px"><?= e($season['title']) ?></h2>
      <p class="muted"><?= e($season['description'] ?? '') ?></p>
      <p><b>Уровень <?= (int)$prog['level_num'] ?></b> · <?= (int)$prog['xp'] ?> XP сезона</p>
      <p><a href="/flexblocks/">Flex Blocks →</a></p>
    </div>
    <h3>Задания</h3>
    <?php foreach ($state['tasks'] as $t):
      $p = (int)($t['user_progress'] ?? 0);
      $tgt = max(1, (int)$t['target_count']);
      $done = !empty($t['completed_at']) || $p >= $tgt;
    ?>
      <div style="padding:10px 12px;margin:8px 0;border-radius:12px;border:1px solid rgba(127,127,127,.25)">
        <b><?= e($t['title']) ?></b>
        <span class="muted"> · <?= $done ? '✓' : ($p . '/' . $tgt) ?> · +<?= (int)$t['xp_reward'] ?> XP</span>
      </div>
    <?php endforeach; ?>
    <h3 style="margin-top:20px">Награды уровней</h3>
    <?php
      $claimed = [];
      try {
        $st = db()->prepare('SELECT level_id FROM bp_user_rewards WHERE user_id=? AND season_id=?');
        $st->execute([(int)$u['id'], (int)$season['id']]);
        foreach ($st->fetchAll() ?: [] as $r) $claimed[(int)$r['level_id']] = true;
      } catch (Throwable $e) {}
      foreach ($state['levels'] as $L):
        $open = (int)$prog['level_num'] >= (int)$L['level_num'];
        $got = !empty($claimed[(int)$L['id']]);
    ?>
      <div style="padding:10px 12px;margin:8px 0;border-radius:12px;border:1px solid rgba(127,127,127,.25);display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap">
        <div>
          <b>Ур. <?= (int)$L['level_num'] ?></b>
          <?= e($L['reward_label'] ?: ($L['reward_type'] . ': ' . $L['reward_value'])) ?>
        </div>
        <?php if ($got): ?>
          <span class="muted">Получено</span>
        <?php elseif ($open): ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="claim">
            <input type="hidden" name="level_id" value="<?= (int)$L['id'] ?>">
            <button class="btn btn-primary btn-sm" type="submit">Забрать</button>
          </form>
        <?php else: ?>
          <span class="muted">Закрыто</span>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
