<?php
/**
 * embed.php — встраиваемый плеер для StreamTok
 * Поддерживает управление через postMessage (play, pause, mute, unmute)
 */

require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
if (is_file(__DIR__ . '/includes/paid_access.php')) require_once __DIR__ . '/includes/paid_access.php';

$slug = $_GET['slug'] ?? '';
$autoplay = isset($_GET['autoplay']) ? (int)$_GET['autoplay'] : 0;
$muted = isset($_GET['mute']) ? (int)$_GET['mute'] : 0;

$stmt = db()->prepare("SELECT * FROM channels WHERE slug = ? AND status = 'approved'");
$stmt->execute([$slug]);
$channel = $stmt->fetch();

if (!$channel) {
    http_response_code(404);
    echo 'Канал недоступен';
    exit;
}

$__user = current_user();
if ($__user && is_user_banned_on_channel($channel['id'], $__user['id'])) {
    http_response_code(403);
    echo 'Доступ запрещён';
    exit;
}

if (function_exists('paid_channel_is_paid') && paid_channel_is_paid($channel)) {
    $__user = $__user ?? (function_exists('current_user') ? current_user() : null);
    if (!(function_exists('paid_user_can_watch') && paid_user_can_watch($__user, $channel))) {
        http_response_code(403);
        header('Content-Type: text/html; charset=utf-8');
        echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Платный канал</title></head><body style="margin:0;background:#0b1220;color:#eee;font-family:system-ui;display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center;padding:24px"><div><h1 style="font-size:1.15rem;margin:0 0 8px">Платный контент</h1><p style="opacity:.7;margin:0">Встраивание недоступно.</p></div></body></html>';
        exit;
    }
}
if (is_file(__DIR__ . '/includes/content_views.php')) require_once __DIR__ . '/includes/content_views.php';
if (function_exists('content_view_register')) {
  $__views = content_view_register('channel', (int)$channel['id']);
  $channel['views'] = $__views;
  $channel['views_count'] = $__views;
} else {
  try { db()->prepare('UPDATE channels SET views = COALESCE(views,0) + 1 WHERE id = ?')->execute([$channel['id']]); } catch (Throwable $e) {}
}
$activeSource = resolve_active_source($channel);

$autoplayAttr = $autoplay ? 'autoplay' : '';
$mutedAttr = $muted ? 'muted' : '';
$playsinlineAttr = 'playsinline webkit-playsinline';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?= htmlspecialchars($channel['title']) ?></title>
    <style>
        html, body { margin: 0; padding: 0; background: #0b1220; color: #e8eef8; font-family: system-ui, sans-serif; min-height: 100%; }
        .page { max-width: 960px; margin: 0 auto; padding: 12px; }
        .player-wrap { width: 100%; aspect-ratio: 16/9; position: relative; background: #000; display: flex; align-items: center; justify-content: center; border-radius: 16px; overflow: hidden; border: 1px solid #243049; }
        .meta { margin-top: 14px; }
        .badge { display:inline-flex; align-items:center; gap:6px; font-size:11px; font-weight:700; text-transform:uppercase; background:#e31c25; color:#fff; padding:4px 10px; border-radius:999px; margin-bottom:10px; }
        .badge:before { content:""; width:6px; height:6px; border-radius:50%; background:#fff; }
        h1.emb-title { margin:0 0 8px; font-size: clamp(1.05rem, 2.5vw, 1.45rem); line-height:1.25; }
        .now { color:#8b9bb4; font-size:14px; margin:0 0 12px; } .now b { color:#e8eef8; }
        .desc { background:#141c2e; border:1px solid #243049; border-radius:14px; padding:14px 16px; font-size:14px; line-height:1.55; color:#c5d0e6; white-space:pre-wrap; }
        .foot { margin-top:12px; font-size:12px; color:#8b9bb4; } .foot a { color:#93c5fd; }
        .player-wrap iframe, .player-wrap video, .player-wrap img {
            width: 100%; height: 100%; border: none; object-fit: contain;
        }
        .player-logo {
            position: absolute; bottom: 10px; right: 10px;
            width: 32px; height: 32px; border-radius: 8px;
            opacity: .85; z-index: 5; pointer-events: none;
            object-fit: contain;
        }
        .offline-text {
            color: #888; font-size: 14px; font-family: sans-serif;
        }
    </style>
</head>
<body>
<div class="page">
<div class="player-wrap" id="playerWrap">
    <?php if (!$activeSource): ?>
        <div class="offline-text">Сейчас нет эфира</div>
    <?php elseif ($activeSource['type'] === 'mp4'): ?>
        <video <?= $autoplayAttr ?> <?= $mutedAttr ?> <?= $playsinlineAttr ?> loop playsinline id="playerVideo">
            <source src="<?= htmlspecialchars($activeSource['url']) ?>" type="video/mp4">
        </video>
    <?php elseif ($activeSource['type'] === 'hls' || $activeSource['type'] === 'm3u8'): ?>
        <video <?= $autoplayAttr ?> <?= $mutedAttr ?> <?= $playsinlineAttr ?> loop playsinline id="playerVideo">
            <source src="<?= htmlspecialchars($activeSource['url']) ?>" type="application/x-mpegURL">
        </video>
    <?php elseif ($activeSource['type'] === 'iframe'): ?>
        <iframe src="<?= htmlspecialchars($activeSource['url']) ?>" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen id="playerIframe"></iframe>
    <?php elseif ($activeSource['type'] === 'image'): ?>
        <img src="<?= htmlspecialchars($activeSource['url']) ?>" alt="" id="playerImage">
    <?php else: ?>
        <iframe src="<?= htmlspecialchars($activeSource['url']) ?>" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen id="playerIframe"></iframe>
    <?php endif; ?>
    <?php if ($channel['logo_url']): ?>
        <img class="player-logo" src="<?= htmlspecialchars($channel['logo_url']) ?>" alt="">
    <?php endif; ?>
</div>

<script>
    // Получаем элементы
    const video = document.getElementById('playerVideo');
    const iframe = document.getElementById('playerIframe');
    const img = document.getElementById('playerImage');

    // Слушаем сообщения от родительского окна
    window.addEventListener('message', function(event) {
        const data = event.data;
        if (!data || data.type !== 'player_control') return;

        // Управление видео
        if (video) {
            if (data.action === 'play') {
                video.muted = false;
                video.play().catch(() => {});
            } else if (data.action === 'pause') {
                video.pause();
            } else if (data.action === 'mute') {
                video.muted = true;
            } else if (data.action === 'unmute') {
                video.muted = false;
            }
        }

        // Для iframe мы не можем управлять внутренним плеером, поэтому просто игнорируем
        // (но можно было бы перезагрузить src, но мы отказываемся от перезагрузки)
        // Поэтому оставляем как есть.
    });

    // Если есть параметр autoplay и video, запускаем сразу
    <?php if ($autoplay && $activeSource && in_array($activeSource['type'], ['mp4', 'hls', 'm3u8'])): ?>
    document.addEventListener('DOMContentLoaded', function() {
        if (video) {
            video.muted = <?= $muted ? 'true' : 'false' ?>;
            video.play().catch(() => {});
        }
    });
    <?php endif; ?>
</script>
</body>
</html>