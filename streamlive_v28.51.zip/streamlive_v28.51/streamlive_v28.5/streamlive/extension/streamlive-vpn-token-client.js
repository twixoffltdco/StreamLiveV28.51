(() => {
  const TOKEN_ENDPOINT = '/streamlive_vpn_token.php';
  const HOST_HINT = /streamlive/i;
  const CLIENT_ID = 'streamlive-extension-v2';
  const REFRESH_MS = 4 * 60 * 1000;

  function shouldRun() {
    try {
      return HOST_HINT.test(location.hostname);
    } catch (_) {
      return false;
    }
  }

  async function refreshToken() {
    if (!shouldRun()) return;
    try {
      const res = await fetch(TOKEN_ENDPOINT, {
        credentials: 'same-origin',
        cache: 'no-store',
        headers: { 'X-StreamLive-VPN-Client': CLIENT_ID }
      });
      if (!res.ok) return;
      const data = await res.json();
      if (!data || !data.token) return;
      chrome.runtime.sendMessage({
        action: 'streamliveSetVpnToken',
        token: String(data.token),
        expiresAt: Number(data.expiresAt || 0)
      }).catch(() => {});
    } catch (_) {}
  }

  refreshToken();
  setInterval(refreshToken, REFRESH_MS);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) refreshToken();
  });
})();
