(function(root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.FlexVpnProxyRecoveryPolicy = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function() {
  'use strict';

  const SCHEMA_VERSION = 1;
  const ENDPOINT_QUARANTINE_STORAGE_KEY = 'endpointQuarantineV1';
  const RECONNECT_STORAGE_KEY = 'vpnReconnectV1';
  const RECOVERY_BLOCK_STORAGE_KEY = 'vpnRecoveryBlock';
  const RECONNECT_DELAY_RANGES_MS = Object.freeze([
    Object.freeze([2000, 5000]),
    Object.freeze([5000, 15000]),
    Object.freeze([15000, 60000]),
    Object.freeze([60000, 300000]),
    Object.freeze([300000, 900000]),
    Object.freeze([900000, 1800000])
  ]);
  const QUARANTINE_BACKOFF_MS = Object.freeze([
    1800000,
    21600000,
    86400000,
    604800000
  ]);
  const QUARANTINE_HISTORY_MS = 2592000000;
  const MAX_QUARANTINE_RECORDS = 128;
  const MANUAL_KICK_COOLDOWN_MS = 5000;
  const SHA256_HEX = /^[0-9a-f]{64}$/;
  const RECONNECT_REASON = /^[a-z0-9][a-z0-9_-]{0,127}$/;
  const DNS_LABEL = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
  const SUPPORTED_SCHEMES = new Set(['http', 'https']);
  const ACCOUNT_BLOCK_CODES = new Set([
    'device_limit_reached',
    'premium_required',
    'unauthorized'
  ]);
  const LOCAL_ACTION_BLOCK_CODES = new Set([
    'split_tunneling_empty',
    'proxy_control_blocked',
    'proxy_control_not_controllable'
  ]);
  const PROTOCOL_ACTION_BLOCK_CODES = new Set([
    'legacy_grant_disabled',
    'invalid_request'
  ]);
  const STRUCTURED_ACCOUNT_SOURCES = new Set([
    'account',
    'premium-grant',
    'premium_grant',
    'grant'
  ]);

  function policyError(message) {
    const error = new Error(message);
    error.code = 'PROXY_RECOVERY_POLICY_INVALID';
    return error;
  }

  function isPlainObject(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
    const prototype = Object.getPrototypeOf(value);
    if (prototype === null) return true;
    if (Object.getPrototypeOf(prototype) !== null) return false;
    if (!Object.prototype.hasOwnProperty.call(prototype, 'constructor')) return false;
    return typeof prototype.constructor === 'function' && prototype.constructor.name === 'Object';
  }

  function isTimestamp(value) {
    return Number.isSafeInteger(value) && value >= 0;
  }

  function requireTimestamp(value, label) {
    if (!isTimestamp(value)) throw policyError(`${label} timestamp is invalid.`);
    return value;
  }

  function normalizeHost(value) {
    if (typeof value !== 'string') throw policyError('Proxy endpoint host is invalid.');
    let host = value.trim().toLowerCase();
    if (host.startsWith('[') && host.endsWith(']')) host = host.slice(1, -1);
    if (
      !host ||
      host.length > 253 ||
      /[\s\0\/?#@:\[\]]/.test(host) ||
      host.startsWith('.') ||
      host.endsWith('.')
    ) {
      throw policyError('Proxy endpoint host is invalid.');
    }

    const labels = host.split('.');
    if (labels.some((label) => !DNS_LABEL.test(label))) {
      throw policyError('Proxy endpoint host is invalid.');
    }
    return host;
  }

  function normalizePort(value) {
    if (
      typeof value !== 'number' &&
      (typeof value !== 'string' || !/^\d{1,5}$/.test(value))
    ) {
      throw policyError('Proxy endpoint port is invalid.');
    }
    const port = Number(value);
    if (!Number.isInteger(port) || port < 1 || port > 65535) {
      throw policyError('Proxy endpoint port is invalid.');
    }
    return port;
  }

  function normalizeEndpoint(value) {
    if (!isPlainObject(value)) throw policyError('Proxy endpoint is invalid.');
    const scheme = typeof value.scheme === 'string'
      ? value.scheme.trim().toLowerCase()
      : '';
    if (!SUPPORTED_SCHEMES.has(scheme)) {
      throw policyError('Proxy endpoint scheme is invalid.');
    }
    return {
      scheme,
      host: normalizeHost(value.host),
      port: normalizePort(value.port)
    };
  }

  function normalizeServerKey(value) {
    if (typeof value !== 'string') throw policyError('Proxy server key is invalid.');
    const serverKey = value.trim();
    if (
      !serverKey ||
      serverKey.length > 128 ||
      /[\0-\x1f\x7f]/.test(serverKey)
    ) {
      throw policyError('Proxy server key is invalid.');
    }
    return serverKey;
  }

  function normalizeDigest(value) {
    const digest = typeof value === 'string' ? value.toLowerCase() : '';
    if (!SHA256_HEX.test(digest)) throw policyError('SHA-256 digest is invalid.');
    return digest;
  }

  async function createEndpointIdentity(input) {
    if (!isPlainObject(input) || typeof input.digestSha256 !== 'function') {
      throw policyError('Endpoint identity input is invalid.');
    }
    const serverKey = normalizeServerKey(input.serverKey);
    const endpoint = normalizeEndpoint(input.endpoint);
    const endpointCanonical =
      `flexvpn:endpoint:v1\0${endpoint.scheme}\0${endpoint.host}\0${endpoint.port}`;
    const keyEndpointCanonical =
      `flexvpn:key-endpoint:v1\0${serverKey}\0${endpoint.scheme}\0${endpoint.host}\0${endpoint.port}`;
    const [endpointHash, keyEndpointHash] = await Promise.all([
      input.digestSha256(endpointCanonical),
      input.digestSha256(keyEndpointCanonical)
    ]);
    return {
      endpointHash: normalizeDigest(endpointHash),
      keyEndpointHash: normalizeDigest(keyEndpointHash)
    };
  }

  function emptyQuarantineEnvelope() {
    return {
      schemaVersion: SCHEMA_VERSION,
      evidence: {},
      keyEndpointIndex: {}
    };
  }

  function normalizeRecord(value, nowMs) {
    if (!isPlainObject(value)) return null;
    const failureCount = value.failureCount;
    const firstFailureAt = value.firstFailureAt;
    const lastFailureAt = value.lastFailureAt;
    const blockedUntil = value.blockedUntil;
    const historyExpiresAt = value.historyExpiresAt;
    if (
      !Number.isSafeInteger(failureCount) ||
      failureCount < 1 ||
      !isTimestamp(firstFailureAt) ||
      !isTimestamp(lastFailureAt) ||
      !isTimestamp(blockedUntil) ||
      !isTimestamp(historyExpiresAt) ||
      firstFailureAt > lastFailureAt ||
      blockedUntil < lastFailureAt ||
      historyExpiresAt <= lastFailureAt ||
      historyExpiresAt <= nowMs
    ) {
      return null;
    }
    return {
      failureCount,
      firstFailureAt,
      lastFailureAt,
      blockedUntil,
      historyExpiresAt
    };
  }

  function normalizeRecordLimit(value) {
    if (!Number.isInteger(value) || value < 1) return MAX_QUARANTINE_RECORDS;
    return Math.min(value, MAX_QUARANTINE_RECORDS);
  }

  function normalizeQuarantineEnvelope(value, options = {}) {
    const nowMs = options.nowMs === undefined
      ? 0
      : requireTimestamp(options.nowMs, 'Quarantine normalization');
    const maxRecords = normalizeRecordLimit(options.maxRecords);
    const normalized = emptyQuarantineEnvelope();
    if (
      !isPlainObject(value) ||
      value.schemaVersion !== SCHEMA_VERSION ||
      !isPlainObject(value.evidence) ||
      !isPlainObject(value.keyEndpointIndex)
    ) {
      return normalized;
    }

    for (const [endpointHash, record] of Object.entries(value.evidence)) {
      if (!SHA256_HEX.test(endpointHash)) continue;
      const normalizedRecord = normalizeRecord(record, nowMs);
      if (normalizedRecord) normalized.evidence[endpointHash] = normalizedRecord;
    }

    const endpointHashes = Object.keys(normalized.evidence);
    if (endpointHashes.length > maxRecords) {
      endpointHashes.sort((leftHash, rightHash) => {
        const left = normalized.evidence[leftHash];
        const right = normalized.evidence[rightHash];
        const leftEligible = left.blockedUntil <= nowMs ? 0 : 1;
        const rightEligible = right.blockedUntil <= nowMs ? 0 : 1;
        if (leftEligible !== rightEligible) return leftEligible - rightEligible;
        if (left.lastFailureAt !== right.lastFailureAt) {
          return left.lastFailureAt - right.lastFailureAt;
        }
        return leftHash.localeCompare(rightHash);
      });
      const removeCount = endpointHashes.length - maxRecords;
      for (let index = 0; index < removeCount; index += 1) {
        delete normalized.evidence[endpointHashes[index]];
      }
    }

    for (const [keyEndpointHash, endpointHash] of Object.entries(value.keyEndpointIndex)) {
      if (
        SHA256_HEX.test(keyEndpointHash) &&
        SHA256_HEX.test(endpointHash) &&
        Object.prototype.hasOwnProperty.call(normalized.evidence, endpointHash)
      ) {
        normalized.keyEndpointIndex[keyEndpointHash] = endpointHash;
      }
    }
    return normalized;
  }

  function normalizeIdentity(value) {
    if (
      !isPlainObject(value) ||
      !SHA256_HEX.test(value.endpointHash) ||
      !SHA256_HEX.test(value.keyEndpointHash)
    ) {
      throw policyError('Endpoint identity hashes are invalid.');
    }
    return {
      endpointHash: value.endpointHash,
      keyEndpointHash: value.keyEndpointHash
    };
  }

  function getQuarantineDecision(input) {
    if (!isPlainObject(input)) throw policyError('Quarantine decision input is invalid.');
    const nowMs = requireTimestamp(input.nowMs, 'Quarantine decision');
    const identity = normalizeIdentity(input.identity);
    const envelope = normalizeQuarantineEnvelope(input.envelope, { nowMs });
    const referencedHashes = new Set([identity.endpointHash]);
    const indexedEndpointHash = envelope.keyEndpointIndex[identity.keyEndpointHash];
    if (indexedEndpointHash) referencedHashes.add(indexedEndpointHash);

    let nextEligibleAt = null;
    for (const endpointHash of referencedHashes) {
      const record = envelope.evidence[endpointHash];
      if (record && record.blockedUntil > nowMs) {
        nextEligibleAt = nextEligibleAt === null
          ? record.blockedUntil
          : Math.max(nextEligibleAt, record.blockedUntil);
      }
    }
    return {
      blocked: nextEligibleAt !== null,
      nextEligibleAt
    };
  }

  function applyConfirmedProbeOutcome(input) {
    if (!isPlainObject(input)) throw policyError('Probe outcome input is invalid.');
    const nowMs = requireTimestamp(input.nowMs, 'Probe outcome');
    const identity = normalizeIdentity(input.identity);
    const maxRecords = normalizeRecordLimit(input.maxRecords);
    const envelope = normalizeQuarantineEnvelope(input.envelope, { nowMs, maxRecords });

    if (input.outcome === 'route-success') {
      delete envelope.evidence[identity.endpointHash];
      for (const [keyEndpointHash, endpointHash] of Object.entries(envelope.keyEndpointIndex)) {
        if (endpointHash === identity.endpointHash) {
          delete envelope.keyEndpointIndex[keyEndpointHash];
        }
      }
      return envelope;
    }
    if (input.outcome !== 'route-failure') {
      throw policyError('Probe outcome is invalid.');
    }

    const previous = envelope.evidence[identity.endpointHash] || null;
    if (previous && nowMs < previous.lastFailureAt) {
      throw policyError('Probe outcome timestamp precedes stored evidence.');
    }
    const failureCount = previous
      ? Math.min(Number.MAX_SAFE_INTEGER, previous.failureCount + 1)
      : 1;
    const backoffMs = QUARANTINE_BACKOFF_MS[
      Math.min(failureCount - 1, QUARANTINE_BACKOFF_MS.length - 1)
    ];
    envelope.evidence[identity.endpointHash] = {
      failureCount,
      firstFailureAt: previous ? previous.firstFailureAt : nowMs,
      lastFailureAt: nowMs,
      blockedUntil: nowMs + backoffMs,
      historyExpiresAt: nowMs + QUARANTINE_HISTORY_MS
    };
    envelope.keyEndpointIndex[identity.keyEndpointHash] = identity.endpointHash;
    return normalizeQuarantineEnvelope(envelope, { nowMs, maxRecords });
  }

  function normalizeReconnectReason(value) {
    const reason = typeof value === 'string' ? value.trim().toLowerCase() : '';
    return RECONNECT_REASON.test(reason) ? reason : null;
  }

  function normalizeReconnectState(value) {
    if (!isPlainObject(value) || value.schemaVersion !== SCHEMA_VERSION) return null;
    const reason = normalizeReconnectReason(value.reason);
    if (
      !Number.isSafeInteger(value.intentRevision) ||
      value.intentRevision < 1 ||
      !Number.isInteger(value.attempt) ||
      value.attempt < 1 ||
      value.attempt > 31 ||
      !reason ||
      !isTimestamp(value.nextAttemptAt) ||
      !isTimestamp(value.lastManualKickAt)
    ) {
      return null;
    }
    return {
      schemaVersion: SCHEMA_VERSION,
      intentRevision: value.intentRevision,
      attempt: value.attempt,
      reason,
      nextAttemptAt: value.nextAttemptAt,
      lastManualKickAt: value.lastManualKickAt
    };
  }

  function createReconnectState(input) {
    if (!isPlainObject(input)) throw policyError('Reconnect input is invalid.');
    if (!Number.isSafeInteger(input.intentRevision) || input.intentRevision < 1) {
      throw policyError('Reconnect intent revision is invalid.');
    }
    const reason = normalizeReconnectReason(input.reason);
    if (!reason) throw policyError('Reconnect reason is invalid.');
    const nowMs = requireTimestamp(input.nowMs, 'Reconnect');
    const previousCandidate = normalizeReconnectState(input.previous);
    const previous = previousCandidate && previousCandidate.intentRevision === input.intentRevision
      ? previousCandidate
      : null;
    const notBeforeMs = input.notBeforeMs === undefined
      ? 0
      : requireTimestamp(input.notBeforeMs, 'Reconnect not-before');

    if (input.manualKick === true) {
      if (
        previous &&
        previous.lastManualKickAt !== 0 &&
        nowMs - previous.lastManualKickAt < MANUAL_KICK_COOLDOWN_MS
      ) {
        return {
          ...previous,
          nextAttemptAt: Math.max(previous.nextAttemptAt, notBeforeMs)
        };
      }
      return {
        schemaVersion: SCHEMA_VERSION,
        intentRevision: input.intentRevision,
        attempt: previous ? previous.attempt : 1,
        reason,
        nextAttemptAt: Math.max(nowMs, notBeforeMs),
        lastManualKickAt: nowMs
      };
    }

    const attempt = previous ? Math.min(31, previous.attempt + 1) : 1;
    const range = RECONNECT_DELAY_RANGES_MS[
      Math.min(attempt - 1, RECONNECT_DELAY_RANGES_MS.length - 1)
    ];
    const randomNumber = Number(input.randomValue);
    const randomValue = Number.isFinite(randomNumber)
      ? Math.min(1, Math.max(0, randomNumber))
      : 0;
    const delayMs = range[0] + Math.floor((range[1] - range[0]) * randomValue);
    return {
      schemaVersion: SCHEMA_VERSION,
      intentRevision: input.intentRevision,
      attempt,
      reason,
      nextAttemptAt: Math.max(nowMs + delayMs, notBeforeMs),
      lastManualKickAt: previous ? previous.lastManualKickAt : 0
    };
  }

  function normalizedFailureCode(value) {
    const code = typeof value === 'string' ? value.trim().toLowerCase() : '';
    return RECONNECT_REASON.test(code) ? code : '';
  }

  function classification(kind, code, controlPlane, endpointEvidence) {
    return { kind, code, controlPlane, endpointEvidence };
  }

  function classifyConnectionFailure(input) {
    const value = isPlainObject(input) ? input : {};
    const source = typeof value.source === 'string' ? value.source.trim().toLowerCase() : '';
    const status = Number(value.status);
    const statusCode = Number.isInteger(status) && status >= 100 && status <= 599
      ? `http_${status}`
      : '';
    const suppliedCode = normalizedFailureCode(value.code);

    if (source === 'proxy-session-v2') {
      const code = statusCode || suppliedCode || (
        value.malformed === true ? 'malformed_response' : 'proxy_session_unavailable'
      );
      return classification('transient', code, true, false);
    }

    const isStructuredAccountResult = value.structured === true &&
      STRUCTURED_ACCOUNT_SOURCES.has(source);
    if (isStructuredAccountResult && ACCOUNT_BLOCK_CODES.has(suppliedCode)) {
      return classification('account-block', suppliedCode, false, false);
    }
    if (
      LOCAL_ACTION_BLOCK_CODES.has(suppliedCode) ||
      (isStructuredAccountResult && PROTOCOL_ACTION_BLOCK_CODES.has(suppliedCode))
    ) {
      return classification('user-action-block', suppliedCode, false, false);
    }

    const endpointEvidence = source === 'endpoint-probe' &&
      value.proxyApplied === true &&
      value.confirmation204Attempted === true &&
      value.confirmation204Succeeded === false &&
      value.failureStage === 'confirmation-204';
    const controlPlane = source === 'control-plane';
    return classification(
      'transient',
      statusCode || suppliedCode || 'transient_failure',
      controlPlane,
      endpointEvidence
    );
  }

  return Object.freeze({
    SCHEMA_VERSION,
    ENDPOINT_QUARANTINE_STORAGE_KEY,
    RECONNECT_STORAGE_KEY,
    RECOVERY_BLOCK_STORAGE_KEY,
    RECONNECT_DELAY_RANGES_MS,
    QUARANTINE_BACKOFF_MS,
    QUARANTINE_HISTORY_MS,
    MAX_QUARANTINE_RECORDS,
    normalizeEndpoint,
    createEndpointIdentity,
    normalizeQuarantineEnvelope,
    getQuarantineDecision,
    applyConfirmedProbeOutcome,
    normalizeReconnectState,
    createReconnectState,
    classifyConnectionFailure
  });
});
