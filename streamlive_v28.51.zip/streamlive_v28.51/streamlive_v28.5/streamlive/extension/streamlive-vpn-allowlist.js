/*
 * Optional exact host allowlist for custom StreamLive engine domains.
 * The bundled DNR rule already covers hostnames containing "streamlive".
 * Add custom hostnames here and the background worker creates equivalent
 * dynamic header rules when the extension starts.
 */
const STREAMLIVE_VPN_CUSTOM_HOSTS = [
  // "my-streamlive-site.example",
  // "another.example"
];

const STREAMLIVE_VPN_TOKEN = "SLVPN-2026-TRUST-7f4c8b9d2a6e1c5f";

function slVpnBuildUrlFilter(host) {
  const h = String(host || "").trim().toLowerCase().replace(/^\.+|\.+$/g, "");
  if (!/^[a-z0-9.-]+$/.test(h) || !h.includes(".")) return null;
  return `||${h}^`;
}

async function slVpnInstallCustomRules() {
  if (!chrome.declarativeNetRequest?.updateDynamicRules) return;
  const rules = [];
  let id = 920000;
  for (const host of STREAMLIVE_VPN_CUSTOM_HOSTS) {
    const urlFilter = slVpnBuildUrlFilter(host);
    if (!urlFilter) continue;
    rules.push({
      id: id++,
      priority: 100,
      action: {
        type: "modifyHeaders",
        requestHeaders: [
          { header: "X-StreamLive-VPN", operation: "set", value: STREAMLIVE_VPN_TOKEN }
        ]
      },
      condition: {
        urlFilter,
        resourceTypes: ["main_frame", "sub_frame", "xmlhttprequest", "script", "stylesheet", "image", "font", "media"]
      }
    });
  }
  try {
    const old = await chrome.declarativeNetRequest.getDynamicRules();
    const removeRuleIds = old.map(r => r.id).filter(id => id >= 920000 && id < 921000);
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: rules });
  } catch (e) {
    console.warn("[StreamLive VPN] custom allowlist rules unavailable:", e?.message || e);
  }
}

slVpnInstallCustomRules();
chrome.runtime.onInstalled?.addListener(() => slVpnInstallCustomRules());
