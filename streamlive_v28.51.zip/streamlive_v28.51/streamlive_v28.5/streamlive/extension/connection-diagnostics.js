(function(root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.FlexVpnConnectionDiagnostics = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function() {
  'use strict';

  const STORAGE_KEY = 'connectionDiagnosticsV1';
  const MAX_EVENTS = 200;
  const sets = {
    event: new Set(['startup', 'intent', 'phase', 'outcome', 'auth', 'candidate', 'recovery', 'quarantine']),
    code: new Set(['ok', 'unknown', 'timeout', 'denied', 'unavailable', 'obsolete', 'cancelled',
      'proxy_auth_denied', 'proxy_auth_unavailable', 'proxy_auth_timeout', 'network_error',
      'fetch_failed', 'invalid_response', 'invalid_request', 'unauthorized', 'premium_required',
      'device_limit_reached', 'legacy_grant_disabled', 'proxy_control_blocked',
      'proxy_control_not_controllable', 'split_tunneling_empty', 'connection_failed',
      'connectivity_check_failed', 'post_enable_check_failed', 'no_balancer_candidate',
      'all_candidates_quarantined', 'endpoint_quarantined', 'route-failure', 'success',
      'owner_live_auth_blocked', 'deadline_expired', 'operation_timeout',
      'desired_vpn_storage_read_failed', 'desired_vpn_commit_failed', 'proxy_cleanup_pending']),
    phase: new Set(['created', 'acquired', 'reading', 'capturing', 'applying', 'confirming', 'cleaning',
      'switching', 'settled', 'superseded', 'recovery', 'APPLYING', 'CONFIRMING']),
    state: new Set(['ON', 'OFF', 'CONNECTING']),
    splitMode: new Set(['all', 'only', 'include', 'exclude']),
    proxyControl: new Set(['not_controllable', 'controlled_by_other_extensions',
      'controllable_by_this_extension', 'controlled_by_this_extension']),
    operation: new Set(['enable', 'disable', 'switch', 'recovery', 'diagnostic']),
    stage: new Set(['auth', 'apply', 'confirmation', 'readback', 'connectivity', 'cleanup', 'schema',
      'preflight', 'proxy-apply', 'confirmation-budget', 'confirmation-204', 'confirmation-other',
      'quarantine-storage', 'storage', 'steady', 'steady-readback', 'auth-rejection']),
    browser: new Set(['Chrome', 'Edge', 'Chromium']),
    platform: new Set(['Windows', 'macOS', 'Linux', 'ChromeOS', 'Android'])
  };
  for (let status = 400; status <= 599; status++) sets.code.add(`http_${status}`);
  for (const code of ['proxy_session_denied', 'proxy_readback_timeout', 'proxy_readback_mismatch',
    'proxy_connecting_commit_failed', 'proxy_candidate_binding_unavailable', 'connection_timeout',
    'proxy_apply_failed', 'stale', 'https_proxy_unavailable', 'busy', 'not_started', 'skipped',
    'proxy_connectivity_failed', 'proxy_control_unavailable', 'proxy_candidate_failed', 'diagnostics_unavailable',
    'restored', 'restore_failed', 'interrupted', 'settings_changed', 'proxy_state_unavailable']) sets.code.add(code);
  // Product identifiers only. Neither catalog hostnames nor arbitrary strings are accepted.
  const serverKeys = new Set(['auto', 'auto_free']);
  for (const key of ['berlin', 'estonia', 'finland', 'frankfurt', 'latvia', 'netherlands',
    'poland', 'stockholm', 'usa', 'vienna']) {
    serverKeys.add(key);
    for (const suffix of ['backup', 'free', 'premium']) {
      serverKeys.add(`${key}_${suffix}`);
      for (let i = 1; i <= 100; i++) serverKeys.add(`${key}_${suffix}_${i}`);
    }
  }
  function read(value, key) {
    try {
      const descriptor = value && Object.getOwnPropertyDescriptor(value, key);
      return descriptor && Object.prototype.hasOwnProperty.call(descriptor, 'value') ? descriptor.value : undefined;
    } catch (_) { return undefined; }
  }
  function enumValue(value, set) { return set.has(value) ? value : 'unknown'; }
  function numeric(value, maximum = Number.MAX_SAFE_INTEGER) {
    return Number.isSafeInteger(value) && value >= 0 && value <= maximum ? value : undefined;
  }
  function selectFields(value, spec) {
    const result = {};
    for (const [key, transform] of Object.entries(spec)) {
      const input = read(value, key);
      if (input === undefined) continue;
      const safe = transform(input);
      if (safe !== undefined) result[key] = safe;
    }
    return result;
  }
  const asServer = value => enumValue(value, serverKeys);
  const asCode = value => enumValue(value, sets.code);
  const asState = value => enumValue(value, sets.state);
  const asBoolean = value => typeof value === 'boolean' ? value : undefined;
  function sanitizeEvent(input, timestamp) {
    const event = read(input, 'event');
    if (!sets.event.has(event)) return null;
    return { at: timestamp, event, ...selectFields(input, {
      code: asCode, server: asServer, state: asState,
      phase: value => enumValue(value, sets.phase), operation: value => enumValue(value, sets.operation),
      stage: value => enumValue(value, sets.stage),
      durationMs: value => numeric(value, 3600000), attempt: value => numeric(value, 1000000),
      httpStatus: value => value >= 100 ? numeric(value, 599) : undefined,
      revision: numeric, retryAt: numeric, proxyApplied: asBoolean, confirmed: asBoolean,
      success: asBoolean
    }) };
  }
  function sanitizeSnapshot(input) {
    return selectFields(input, {
      extensionVersion: value => typeof value === 'string' && /^\d{1,5}(\.\d{1,5}){1,3}$/.test(value) ? value : 'unknown',
      browser: value => enumValue(value, sets.browser), browserMajor: value => numeric(value, 10000),
      platform: value => enumValue(value, sets.platform),
      buttonState: asState, desiredVpnState: asState, reason: asCode,
      selectedServer: asServer, actualServer: asServer, desiredVpnRevision: numeric,
      splitMode: value => enumValue(value, sets.splitMode),
      proxyControl: value => enumValue(value, sets.proxyControl),
      phase: value => enumValue(value, sets.phase), recoveryCode: asCode,
      retryAttempt: value => numeric(value, 1000000), retryAt: numeric,
      proxystate: asBoolean, stateAvailable: asBoolean, snapshotConsistent: asBoolean
    });
  }

  function createRecorder({ now = Date.now } = {}) {
    let active = false;
    let events = [];
    const timestamp = () => { try { return numeric(now()) ?? 0; } catch (_) { return 0; } };
    return Object.freeze({
      start() { events = []; active = true; },
      finish() { active = false; },
      record(input) {
        try {
          if (!active) return;
          const row = sanitizeEvent(input, timestamp());
          if (row) events = [...events, row].slice(-MAX_EVENTS);
        } catch (_) { /* Diagnostics must not interrupt a VPN operation. */ }
      },
      report(snapshot) {
        return { schemaVersion: 2, generatedAt: timestamp(),
          snapshot: sanitizeSnapshot(snapshot), events: events.map(row => ({ ...row })) };
      }
    });
  }
  return Object.freeze({ STORAGE_KEY, createRecorder, sanitizeSnapshot, sanitizeEvent, asCode, asServer });
});
