# StreamLive VPN — Unified FlexVPN + FLOWVPN

## Что внутри
- FlexVPN — основной движок и серверные пулы.
- FLOWVPN — резервный API/session канал; включается автоматически, если основной Flex-канал не смог установить прокси.
- 90-минутный free timer сохраняется.
- Выбор стран и health-check Flex сохраняются.
- Название и UI переименованы в StreamLive VPN.
- Премиальные промо-блоки убраны из интерфейса; вместо них используется кнопка настроек.
- Добавлена локальная кастомизация обложки.
- В `flow_legacy/` сохранены исходные FLOWVPN файлы для совместимости/аудита.

## Установка
1. В Chrome откройте `chrome://extensions`.
2. Включите режим разработчика.
3. Нажмите «Загрузить распакованное».
4. Выберите папку, где лежит этот `manifest.json`.

## Важно
Резервный FLOWVPN использует API `api.open60m.ru` / `api2.open60m.ru` и может работать только для стран, которые этот API принимает (DE/NL/RU). Для остальных стран основной Flex-пул остаётся единственным каналом.

Расширение не пытается скрывать факт использования VPN или обходить сторонние anti-VPN системы.

### StreamLive allowlist
The extension adds the `X-StreamLive-VPN` marker for StreamLive hostnames through declarativeNetRequest. Copy `engine/includes/geo.php` into the engine if you use the provided geo guard. The marker is not cryptographic authentication; for stronger trust, validate VPN egress IPs server-side.
