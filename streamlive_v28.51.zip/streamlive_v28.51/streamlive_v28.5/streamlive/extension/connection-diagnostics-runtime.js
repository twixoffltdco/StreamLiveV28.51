(function(root, factory) {
  const core = typeof module !== 'undefined' && module.exports
    ? require('./connection-diagnostics.js') : root.FlexVpnConnectionDiagnostics;
  const api = factory(core);
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.FlexVpnConnectionDiagnosticsRuntime = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function(core) {
  'use strict';
  const CHECKS = ['settings', 'network', 'access', 'tunnel', 'restore'];
  const CHECK_STATUS = new Set(['pending', 'running', 'passed', 'failed', 'skipped']);
  const STATE_KEYS = ['buttonState', 'proxystate', 'desiredVpnState', 'desiredVpnRevision',
    'selectedServer', 'actualProxyServer', 'splitMode', 'proxyControlError', 'vpnRecoveryBlock', 'vpnReconnectV1'];

  function createRuntime({ chrome, now = Date.now, ioTimeoutMs = 2000,
    getOwner = () => null, getButtonState = () => 'OFF', userAgent = '', runTest }) {
    const recorder = core.createRecorder({ now });
    // Retire the old opt-in journal without loading or exporting its contents.
    try { chrome.storage.local.remove([core.STORAGE_KEY], () => { void chrome.runtime.lastError; }); } catch (_) {}
    let active = null;
    let test = { status: 'idle', checks: [] };
    const browserMatch = /\b(Edg|Chrome)\/(\d+)/.exec(userAgent);
    const environment = {
      browser: browserMatch ? browserMatch[1] === 'Edg' ? 'Edge' : 'Chrome' : 'Chromium',
      browserMajor: browserMatch ? Number(browserMatch[2]) : undefined,
      platform: /CrOS/.test(userAgent) ? 'ChromeOS' : /Android/.test(userAgent) ? 'Android'
        : /Windows/.test(userAgent) ? 'Windows' : /Macintosh/.test(userAgent) ? 'macOS'
          : /Linux/.test(userAgent) ? 'Linux' : 'unknown'
    };
    function readBounded(start) {
      return new Promise(resolve => {
        let settled = false;
        const deadline = setTimeout(() => finish(null), ioTimeoutMs);
        function finish(value) {
          if (settled) return;
          settled = true; clearTimeout(deadline); resolve(value);
        }
        try { start(value => finish(chrome.runtime.lastError ? null : value)); }
        catch (_) { finish(null); }
      });
    }
    let snapshotInFlight = null;
    function snapshot() {
      // Concurrent pages share reads; neither PAC data nor auth storage are exported.
      if (snapshotInFlight) return snapshotInFlight;
      snapshotInFlight = (async () => {
        const [state, proxy] = await Promise.all([
          readBounded(done => chrome.storage.local.get(STATE_KEYS, done)),
          readBounded(done => chrome.proxy.settings.get({ incognito: false }, done))
        ]);
        const owner = getOwner();
        return core.sanitizeSnapshot({
          ...environment, extensionVersion: chrome.runtime.getManifest().version,
          stateAvailable: state !== null,
          // Point-in-time observation, not a successful connectivity test.
          buttonState: state ? owner ? getButtonState() : state.buttonState : undefined,
          desiredVpnState: state?.desiredVpnState, desiredVpnRevision: state?.desiredVpnRevision,
          proxystate: state?.proxystate, selectedServer: state?.selectedServer,
          actualServer: state?.actualProxyServer, splitMode: state?.splitMode,
          reason: state?.proxyControlError || state?.vpnReconnectV1?.reason, recoveryCode: state?.vpnRecoveryBlock?.code,
          retryAttempt: state?.vpnReconnectV1?.attempt, retryAt: state?.vpnReconnectV1?.nextAttemptAt,
          phase: owner?.phase, proxyControl: proxy?.levelOfControl || 'unknown'
        });
      })().finally(() => { snapshotInFlight = null; });
      return snapshotInFlight;
    }
    const trusted = sender => Boolean(chrome.runtime.id && sender?.id === chrome.runtime.id &&
      sender?.url === chrome.runtime.getURL('diagnostics.html'));
    async function report() {
      return { ...recorder.report(await snapshot()), test: { ...test, checks: test.checks.map(row => ({ ...row })) } };
    }
    function step(run, value) {
      if (active !== run || !CHECKS.includes(value?.id) || !CHECK_STATUS.has(value.status)) return;
      const row = { id: value.id, status: value.status, code: core.asCode(value.code) };
      if (Number.isSafeInteger(value.durationMs) && value.durationMs >= 0 && value.durationMs <= 60000) row.durationMs = value.durationMs;
      if (value.server !== undefined) row.server = core.asServer(value.server);
      test.checks = test.checks.map(previous => previous.id === row.id ? row : previous);
    }
    function cancel(run) {
      if (!run || active !== run) return;
      test.status = 'cancelling';
      run.controller.abort();
    }
    function start(port) {
      if (active) return { ok: false, error: 'busy' };
      if (typeof runTest !== 'function') return { ok: false, error: 'diagnostics_unavailable' };
      const run = { port, controller: new AbortController() };
      active = run;
      recorder.start();
      test = { status: 'running', startedAt: now(), checks: CHECKS.map(id => ({ id, status: 'pending', code: 'not_started' })) };
      // The background bridge also has work and cleanup watchdogs. This abort
      // requests cleanup; it must not announce completion before restoration.
      const deadline = setTimeout(() => cancel(run), 30000);
      void Promise.resolve().then(() => runTest({ signal: run.controller.signal, onStep: value => step(run, value) }))
        .then(result => {
          if (active !== run) return;
          test.status = result?.restored !== true ? 'interrupted'
            : run.controller.signal.aborted ? 'cancelled' : 'complete';
          test.code = core.asCode(result?.code);
          test.restored = result?.restored === true;
        }, () => {
          if (active === run) { test.status = 'interrupted'; test.code = 'diagnostics_unavailable'; test.restored = false; }
        }).finally(() => {
          clearTimeout(deadline);
          if (active !== run) return;
          test.finishedAt = now();
          test.checks = test.checks.map(row => ['pending', 'running'].includes(row.status)
            ? { ...row, status: 'skipped', code: run.controller.signal.aborted ? 'cancelled' : 'skipped' } : row);
          recorder.finish();
          active = null;
        });
      return { ok: true };
    }
    return Object.freeze({
      record: recorder.record,
      handleMessage(request, sender, respond) {
        if (request?.action !== 'getConnectionDiagnostics') return false;
        const send = value => { try { respond(value); } catch (_) {} };
        if (!trusted(sender)) {
          send({ ok: false, error: 'not_allowed' });
          return true;
        }
        void report().then(value => send({ ok: true, report: value }), () => send({ ok: false, error: 'diagnostics_unavailable' }));
        return true;
      },
      handlePort(port) {
        if (port?.name !== 'connection-diagnostics' || !trusted(port.sender)) return false;
        let closed = false;
        const send = value => { if (!closed) { try { port.postMessage(value); } catch (_) {} } };
        const onMessage = request => {
          if (closed || !Number.isSafeInteger(request?.id) || request.id < 1) return;
          const id = request.id;
          if (request.action === 'startConnectionDiagnostics') { send({ id, ...start(port) }); return; }
          if (request.action === 'cancelConnectionDiagnostics') {
            const owned = active?.port === port;
            if (owned) cancel(active);
            send({ id, ok: owned }); return;
          }
          if (request.action === 'getConnectionDiagnostics') {
            void report().then(value => send({ id, ok: true, report: value }), () => send({ id, ok: false, error: 'diagnostics_unavailable' }));
          } else send({ id, ok: false, error: 'not_allowed' });
        };
        port.onMessage.addListener(onMessage);
        port.onDisconnect.addListener(() => {
          closed = true;
          port.onMessage.removeListener?.(onMessage);
          if (active?.port === port) cancel(active);
        });
        return true;
      }
    });
  }
  return Object.freeze({ createRuntime });
});
