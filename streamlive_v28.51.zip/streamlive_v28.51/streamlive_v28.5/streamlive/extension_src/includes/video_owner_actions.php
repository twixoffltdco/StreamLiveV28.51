<?php
/** Кнопки владельца на странице видео: удалить + статьи */
if (!function_exists('video_owner_actions_render')) {
  function video_owner_actions_render(?array $video, ?array $user): void {
    if (!$video || !$user) return;
    $uid = (int)$user['id'];
    $isOwner = (int)($video['user_id'] ?? 0) === $uid;
    $isAdmin = !empty($user['role']) && $user['role'] === 'admin';
    if (!$isOwner && !$isAdmin) {
      try {
        $st = db()->prepare('SELECT owner_id FROM channels WHERE id = ? LIMIT 1');
        $st->execute([(int)($video['channel_id'] ?? 0)]);
        $ch = $st->fetch();
        if ($ch && (int)$ch['owner_id'] === $uid) $isOwner = true;
      } catch (Throwable $e) {}
    }
    if (!$isOwner && !$isAdmin) return;
    $id = (int)$video['id'];
    $slug = rawurlencode((string)($video['slug'] ?? ''));
    echo '<div class="video-owner-actions" style="display:flex;flex-wrap:wrap;gap:8px;margin:12px 0">';
    echo '<a class="btn btn-danger" href="/video_delete.php?id=' . $id . '">Удалить видео</a>';
    echo '<a class="btn btn-ghost" href="/my_articles.php">Мои статьи</a>';
    echo '</div>';
  }
}
