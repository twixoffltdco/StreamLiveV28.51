<?php
if (!function_exists('channel_articles_panel_render')) {
  function channel_articles_panel_render(array $channel, ?array $user): void {
    if (!$user || empty($channel['id'])) return;
    if (is_file(__DIR__ . '/content_articles.php')) require_once __DIR__ . '/content_articles.php';
    content_articles_ensure_table();
    $cid = (int)$channel['id'];
    $list = [];
    try {
      $st = db()->prepare(
        "SELECT * FROM content_articles WHERE channel_id = ? ORDER BY created_at DESC LIMIT 50"
      );
      $st->execute([$cid]);
      $list = $st->fetchAll() ?: [];
    } catch (Throwable $e) {}
    $defaultCover = trim((string)($channel['logo_url'] ?? ''));
    ?>
    <div class="form-card form-wide" id="channel-articles" style="margin-top:24px">
      <h2>Статьи канала</h2>
      <p style="color:var(--text-dim);font-size:13px;margin:0 0 14px">
        Как в Дзене: статья открывается в окне на сайте. Без галочки — на модерации до одобрения.
      </p>
      <form method="POST" action="/channel_manage.php?id=<?= $cid ?>#channel-articles">
        <?= function_exists('csrf_field') ? csrf_field() : '' ?>
        <input type="hidden" name="action" value="create_article">
        <label>Заголовок</label>
        <input type="text" name="title" required maxlength="255" placeholder="Заголовок статьи">
        <label>Текст</label>
        <textarea name="body" required rows="8" placeholder="Текст статьи…"></textarea>
        <label>Обложка URL</label>
        <input type="url" name="cover_url" value="<?= htmlspecialchars($defaultCover, ENT_QUOTES, 'UTF-8') ?>" placeholder="https://...">
        <button type="submit" class="btn btn-primary" style="margin-top:12px">Опубликовать статью</button>
      </form>

      <?php if ($list): ?>
      <h3 style="margin-top:22px;font-size:1rem">Ваши статьи (<?= count($list) ?>)</h3>
      <ul style="list-style:none;padding:0;margin:0">
        <?php foreach ($list as $a): ?>
        <li style="padding:12px 0;border-bottom:1px solid var(--border,#243049);display:flex;gap:12px;align-items:flex-start;flex-wrap:wrap">
          <?php if (!empty($a['cover_url'])): ?>
            <img src="<?= htmlspecialchars($a['cover_url'], ENT_QUOTES, 'UTF-8') ?>" alt="" style="width:72px;height:48px;object-fit:cover;border-radius:8px">
          <?php endif; ?>
          <div style="flex:1;min-width:160px">
            <strong><?= htmlspecialchars($a['title'], ENT_QUOTES, 'UTF-8') ?></strong>
            <div style="font-size:12px;opacity:.65;margin-top:4px">
              <?= htmlspecialchars($a['status'], ENT_QUOTES, 'UTF-8') ?> · <?= htmlspecialchars($a['created_at'], ENT_QUOTES, 'UTF-8') ?>
              · <?= (int)($a['views'] ?? 0) ?> просм.
            </div>
          </div>
          <button type="button" class="btn btn-ghost dz-open-article" data-id="<?= (int)$a['id'] ?>" style="font-size:12px">Смотреть</button>
          <form method="POST" action="/channel_manage.php?id=<?= $cid ?>#channel-articles" style="display:inline" onsubmit="return confirm('Удалить статью?');">
            <?= function_exists('csrf_field') ? csrf_field() : '' ?>
            <input type="hidden" name="action" value="delete_article">
            <input type="hidden" name="article_id" value="<?= (int)$a['id'] ?>">
            <button type="submit" class="btn btn-danger" style="font-size:12px">Удалить</button>
          </form>
        </li>
        <?php endforeach; ?>
      </ul>
      <?php else: ?>
      <p style="color:var(--text-dim);font-size:13px;margin-top:16px">Статей пока нет.</p>
      <?php endif; ?>
    </div>
    <?php
    // modal assets once
    if (empty($GLOBALS['__dz_article_modal'])) {
      $GLOBALS['__dz_article_modal'] = true;
      echo '<link rel="stylesheet" href="/assets/css/dzen-article-modal.css?v=1">';
      echo '<script src="/assets/js/dzen-article-modal.js?v=1" defer></script>';
      echo '<div id="dz-article-modal" class="dz-modal" hidden><div class="dz-modal__backdrop" data-dz-close></div><div class="dz-modal__sheet" role="dialog"><button type="button" class="dz-modal__x" data-dz-close aria-label="Закрыть">×</button><div class="dz-modal__body" id="dz-article-body">Загрузка…</div></div></div>';
    }
  }
}
