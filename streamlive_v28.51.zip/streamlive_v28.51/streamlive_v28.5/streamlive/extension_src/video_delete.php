<?php
require_once __DIR__ . '/includes/header.php';
require_login();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$slug = trim((string)($_GET['slug'] ?? $_POST['slug'] ?? ''));

try {
  if ($id > 0) {
    $st = db()->prepare('SELECT * FROM videos WHERE id = ? LIMIT 1');
    $st->execute([$id]);
  } elseif ($slug !== '') {
    $st = db()->prepare('SELECT * FROM videos WHERE slug = ? LIMIT 1');
    $st->execute([$slug]);
  } else {
    flash_set('error', 'Не указано видео');
    redirect('/videos.php');
  }
  $video = $st->fetch();
} catch (Throwable $e) {
  $video = null;
}

if (!$video) {
  flash_set('error', 'Видео не найдено');
  redirect('/videos.php');
}

$isOwner = (int)($video['user_id'] ?? 0) === (int)$__user['id'];
$isAdmin = !empty($__user['role']) && $__user['role'] === 'admin';
// also channel owner
if (!$isOwner && !$isAdmin) {
  try {
    $st = db()->prepare('SELECT owner_id FROM channels WHERE id = ? LIMIT 1');
    $st->execute([(int)$video['channel_id']]);
    $ch = $st->fetch();
    if ($ch && (int)$ch['owner_id'] === (int)$__user['id']) $isOwner = true;
  } catch (Throwable $e) {}
}

if (!$isOwner && !$isAdmin) {
  flash_set('error', 'Нет прав на удаление');
  redirect('/video.php?slug=' . rawurlencode((string)$video['slug']));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try { csrf_verify(); } catch (Throwable $e) {
    flash_set('error', 'CSRF');
    redirect('/video_delete.php?id=' . (int)$video['id']);
  }
  try {
    // soft delete if column exists, else hard
    try {
      db()->prepare("UPDATE videos SET status='deleted' WHERE id=?")->execute([(int)$video['id']]);
    } catch (Throwable $e) {
      db()->prepare('DELETE FROM videos WHERE id=?')->execute([(int)$video['id']]);
    }
    // linked articles optional cleanup
    try {
      db()->prepare('DELETE FROM content_articles WHERE video_id=?')->execute([(int)$video['id']]);
    } catch (Throwable $e) {}
    flash_set('success', 'Видео удалено');
  } catch (Throwable $e) {
    flash_set('error', 'Не удалось удалить: ' . $e->getMessage());
  }
  redirect('/videos.php');
}

$pageTitle = 'Удалить видео';
?>
<div class="container">
  <div class="form-card form-wide">
    <h2>Удалить видео?</h2>
    <p><strong><?= e($video['title'] ?? '') ?></strong></p>
    <p style="color:var(--text-dim);font-size:13px">Действие необратимо. Связанные статьи видео тоже будут удалены.</p>
    <form method="POST">
      <?= function_exists('csrf_field') ? csrf_field() : '' ?>
      <input type="hidden" name="id" value="<?= (int)$video['id'] ?>">
      <button type="submit" class="btn btn-danger">Удалить навсегда</button>
      <a class="btn btn-ghost" href="/video.php?slug=<?= e(urlencode((string)$video['slug'])) ?>">Отмена</a>
    </form>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
