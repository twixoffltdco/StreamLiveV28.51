<?php
header('Content-Type: text/plain; charset=utf-8');
echo "forum_ping_ok\n";
echo "php=" . PHP_VERSION . "\n";
echo "file=" . __FILE__ . "\n";
if (is_file(__DIR__ . '/forum.php')) echo "forum.php=exists\n";
else echo "forum.php=MISSING\n";
