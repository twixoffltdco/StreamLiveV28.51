<?php
// Редирект на channel.php (старые ссылки)
$slug = isset($_GET['slug']) ? (string)$_GET['slug'] : '';
$id = isset($_GET['id']) ? (string)$_GET['id'] : '';
$q = [];
if ($slug !== '') $q[] = 'slug=' . rawurlencode($slug);
if ($id !== '') $q[] = 'id=' . rawurlencode($id);
header('Location: /channel.php' . ($q ? ('?' . implode('&', $q)) : ''), true, 301);
exit;
