<?php
/**
 * Embed канала.
 * Браузер → cinema-лендинг (как by-badr).
 * iframe / ?cinema=0 / ?raw=1 → чистый плеер.
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
if (is_file(__DIR__ . '/includes/paid_access.php')) require_once __DIR__ . '/includes/paid_access.php';
if (is_file(__DIR__ . '/includes/cinema_landing.php')) require_once __DIR__ . '/includes/cinema_landing.php';
if (is_file(__DIR__ . '/includes/content_articles.php')) require_once __DIR__ . '/includes/content_articles.php';

if (is_file(__DIR__ . '/includes/verified_moderation.php')) {
  require_once __DIR__ . '/includes/verified_moderation.php';
  if (function_exists('verified_try_flush_current_user')) verified_try_flush_current_user();
}


$slug = trim((string)($_GET['slug'] ?? ''));
$stmt = db()->prepare("SELECT * FROM channels WHERE slug = ? AND status = 'approved'");
$stmt->execute([$slug]);
$channel = $stmt->fetch();

if (!$channel) {
  http_response_code(404);
  header('Content-Type: text/html; charset=utf-8');
  echo '<!DOCTYPE html><html><body style="margin:0;background:#000;color:#888;font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh">Канал недоступен</body></html>';
  exit;
}

$__user = function_exists('current_user') ? current_user() : null;
if ($__user && function_exists('is_user_banned_on_channel') && is_user_banned_on_channel($channel['id'], $__user['id'])) {
  http_response_code(403);
  echo 'УВЫ, ВАС ЗАБЛОКИРОВАЛИ';
  exit;
}

if (function_exists('paid_channel_is_paid') && paid_channel_is_paid($channel)) {
  if (!(function_exists('paid_user_can_watch') && paid_user_can_watch($__user, $channel))) {
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Платный канал</title></head><body style="margin:0;background:#0b1220;color:#eee;font-family:system-ui;display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center;padding:24px"><div><h1 style="font-size:1.15rem;margin:0 0 8px">Платный контент</h1><p style="opacity:.7;margin:0">Встраивание недоступно. Откройте канал на сайте.</p></div></body></html>';
    exit;
  }
}

if (is_file(__DIR__ . '/includes/content_views.php')) require_once __DIR__ . '/includes/content_views.php';
if (function_exists('content_view_register')) {
  content_view_register('channel', (int)$channel['id']);
} else {
  try { db()->prepare('UPDATE channels SET views = COALESCE(views,0) + 1 WHERE id = ?')->execute([(int)$channel['id']]); } catch (Throwable $e) {}
}

$activeSource = function_exists('resolve_active_source') ? resolve_active_source($channel) : null;
$isRaw = function_exists('cinema_is_raw_player') ? cinema_is_raw_player() : (isset($_GET['cinema']) && (string)$_GET['cinema'] === '0');

/* ===== CINEMA LANDING (основной вид) ===== */
if (!$isRaw && function_exists('cinema_render_page')) {
  $__desc = trim((string)($channel['description'] ?? $channel['about'] ?? ''));
  $__now = $activeSource
    ? trim((string)($activeSource['program_title'] ?? $activeSource['source_name'] ?? 'Прямой эфир'))
    : 'Эфир недоступен';
  $articles = function_exists('content_articles_list')
    ? content_articles_list((int)$channel['id'], null, 24, true)
    : [];
  $playerHtml = '<iframe src="/embed.php?slug=' . rawurlencode((string)$channel['slug']) . '&cinema=0" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen style="width:100%;height:100%;border:0"></iframe>';
  cinema_render_page([
    'title' => (string)$channel['title'],
    'description' => $__desc,
    'primary_url' => '/channel-pc.php?slug=' . rawurlencode((string)$channel['slug']),
    'player_html' => $playerHtml,
    'articles' => $articles,
    'badge' => $activeSource ? 'В эфире' : '',
    'now_line' => 'Сейчас: <b>' . htmlspecialchars($__now, ENT_QUOTES, 'UTF-8') . '</b>',
  ]);
  exit;
}

/* ===== RAW PLAYER (iframe / cinema=0) ===== */
$srcUrl = '';
$srcType = '';
if ($activeSource) {
  $srcUrl = (string)($activeSource['url'] ?? $activeSource['stream_url'] ?? '');
  $srcType = strtolower((string)($activeSource['type'] ?? $activeSource['source_type'] ?? ''));
}
header('Content-Type: text/html; charset=utf-8');
header('X-Frame-Options: ALLOWALL');
@header_remove('X-Frame-Options');
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars((string)$channel['title'], ENT_QUOTES, 'UTF-8') ?></title>
<style>
html,body{margin:0;padding:0;width:100%;height:100%;background:#000;overflow:hidden}
#playerjs-container,iframe,video{position:absolute;inset:0;width:100%;height:100%;border:0;object-fit:contain}
</style>
</head>
<body>
<div id="playerjs-container"></div>
<?php if (!empty($channel['logo_url'])): ?>
<img src="<?= htmlspecialchars((string)$channel['logo_url'], ENT_QUOTES, 'UTF-8') ?>" alt="" style="position:absolute;bottom:10px;right:10px;width:36px;height:36px;border-radius:10px;opacity:.85;z-index:5;pointer-events:none">
<?php endif; ?>
<script src="/playerjs.js"></script>
<script>
(function () {
  var src = <?= json_encode($srcUrl, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
  var type = <?= json_encode($srcType, JSON_UNESCAPED_SLASHES) ?>;
  var el = document.getElementById('playerjs-container');
  if (!src) {
    el.innerHTML = '<div style="color:#666;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100%">Нет источника</div>';
    return;
  }
  if (typeof Playerjs !== 'undefined') {
    try {
      new Playerjs({ id: 'playerjs-container', file: src, autoplay: 1 });
      return;
    } catch (e) {}
  }
  if (/\.m3u8($|\?)/i.test(src) || type === 'hls') {
    var v = document.createElement('video');
    v.controls = true; v.autoplay = true; v.playsInline = true;
    v.style.cssText = 'width:100%;height:100%;object-fit:contain;background:#000';
    el.appendChild(v);
    var s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/hls.js@1.5.15/dist/hls.min.js';
    s.onload = function () {
      if (window.Hls && Hls.isSupported()) { var h = new Hls(); h.loadSource(src); h.attachMedia(v); }
      else { v.src = src; }
    };
    document.head.appendChild(s);
    return;
  }
  if (/^https?:\/\//i.test(src) && (type === 'iframe' || /youtube|twitch|vk\.com|ok\.ru|rutube/i.test(src))) {
    var f = document.createElement('iframe');
    f.src = src; f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen'; f.allowFullscreen = true;
    f.style.cssText = 'width:100%;height:100%;border:0';
    el.appendChild(f);
    return;
  }
  var v2 = document.createElement('video');
  v2.src = src; v2.controls = true; v2.autoplay = true; v2.playsInline = true;
  v2.style.cssText = 'width:100%;height:100%;object-fit:contain;background:#000';
  el.appendChild(v2);
})();
</script>

<?php
$__embedArticles = [];
if (function_exists('content_articles_list') && !empty($channel['id'])) {
  $__embedArticles = content_articles_list((int)$channel['id'], null, 12, true);
}
if (!empty($__embedArticles)): ?>
<div class="embed-articles" style="padding:12px;background:#0f0f14;color:#eee;font-family:system-ui,sans-serif">
  <div style="font-weight:700;margin-bottom:10px;font-size:14px">Статьи</div>
  <div style="display:grid;gap:8px">
    <?php foreach ($__embedArticles as $__a): ?>
    <a href="/article.php?id=<?= (int)$__a['id'] ?>" target="_blank" rel="noopener" style="color:#c4b5fd;text-decoration:none;font-size:13px">
      <?= htmlspecialchars((string)$__a['title'], ENT_QUOTES, 'UTF-8') ?>
      <span style="opacity:.55;font-size:11px"> · <?= (int)($__a['views'] ?? 0) ?></span>
    </a>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

</body>
</html>
