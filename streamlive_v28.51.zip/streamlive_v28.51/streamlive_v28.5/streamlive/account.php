<?php
/**
 * Совместимость: /account.php → кабинет
 * Реального account.php в корне нет → 404-заглушка хоста.
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
$u = function_exists('current_user') ? current_user() : null;
if (!$u) {
  $next = '/account.php';
  header('Location: /auth/login.php?next=' . rawurlencode($next), true, 302);
  exit;
}
// приоритет: dashboard → account_settings → profile
if (is_file(__DIR__ . '/dashboard.php')) {
  header('Location: /dashboard.php', true, 302);
  exit;
}
if (is_file(__DIR__ . '/account_settings.php')) {
  header('Location: /account_settings.php', true, 302);
  exit;
}
$uname = (string)($u['username'] ?? '');
header('Location: /profile.php?username=' . rawurlencode($uname), true, 302);
exit;
