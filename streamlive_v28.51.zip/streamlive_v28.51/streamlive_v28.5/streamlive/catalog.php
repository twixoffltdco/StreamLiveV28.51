<?php
require_once __DIR__ . '/includes/header.php';

/* Рекомендации: и каналы, и видео */
$__recChannels = [];
$__recVideos = [];
try {
  if (function_exists('recommended_channels')) {
    $__recChannels = recommended_channels(function_exists('current_user') ? current_user() : null, null, 12);
  }
} catch (Throwable $e) {}
try {
  if (is_file(__DIR__ . '/includes/recommendations.php')) require_once __DIR__ . '/includes/recommendations.php';
  if (function_exists('get_recommended_videos')) {
    $__recVideos = get_recommended_videos(0, 12);
  }
} catch (Throwable $e) {}
?>
<?php if (!empty($__recChannels)): ?>
<section class="container" style="padding-top:16px">
  <h2 style="font-size:18px;margin:0 0 12px">Рекомендуемые каналы</h2>
  <div class="grid">
    <?php foreach ($__recChannels as $c): ?>
      <a class="card" href="/channel.php?slug=<?= e($c['slug']) ?>">
        <div class="card-thumb">
          <span class="badge-live"><?= (($c['type'] ?? '') === 'radio') ? 'РАДИО' : 'LIVE' ?></span>
          <?php if (!empty($c['logo_url'])): ?><img src="<?= e($c['logo_url']) ?>" alt=""><?php endif; ?>
        </div>
        <div class="card-body">
          <p class="card-title"><?= e($c['title'] ?? '') ?></p>
          <p class="card-meta"><?= (int)($c['views'] ?? 0) ?> просмотров</p>
        </div>
      </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>
<?php if (!empty($__recVideos)): ?>
<section class="container" style="padding-top:8px">
  <h2 style="font-size:18px;margin:0 0 12px">Рекомендуемые видео</h2>
  <div class="grid">
    <?php foreach ($__recVideos as $v): ?>
      <a class="card" href="/video.php?slug=<?= e($v['slug'] ?? '') ?>">
        <div class="card-thumb">
          <?php if (!empty($v['thumbnail_url'])): ?><img src="<?= e($v['thumbnail_url']) ?>" alt=""><?php endif; ?>
        </div>
        <div class="card-body">
          <p class="card-title"><?= e($v['title'] ?? '') ?></p>
          <p class="card-meta"><?= (int)($v['views_count'] ?? $v['views'] ?? 0) ?> просм.<?= !empty($v['channel_title']) ? ' · ' . e($v['channel_title']) : '' ?></p>
        </div>
      </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>
<?php

$type = $_GET['type'] ?? null;
$type = in_array($type, ['tv', 'radio'], true) ? $type : null;

$sql = "SELECT id, slug, title, logo_url, type, views FROM channels WHERE status = 'approved'";
$params = [];
if ($type) { $sql .= ' AND type = ?'; $params[] = $type; }
$sql .= ' ORDER BY views DESC, created_at DESC LIMIT 60';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$channels = $stmt->fetchAll();
?>
<div class="container">
  <div class="type-tabs">
    <a href="/catalog.php?type=tv" class="<?= $type === 'tv' ? 'active' : '' ?>">Телеканалы</a>
    <a href="/catalog.php?type=radio" class="<?= $type === 'radio' ? 'active' : '' ?>">Радио</a>
    <a href="/shorts.php" class="btn btn-outline btn-sm" style="margin-left:8px">▶ Shorts</a>
  </div>

  <?php if (empty($channels)): ?>
    <div class="empty-state">Пока тут пусто. Будь первым, кто запустит канал.</div>
  <?php else: ?>
  <div class="grid">
    <?php foreach ($channels as $c): ?>
      <a class="card" href="/channel.php?slug=<?= e($c['slug']) ?>">
        <div class="card-thumb">
          <span class="badge-live"><?= $c['type'] === 'radio' ? 'РАДИО' : 'LIVE' ?></span>
          <?php if ($c['logo_url']): ?><img src="<?= e($c['logo_url']) ?>" alt="<?= e($c['title']) ?>"><?php endif; ?>
        </div>
        <div class="card-body">
          <p class="card-title"><?= e($c['title']) ?></p>
          <p class="card-meta"><?= (int)$c['views'] ?> просмотров</p>
        </div>
      </a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
