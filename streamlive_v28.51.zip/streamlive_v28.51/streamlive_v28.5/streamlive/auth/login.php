<?php
$pageTitle = 'Вход';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/totp.php';
$__user = current_user();

if (isset($_GET['next'])) {
  $_SESSION['login_next'] = normalize_auth_redirect_target($_GET['next'], '/dashboard.php');
}
if ($__user) redirect(safe_after_login_redirect());

$error = '';
$mode = $_POST['mode'] ?? 'password'; // password | totp_only

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if ($mode === 'totp_only') {
    // Вход: логин + код 2FA (без пароля) — только если 2FA включена
    $login = trim((string)($_POST['login'] ?? ''));
    $code = preg_replace('/\s+/', '', (string)($_POST['code'] ?? ''));
    $user = null;
    foreach (['username', 'email'] as $col) {
      try {
        $st = db()->prepare("SELECT * FROM users WHERE {$col} = ? LIMIT 1");
        $st->execute([$login]);
        $user = $st->fetch() ?: null;
        if ($user) break;
      } catch (Throwable $e) {}
    }
    if (!$user) {
      try {
        $st = db()->prepare('SELECT * FROM users WHERE LOWER(email)=LOWER(?) OR username=? LIMIT 1');
        $st->execute([$login, $login]);
        $user = $st->fetch() ?: null;
      } catch (Throwable $e) {}
    }
    if (!$user || empty($user['totp_enabled']) || empty($user['totp_secret'])) {
      $error = 'Нужен аккаунт с включённой 2FA, либо войдите паролем.';
    } elseif (!empty($user['is_banned'])) {
      $error = 'Аккаунт заблокирован';
    } elseif (!Totp::verify($user['totp_secret'], $code)) {
      $error = 'Неверный код 2FA. Проверьте время на телефоне.';
    } else {
      login_user((int)$user['id']);
      try { db()->prepare('UPDATE users SET last_seen=NOW() WHERE id=?')->execute([(int)$user['id']]); } catch (Throwable $e) {}
      redirect(safe_after_login_redirect());
    }
  } else {
    $login = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $user = null;
    if (function_exists('normalize_phone')) {
      $np = normalize_phone($login);
      if ($np) {
        try {
          $st = db()->prepare('SELECT * FROM users WHERE phone=? LIMIT 1');
          $st->execute([$np]);
          $user = $st->fetch() ?: null;
        } catch (Throwable $e) {}
      }
    }
    if (!$user && filter_var($login, FILTER_VALIDATE_EMAIL)) {
      try {
        $st = db()->prepare('SELECT * FROM users WHERE email=? OR LOWER(email)=LOWER(?) LIMIT 1');
        $st->execute([$login, $login]);
        $user = $st->fetch() ?: null;
      } catch (Throwable $e) {}
    }
    if (!$user) {
      try {
        $st = db()->prepare('SELECT * FROM users WHERE username=? LIMIT 1');
        $st->execute([$login]);
        $user = $st->fetch() ?: null;
      } catch (Throwable $e) {}
    }
    if (!$user && preg_match('/^\+?\d[\d\s\-]{8,}$/', $login)) {
      $clean = preg_replace('/[^\d+]/', '', $login);
      if ($clean[0] !== '+') $clean = '+' . $clean;
      try {
        $st = db()->prepare('SELECT * FROM users WHERE phone=? LIMIT 1');
        $st->execute([$clean]);
        $user = $st->fetch() ?: null;
      } catch (Throwable $e) {}
    }

    if (!$user || empty($user['password_hash']) || !password_verify($password, $user['password_hash'])) {
      $error = 'Неверный логин или пароль';
    } elseif (!empty($user['is_banned'])) {
      $error = 'Аккаунт заблокирован';
    } else {
      $_SESSION['login_next'] = safe_after_login_redirect();
      $user2fa = !empty($user['totp_enabled']) && !empty($user['totp_secret']);
      $force2fa = function_exists('get_setting') && get_setting('force_2fa_enabled', '0') === '1';
      if ($user2fa || $force2fa) {
        $_SESSION['pending_2fa_user_id'] = (int)$user['id'];
        $token = make_2fa_token((int)$user['id']);
        redirect(($user2fa ? '/auth/2fa_verify.php' : '/auth/2fa_setup.php') . '?t=' . urlencode($token));
      }
      login_user((int)$user['id']);
      try { db()->prepare('UPDATE users SET last_seen=NOW() WHERE id=?')->execute([(int)$user['id']]); } catch (Throwable $e) {}
      redirect(safe_after_login_redirect());
    }
  }
}

$providers = [];
try {
  $providers = db()->query('SELECT name, display_name, icon_url FROM oauth_providers WHERE enabled = 1')->fetchAll() ?: [];
} catch (Throwable $e) {}

require_once __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <div class="form-card">
    <h2>Вход в аккаунт</h2>
    <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

    <form method="POST" action="/auth/login.php<?= !empty($_GET['next'])?'?next='.rawurlencode((string)$_GET['next']):'' ?>">
      <input type="hidden" name="mode" value="password">
      <label>Email, логин или телефон</label>
      <input type="text" name="email" required autocomplete="username" placeholder="you@mail.com / nick / +7999…">
      <label>Пароль</label>
      <input type="password" name="password" required autocomplete="current-password">
      <button class="btn btn-primary" style="margin-top:20px;width:100%" type="submit">Войти → далее 2FA если включена</button>
    </form>

    <hr style="margin:22px 0;border:none;border-top:1px solid rgba(255,255,255,.08)">
    <h3 style="font-size:15px;margin:0 0 10px">Или только код 2FA</h3>
    <p style="font-size:12px;opacity:.65;margin:0 0 10px">Логин + код из Google Authenticator (без пароля). Работает только если 2FA уже включена.</p>
    <form method="POST">
      <input type="hidden" name="mode" value="totp_only">
      <label>Логин или email</label>
      <input type="text" name="login" required>
      <label>Код 2FA</label>
      <input type="text" name="code" inputmode="numeric" pattern="[0-9 ]{6,8}" required placeholder="123456" autocomplete="one-time-code">
      <button class="btn btn-outline" style="margin-top:12px;width:100%" type="submit">Войти по 2FA</button>
    </form>

    <?php if ($providers): ?>
      <div class="oauth-row" style="margin-top:16px">
        <?php foreach ($providers as $p): ?>
          <a class="oauth-btn" href="/auth/oauth_start.php?provider=<?= e($p['name']) ?>"><?= e($p['display_name'] ?? $p['name']) ?></a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    <p style="margin-top:18px;font-size:13px;color:var(--text-dim)">Нет аккаунта? <a href="/auth/register.php">Регистрация</a> · <a href="/auth/2fa_setup.php">Настроить 2FA</a></p>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
