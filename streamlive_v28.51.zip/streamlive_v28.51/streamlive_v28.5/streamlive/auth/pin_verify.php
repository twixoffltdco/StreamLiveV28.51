<?php
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/auth_protect.php';
auth_check_pin_timeout();

if (empty($_SESSION['auth_pin_user_id'])) {
  redirect('/auth/login.php');
}
$error = '';
$left = max(0, (int)($_SESSION['auth_pin_deadline'] ?? time()) - time());
$displayPin = $_SESSION['auth_pin_display'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $pin = (string)($_POST['pin'] ?? '');
  $uid = auth_verify_pin($pin);
  if ($uid) {
    $need2fa = !empty($_SESSION['auth_after_pin_need_2fa']);
    unset($_SESSION['auth_after_pin_need_2fa']);
    if (!$need2fa) {
      try {
        $st = db()->prepare('SELECT totp_enabled, totp_secret FROM users WHERE id=?');
        $st->execute([$uid]);
        $u = $st->fetch();
        $need2fa = $u && !empty($u['totp_enabled']) && !empty($u['totp_secret']);
      } catch (Throwable $e) {}
    }
    if ($need2fa) {
      $_SESSION['pending_2fa_user_id'] = $uid;
      redirect('/auth/2fa_verify.php?t=' . urlencode(make_2fa_token($uid)));
    }
    login_user($uid);
    try { db()->prepare('UPDATE users SET last_seen=NOW() WHERE id=?')->execute([$uid]); } catch (Throwable $e) {}
    redirect(function_exists('safe_after_login_redirect') ? safe_after_login_redirect() : '/');
  }
  if (auth_is_locked()) {
    $error = 'Вход и регистрация заблокированы на 100 часов (не успели ввести PIN за 30 сек).';
  } else {
    $error = 'Неверный PIN или время вышло.';
    $left = max(0, (int)($_SESSION['auth_pin_deadline'] ?? time()) - time());
  }
}

$pageTitle = 'PIN подтверждение';
require_once dirname(__DIR__) . '/includes/header.php';
?>
<div class="container" style="max-width:400px;margin:40px auto">
  <div class="form-card">
    <h2>Подтверждение входа</h2>
    <p style="font-size:13px;opacity:.75">Введите PIN в течение <b id="pin-timer"><?= (int)$left ?></b> сек. Иначе вход/регистрация блокируются на 100 часов с вашего IP.</p>
    <?php if ($displayPin): ?>
      <p style="font-size:28px;font-weight:900;letter-spacing:.2em;text-align:center;margin:16px 0"><?= htmlspecialchars($displayPin, ENT_QUOTES, 'UTF-8') ?></p>
      <p style="font-size:11px;opacity:.5;text-align:center">Этот код показывается один раз на экране</p>
    <?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
    <form method="post">
      <label>PIN</label>
      <input name="pin" inputmode="numeric" pattern="[0-9]{6}" required autocomplete="one-time-code" style="font-size:22px;letter-spacing:.15em;text-align:center">
      <button class="btn btn-primary" style="width:100%;margin-top:14px" type="submit">Подтвердить</button>
    </form>
  </div>
</div>
<script>
(function(){
  var t=document.getElementById('pin-timer'); if(!t) return;
  var s=parseInt(t.textContent,10)||0;
  var iv=setInterval(function(){
    s--; if(s<0){ clearInterval(iv); t.textContent='0'; return; }
    t.textContent=String(s);
  },1000);
})();
</script>
<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
