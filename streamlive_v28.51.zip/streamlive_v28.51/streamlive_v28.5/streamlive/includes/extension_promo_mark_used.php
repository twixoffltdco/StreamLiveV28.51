<?php
/**
 * Пометить extension-промокод как активированный.
 * Вызывать из partners_activate / paid_activate_code.
 */
if (!function_exists('extension_promo_mark_used')) {
  function extension_promo_mark_used(string $code, ?int $userId = null): void {
    $code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $code) ?? '');
    if ($code === '') {
      return;
    }
    try {
      if ($userId) {
        db()->prepare(
          'UPDATE extension_promos SET used = 1, used_at = NOW() WHERE code = ? AND (user_id = ? OR user_id > 0) AND used = 0'
        )->execute([$code, $userId]);
      } else {
        db()->prepare(
          'UPDATE extension_promos SET used = 1, used_at = NOW() WHERE code = ? AND used = 0'
        )->execute([$code]);
      }
    } catch (Throwable $e) {
    }
  }
}
