<?php
/**
 * Начисление автору за платный просмотр статьи → wallet
 * Подключить в article.php после успешной оплаты/доступа:
 * require_once __DIR__.'/includes/wallet_articles.php';
 * articles_credit_author_on_purchase($articleId, $buyerId, $amountRub);
 */
if (!function_exists('articles_credit_author_on_purchase')) {
  function articles_credit_author_on_purchase(int $articleId, int $buyerId, float $amountRub): bool {
    if ($amountRub <= 0) return false;
    try {
      if (!function_exists('wallet_credit') && is_file(__DIR__ . '/wallet.php')) {
        require_once __DIR__ . '/wallet.php';
      }
      if (!function_exists('wallet_credit')) return false;
      $st = db()->prepare('SELECT user_id, title FROM articles WHERE id = ?');
      $st->execute([$articleId]);
      $a = $st->fetch();
      if (!$a) return false;
      $authorId = (int)$a['user_id'];
      if ($authorId === $buyerId) return false;
      // 80% автору
      $credit = round($amountRub * 0.8, 2);
      return wallet_credit($authorId, $credit, 'article_sale', 'Статья: ' . ($a['title'] ?? $articleId));
    } catch (Throwable $e) {
      return false;
    }
  }
}
