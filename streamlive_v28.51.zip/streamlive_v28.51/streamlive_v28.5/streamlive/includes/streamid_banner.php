<?php
/** Баннер в шапке: подтвердите телефон / email → StreamID */
function streamid_header_banner(?array $user): string {
  if (!$user || empty($user['id'])) return '';
  if (!is_file(__DIR__ . '/streamid.php')) return '';
  require_once __DIR__ . '/streamid.php';
  try { streamid_ensure(); } catch (Throwable $e) { return ''; }
  $sid = [];
  try { $sid = streamid_get((int)$user['id']); } catch (Throwable $e) { return ''; }
  $bits = [];
  $phone = trim((string)($sid['phone'] ?? $user['phone'] ?? ''));
  $email = trim((string)($user['email'] ?? ''));
  if ($phone === '') $bits[] = 'укажите номер телефона';
  elseif (empty($sid['phone_confirmed'])) $bits[] = 'подтвердите номер ' . htmlspecialchars($phone, ENT_QUOTES, 'UTF-8');
  if ($email === '') $bits[] = 'укажите email';
  $fn = trim((string)($sid['first_name'] ?? ''));
  $ln = trim((string)($sid['last_name'] ?? ''));
  if ($fn === '' || $ln === '') $bits[] = 'укажите имя и фамилию';
  if (!$bits) return '';
  $text = 'StreamID: ' . implode(', ', $bits);
  return '<div class="sid-head-banner" style="background:linear-gradient(90deg,#4c1d95,#1e3a5f);color:#fff;padding:8px 14px;font-size:13px;display:flex;justify-content:space-between;align-items:center;gap:12px">'
    . '<span>' . $text . '</span>'
    . '<a href="/streamid/" style="color:#fff;font-weight:700;text-decoration:underline;white-space:nowrap">Открыть StreamID →</a>'
    . '</div>';
}
