<?php
/**
 * Единый рендер префикса — везде, где показывается ник/тема.
 * require_once в header.php или functions.php один раз.
 */
if (!function_exists('user_render_prefix_html')) {
  function user_render_prefix_html($prefixOrUser): string {
    $p = $prefixOrUser;
    if (is_array($prefixOrUser) && !isset($prefixOrUser['title']) && isset($prefixOrUser['prefix_id'])) {
      try {
        $st = db()->prepare('SELECT * FROM user_prefixes WHERE id=? AND is_active=1');
        $st->execute([(int)$prefixOrUser['prefix_id']]);
        $p = $st->fetch() ?: null;
      } catch (Throwable $e) { $p = null; }
    }
    if (!$p || !is_array($p)) return '';
    $title = htmlspecialchars((string)($p['title'] ?? ''), ENT_QUOTES, 'UTF-8');
    if ($title === '') return '';
    $css = trim((string)($p['css'] ?? ''));
    if ($css === '') {
      $tc = htmlspecialchars((string)($p['text_color'] ?? '#fff'), ENT_QUOTES, 'UTF-8');
      $bg = htmlspecialchars((string)($p['bg_color'] ?? '#6366f1'), ENT_QUOTES, 'UTF-8');
      $css = "background:{$bg};color:{$tc};border-radius:4px;padding:2px 6px;font-weight:700;font-size:11px";
    } else {
      $css = htmlspecialchars($css, ENT_QUOTES, 'UTF-8');
    }
    return '<span class="user-prefix xf-prefix" style="' . $css . '">' . $title . '</span> ';
  }
}

if (!function_exists('user_prefixes_html')) {
  /** Все префиксы пользователя (map + primary) */
  function user_prefixes_html(int $userId): string {
    $html = '';
    try {
      $ids = [];
      $st = db()->prepare('SELECT prefix_id FROM user_prefix_map WHERE user_id=? ORDER BY sort_order ASC');
      $st->execute([$userId]);
      foreach ($st->fetchAll() as $r) $ids[] = (int)$r['prefix_id'];
      if (!$ids) {
        $st = db()->prepare('SELECT prefix_id FROM users WHERE id=?');
        $st->execute([$userId]);
        $one = (int)$st->fetchColumn();
        if ($one) $ids[] = $one;
      }
      foreach ($ids as $pid) {
        $st = db()->prepare('SELECT * FROM user_prefixes WHERE id=? AND is_active=1');
        $st->execute([$pid]);
        $p = $st->fetch();
        if ($p) $html .= user_render_prefix_html($p);
      }
    } catch (Throwable $e) {}
    return $html;
  }
}
