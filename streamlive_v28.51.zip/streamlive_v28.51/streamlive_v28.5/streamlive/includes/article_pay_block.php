<?php
/**
 * Вставить в article.php после загрузки $article и $user:
 * require_once __DIR__.'/includes/wallet_pay.php';
 * include __DIR__.'/includes/article_pay_block.php';
 */
if (!isset($article) || !is_array($article)) return;
$uid = isset($user['id']) ? (int)$user['id'] : 0;
$needPay = ((int)($article['is_premium'] ?? 0) === 1)
  && !wallet_user_has_article_access($uid, $article);
if ($needPay):
  $price = number_format((float)($article['premium_price'] ?? 0), 2, '.', ' ');
  $bal = ($uid && function_exists('wallet_balance')) ? wallet_balance($uid) : 0;
?>
<div class="sl-paywall" style="padding:24px;border-radius:16px;background:#1a1a22;border:1px solid rgba(251,191,36,.3);margin:16px 0;text-align:center">
  <h3 style="margin:0 0 8px">🔒 Платная статья</h3>
  <p style="opacity:.8">Стоимость: <b><?= htmlspecialchars($price) ?> ₽</b>
    <?php if ($uid): ?> · ваш баланс: <b><?= number_format($bal, 2, '.', ' ') ?> ₽</b><?php endif; ?></p>
  <?php if ($uid): ?>
    <form method="post" action="/article_pay.php">
      <input type="hidden" name="article_id" value="<?= (int)$article['id'] ?>">
      <button type="submit" style="padding:12px 20px;border:0;border-radius:12px;background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#111;font-weight:800;cursor:pointer">
        Оплатить с баланса
      </button>
    </form>
  <?php else: ?>
    <a href="/auth/login.php">Войдите</a>, чтобы оплатить с баланса.
  <?php endif; ?>
</div>
<?php
  // скрыть контент
  $article['content'] = '';
endif;
