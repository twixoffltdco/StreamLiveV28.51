<?php
/**
 * В video_import.php после получения URL:
 * require_once __DIR__.'/includes/video_embed_rumble_fix.php';
 * if (detect_video_platform($url)==='rumble') { $meta = video_fetch_meta_rumble_boost($url); ...}
 */
