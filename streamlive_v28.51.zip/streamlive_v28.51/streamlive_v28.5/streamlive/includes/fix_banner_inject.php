<?php
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';
$u = current_user();
if (!$u || ($u['role'] ?? '') !== 'admin') { http_response_code(403); exit('admin only'); }
$h = __DIR__ . '/header.php';
$t = file_get_contents($h);
// ensure scripts
if (strpos($t, 'ext-app-banner.js') === false) {
  $inj = "<?php if (is_file(__DIR__ . '/ext_app_head.php')) require_once __DIR__ . '/ext_app_head.php'; ?>\n</head>";
  if (preg_match('/<\/head>/i', $t)) {
    $t = preg_replace('/<\/head>/i', $inj, $t, 1);
  }
}
file_put_contents($h, $t);
echo 'OK: banner points to extension download. Clear browser cache / hard refresh.';
