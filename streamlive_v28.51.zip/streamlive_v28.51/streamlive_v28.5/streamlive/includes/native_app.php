<?php
/**
 * «Приложение» = браузерное расширение (extension_app).
 * Серебряная галочка + ачивка. Работает на HTTP и HTTPS.
 */
function native_app_ensure(): void {
  static $d = false;
  if ($d) return;
  $d = true;
  try {
    db()->exec(
      "CREATE TABLE IF NOT EXISTS native_app_installs (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NULL,
        device_id VARCHAR(64) NOT NULL,
        platform VARCHAR(16) NOT NULL DEFAULT 'extension',
        app_version VARCHAR(32) DEFAULT '1.0.0',
        last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_device (device_id),
        KEY idx_user (user_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
  } catch (Throwable $e) {}
  try { db()->exec("ALTER TABLE users ADD COLUMN native_app_active TINYINT(1) NOT NULL DEFAULT 0"); } catch (Throwable $e) {}
  try { db()->exec("ALTER TABLE users ADD COLUMN native_app_last_at DATETIME NULL"); } catch (Throwable $e) {}
}

function native_app_ping(?int $userId, string $deviceId, string $platform = 'extension', string $version = '1.0.0'): array {
  native_app_ensure();
  $deviceId = substr(preg_replace('/[^a-zA-Z0-9_-]/', '', $deviceId), 0, 64);
  if ($deviceId === '') return ['ok' => false, 'error' => 'device_id'];
  $platform = in_array($platform, ['extension', 'pwa', 'android', 'windows', 'ios'], true) ? $platform : 'extension';
  try {
    db()->prepare(
      'INSERT INTO native_app_installs (user_id, device_id, platform, app_version, last_seen_at)
       VALUES (?,?,?,?,NOW())
       ON DUPLICATE KEY UPDATE user_id=COALESCE(VALUES(user_id), user_id), platform=VALUES(platform),
         app_version=VALUES(app_version), last_seen_at=NOW()'
    )->execute([$userId ?: null, $deviceId, $platform, substr($version, 0, 32)]);
  } catch (Throwable $e) {
    return ['ok' => false, 'error' => $e->getMessage()];
  }
  if ($userId) {
    try {
      db()->prepare('UPDATE users SET native_app_active=1, native_app_last_at=NOW() WHERE id=?')->execute([$userId]);
    } catch (Throwable $e) {}
    try {
      db()->prepare(
        "INSERT IGNORE INTO user_achievements (user_id, code, title, created_at)
         VALUES (?, 'native_app', 'Установил приложение (расширение)', NOW())"
      )->execute([$userId]);
    } catch (Throwable $e) {
      try {
        db()->prepare(
          "INSERT IGNORE INTO achievements_unlocked (user_id, achievement_key, unlocked_at)
           VALUES (?, 'native_app', NOW())"
        )->execute([$userId]);
      } catch (Throwable $e2) {}
    }
  }
  return ['ok' => true, 'badge' => 'silver'];
}

function native_app_user_has_badge(array $user): bool {
  if (!empty($user['native_app_last_at'])) {
    $ts = strtotime((string)$user['native_app_last_at']);
    if ($ts && $ts > time() - 14 * 86400) return true;
  }
  try {
    native_app_ensure();
    $st = db()->prepare(
      'SELECT 1 FROM native_app_installs WHERE user_id=? AND last_seen_at > (NOW() - INTERVAL 14 DAY) LIMIT 1'
    );
    $st->execute([(int)$user['id']]);
    return (bool)$st->fetchColumn();
  } catch (Throwable $e) {
    return !empty($user['native_app_active']);
  }
}

/** Серебряная галочка (не синяя) */
function native_app_badge_html(array $user): string {
  if (!native_app_user_has_badge($user)) return '';
  return ' <span class="native-app-badge" title="Использует приложение StreamLive" style="display:inline-flex;vertical-align:middle;margin-left:3px;line-height:0">'
    . '<svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">'
    . '<defs><linearGradient id="slSilver" x1="0" y1="0" x2="1" y2="1">'
    . '<stop offset="0%" stop-color="#f8fafc"/><stop offset="45%" stop-color="#c0c7d1"/>'
    . '<stop offset="100%" stop-color="#8b95a5"/></linearGradient></defs>'
    . '<circle cx="12" cy="12" r="11" fill="url(#slSilver)" stroke="#6b7280" stroke-width="0.8"/>'
    . '<path d="M7 12.5l3 3 7-7" stroke="#1f2937" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
    . '</svg></span>';
}
