<?php
/**
 * Единый счётчик просмотров (видео, каналы, ресурсы, темы, статьи, embed).
 * Колонки: views_count ИЛИ views — обе поддерживаются.
 * Антифлуд: 1 зачёт на объект за сессию (как «сессионный» просмотр на YT).
 */
if (!function_exists('content_view_register')) {
  function content_view_register(string $type, int $id, bool $force = false): int {
    if ($id <= 0) return 0;
    $type = strtolower(preg_replace('/[^a-z_]/', '', $type) ?: '');
    if ($type === '') return 0;

    // session dedupe
    if (!$force) {
      try {
        if (session_status() !== PHP_SESSION_ACTIVE) {
          @session_start();
        }
        $key = '_cv_' . $type . '_' . $id;
        if (!empty($_SESSION[$key])) {
          return content_view_get($type, $id);
        }
        $_SESSION[$key] = time();
      } catch (Throwable $e) {}
    }

    $map = [
      'video'   => ['table' => 'videos',          'cols' => ['views_count', 'views']],
      'channel' => ['table' => 'channels',        'cols' => ['views', 'views_count']],
      'resource'=> ['table' => 'resources',       'cols' => ['views', 'views_count']],
      'thread'  => ['table' => 'forum_threads',   'cols' => ['views', 'views_count']],
      'article' => ['table' => 'content_articles','cols' => ['views', 'views_count']],
    ];
    if (!isset($map[$type])) return 0;
    $table = $map[$type]['table'];
    $cols = $map[$type]['cols'];

    $updated = false;
    foreach ($cols as $col) {
      try {
        $q = db()->prepare("UPDATE `{$table}` SET `{$col}` = COALESCE(`{$col}`,0) + 1 WHERE id = ?");
        $q->execute([$id]);
        if ($q->rowCount() >= 0) {
          $updated = true;
          // also mirror to other col if exists
          foreach ($cols as $col2) {
            if ($col2 === $col) continue;
            try {
              db()->prepare("UPDATE `{$table}` SET `{$col2}` = COALESCE(`{$col}`,0) WHERE id = ?")->execute([$id]);
            } catch (Throwable $e) {}
          }
          break;
        }
      } catch (Throwable $e) {
        // try next column name
      }
    }

    // ensure column exists once
    if (!$updated) {
      foreach ($cols as $col) {
        try {
          db()->exec("ALTER TABLE `{$table}` ADD COLUMN `{$col}` INT UNSIGNED NOT NULL DEFAULT 0");
          db()->prepare("UPDATE `{$table}` SET `{$col}` = 1 WHERE id = ?")->execute([$id]);
          $updated = true;
          break;
        } catch (Throwable $e) {}
      }
    }

    return content_view_get($type, $id);
  }
}

if (!function_exists('content_view_get')) {
  function content_view_get(string $type, int $id): int {
    if ($id <= 0) return 0;
    $map = [
      'video'   => ['videos', ['views_count', 'views']],
      'channel' => ['channels', ['views', 'views_count']],
      'resource'=> ['resources', ['views', 'views_count']],
      'thread'  => ['forum_threads', ['views', 'views_count']],
      'article' => ['content_articles', ['views', 'views_count']],
    ];
    $type = strtolower($type);
    if (!isset($map[$type])) return 0;
    [$table, $cols] = $map[$type];
    foreach ($cols as $col) {
      try {
        $st = db()->prepare("SELECT `{$col}` AS v FROM `{$table}` WHERE id = ? LIMIT 1");
        $st->execute([$id]);
        $row = $st->fetch();
        if ($row && $row['v'] !== null) return (int)$row['v'];
      } catch (Throwable $e) {}
    }
    return 0;
  }
}

if (!function_exists('content_view_display')) {
  /** Нормализовать поле просмотров в массиве сущности */
  function content_view_display(array $row, string $type = 'video'): int {
    foreach (['views_count', 'views', 'view_count'] as $k) {
      if (isset($row[$k]) && $row[$k] !== null && $row[$k] !== '') {
        return (int)$row[$k];
      }
    }
    if (!empty($row['id'])) {
      return content_view_get($type, (int)$row['id']);
    }
    return 0;
  }
}
