<?php
$__root = dirname(__DIR__);
foreach (['/includes/functions.php', '/includes/db.php', '/includes/auth.php'] as $f) {
  if (is_file($__root . $f)) { try { require_once $__root . $f; } catch (Throwable $e) {} }
}
foreach ([
  $__root . '/includes/user_display.php',
  $__root . '/includes/includes/user_display.php',
  $__root . '/includes/prefix_render_fix.php',
] as $f) {
  if (is_file($f)) { try { require_once $f; } catch (Throwable $e) {} }
}
function sl_safe_require_admin(): array {
  $u = function_exists('current_user') ? current_user() : null;
  if (!$u) { http_response_code(403); exit('Login'); }
  $role = (string)($u['role'] ?? '');
  if ($role !== 'admin' && empty($u['is_admin']) && (int)($u['id'] ?? 0) !== 1) {
    http_response_code(403); exit('Admin only');
  }
  return $u;
}
function sl_safe_require_mod(): array {
  $u = function_exists('current_user') ? current_user() : null;
  if (!$u) { http_response_code(403); exit('Login'); }
  $role = (string)($u['role'] ?? '');
  if (!in_array($role, ['admin','moderator','mod'], true) && empty($u['is_admin']) && empty($u['is_moderator'])) {
    http_response_code(403); exit('Mod only');
  }
  return $u;
}
function sl_prefix_html(?array $p): string {
  if (!$p) return '';
  $title = htmlspecialchars((string)($p['title'] ?? ''), ENT_QUOTES, 'UTF-8');
  if ($title === '') return '';
  if (function_exists('user_render_prefix_html')) {
    try { return user_render_prefix_html($p); } catch (Throwable $e) {}
  }
  $bg = (string)($p['bg_color'] ?? $p['color'] ?? '#6366f1');
  $tc = (string)($p['text_color'] ?? '#ffffff');
  $css = trim((string)($p['css'] ?? ''));
  if ($css !== '') {
    $css = preg_replace('/[<>]/', '', $css);
    return '<span style="'.htmlspecialchars($css, ENT_QUOTES).'">'.$title.'</span>';
  }
  return '<span style="display:inline-block;padding:2px 7px;border-radius:6px;font-size:11px;font-weight:700;color:'.
    htmlspecialchars($tc, ENT_QUOTES).';background:'.htmlspecialchars($bg, ENT_QUOTES).'">'.$title.'</span>';
}
