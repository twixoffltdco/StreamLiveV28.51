<?php
function streampedia_ensure(): void {
  streampedia_suspend_ensure();
  streampedia_auto_suspend_inactive();

  static $d = false; if ($d) return; $d = true;
  foreach (['071_streampedia.sql', '075_streampedia_wiki.sql', '076_streampedia_templates.sql'] as $name) {
    $f = __DIR__ . '/../sql/migrations/' . $name;
    if (!is_file($f)) continue;
    try {
      foreach (array_filter(array_map('trim', explode(';', file_get_contents($f)))) as $q) {
        if ($q !== '') { try { db()->exec($q); } catch (Throwable $e) {} }
      }
    } catch (Throwable $e) {}
  }
  foreach ([
    "ALTER TABLE streampedia_pages ADD COLUMN is_outdated TINYINT(1) NOT NULL DEFAULT 0",
    "ALTER TABLE streampedia_pages ADD COLUMN mark_delete_at DATETIME NULL",
    "ALTER TABLE streampedia_pages ADD COLUMN event_at DATETIME NULL",
    "ALTER TABLE streampedia_pages ADD COLUMN views_count INT NOT NULL DEFAULT 0",
    "ALTER TABLE streampedia_wikis ADD COLUMN views_count INT NOT NULL DEFAULT 0",
    "ALTER TABLE streampedia_wikis ADD COLUMN card_title VARCHAR(120) DEFAULT 'Карточка'",
  ] as $q) {
    try { db()->exec($q); } catch (Throwable $e) {}
  }
}

function streampedia_slug(string $s): string {
  $s = function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
  $map = ['а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','ё'=>'e','ж'=>'zh','з'=>'z','и'=>'i','й'=>'y','к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u','ф'=>'f','х'=>'h','ц'=>'ts','ч'=>'ch','ш'=>'sh','щ'=>'sch','ъ'=>'','ы'=>'y','ь'=>'','э'=>'e','ю'=>'yu','я'=>'ya'];
  $s = strtr($s, $map);
  $s = preg_replace('/[^a-z0-9]+/i', '-', $s);
  $s = trim($s, '-');
  return $s !== '' ? substr($s, 0, 100) : ('p-' . substr(md5(microtime()), 0, 8));
}

function streampedia_platform_staff(?array $user): bool {
  if (!$user) return false;
  return in_array(($user['role'] ?? ''), ['admin', 'moderator'], true);
}

function streampedia_wiki_role(int $wikiId, ?array $user): string {
  if (!$user) return '';
  if (streampedia_platform_staff($user)) return 'platform_' . ($user['role'] ?? 'moderator');
  try {
    $st = db()->prepare('SELECT owner_id FROM streampedia_wikis WHERE id=?');
    $st->execute([$wikiId]);
    if ((int)$st->fetchColumn() === (int)$user['id']) return 'admin';
  } catch (Throwable $e) {}
  try {
    $st = db()->prepare('SELECT role FROM streampedia_staff WHERE wiki_id=? AND user_id=?');
    $st->execute([$wikiId, (int)$user['id']]);
    return (string)($st->fetchColumn() ?: '');
  } catch (Throwable $e) {
    return '';
  }
}

function streampedia_can_edit(int $wikiId, ?array $user): bool {
  $r = streampedia_wiki_role($wikiId, $user);
  return in_array($r, ['admin', 'moderator', 'experienced', 'editor', 'platform_admin', 'platform_moderator'], true);
}

function streampedia_can_moderate(int $wikiId, ?array $user): bool {
  $r = streampedia_wiki_role($wikiId, $user);
  return in_array($r, ['admin', 'moderator', 'experienced', 'platform_admin', 'platform_moderator'], true);
}

/** Флаги: {{flag|RU}} {{флаг|Украина}} :ru: и т.д. */
function streampedia_flags_map(): array {
  return [
    'ru' => '🇷🇺', 'russia' => '🇷🇺', 'россия' => '🇷🇺', 'рф' => '🇷🇺',
    'ua' => '🇺🇦', 'ukraine' => '🇺🇦', 'украина' => '🇺🇦',
    'by' => '🇧🇾', 'belarus' => '🇧🇾', 'беларусь' => '🇧🇾',
    'kz' => '🇰🇿', 'kazakhstan' => '🇰🇿', 'казахстан' => '🇰🇿',
    'us' => '🇺🇸', 'usa' => '🇺🇸', 'сша' => '🇺🇸',
    'gb' => '🇬🇧', 'uk' => '🇬🇧', 'britain' => '🇬🇧',
    'de' => '🇩🇪', 'germany' => '🇩🇪', 'германия' => '🇩🇪',
    'fr' => '🇫🇷', 'france' => '🇫🇷', 'франция' => '🇫🇷',
    'cn' => '🇨🇳', 'china' => '🇨🇳', 'китай' => '🇨🇳',
    'jp' => '🇯🇵', 'japan' => '🇯🇵', 'япония' => '🇯🇵',
    'kr' => '🇰🇷', 'korea' => '🇰🇷', 'корея' => '🇰🇷',
    'tr' => '🇹🇷', 'turkey' => '🇹🇷', 'турция' => '🇹🇷',
    'pl' => '🇵🇱', 'poland' => '🇵🇱', 'польша' => '🇵🇱',
    'it' => '🇮🇹', 'italy' => '🇮🇹', 'италия' => '🇮🇹',
    'es' => '🇪🇸', 'spain' => '🇪🇸', 'испания' => '🇪🇸',
    'br' => '🇧🇷', 'brazil' => '🇧🇷',
    'in' => '🇮🇳', 'india' => '🇮🇳', 'индия' => '🇮🇳',
    'eu' => '🇪🇺', 'un' => '🇺🇳',
  ];
}

function streampedia_apply_flags(string $html): string {
  $map = streampedia_flags_map();
  // {{flag|RU}} {{флаг|Россия}}
  $html = preg_replace_callback('/\{\{\s*(?:flag|флаг)\s*\|\s*([^}|]+)\s*\}\}/iu', function ($m) use ($map) {
    $k = function_exists('mb_strtolower') ? mb_strtolower(trim($m[1]), 'UTF-8') : strtolower(trim($m[1]));
    $k = str_replace(' ', '', $k);
    $emoji = $map[$k] ?? null;
    if (!$emoji && strlen($k) === 2) $emoji = $map[$k] ?? null;
    return $emoji ? '<span class="sp-flag" title="' . htmlspecialchars($m[1], ENT_QUOTES, 'UTF-8') . '">' . $emoji . '</span>' : $m[0];
  }, $html);
  // :ru: :ua:
  $html = preg_replace_callback('/:([a-z]{2}):/i', function ($m) use ($map) {
    $k = strtolower($m[1]);
    return isset($map[$k]) ? '<span class="sp-flag">' . $map[$k] . '</span>' : $m[0];
  }, $html);
  return $html;
}

/** Шаблоны вики {{Имя шаблона|a=1|b=2}} */
function streampedia_apply_templates(int $wikiId, string $html): string {
  return preg_replace_callback('/\{\{\s*([^}|{\n]+)\s*(\|[\s\S]*?)?\}\}/u', function ($m) use ($wikiId) {
    $name = trim($m[1]);
    $low = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
    // карточки обрабатываем отдельно
    if (streampedia_is_card_keyword($low)) return $m[0];
    $body = '';
    try {
      $st = db()->prepare('SELECT body FROM streampedia_templates WHERE wiki_id=? AND (name=? OR slug=?) LIMIT 1');
      $st->execute([$wikiId, $name, streampedia_slug($name)]);
      $body = (string)($st->fetchColumn() ?: '');
    } catch (Throwable $e) {}
    if ($body === '') return $m[0];
    $params = [];
    if (!empty($m[2])) {
      foreach (explode('|', trim($m[2], "| \t\n\r")) as $i => $part) {
        $part = trim($part);
        if ($part === '') continue;
        if (strpos($part, '=') !== false) {
          [$k, $v] = array_map('trim', explode('=', $part, 2));
          $params[$k] = $v;
          $params[(string)($i + 1)] = $v;
        } else {
          $params[(string)($i + 1)] = $part;
        }
      }
    }
    foreach ($params as $k => $v) {
      $body = str_replace('{{{' . $k . '}}}', $v, $body);
      $body = preg_replace('/\{\{\{' . preg_quote((string)$k, '/') . '\|[^}]*\}\}\}/u', $v, $body);
    }
    $body = preg_replace('/\{\{\{[^}]+\}\}\}/u', '', $body);
    return $body;
  }, $html);
}

function streampedia_is_card_keyword(string $low): bool {
  // любое слово с «карточ» / card / infobox / инфобокс / карточка компании и т.д.
  if (preg_match('/карточка|карточк|infobox|info[\s_-]?box|инфобокс|инфо[\s_-]?бокс|карточка\s/ui', $low)) return true;
  if (in_array($low, ['card', 'box', 'карточка', 'инфобокс'], true)) return true;
  return false;
}

/**
 * Карточка: {{Карточка компании|Название=...|Тип=...}}
 * или {{любое слово карточка|...}}
 * или HTML table с классом/первой строкой «Карточка»
 */
function streampedia_extract_cards(string $html, string $defaultTitle = 'Карточка'): array {
  $cards = '';
  // {{Something|key=val|key2=val2}}
  $html = preg_replace_callback('/\{\{\s*([^}|{\n]+)\s*\|([\s\S]*?)\}\}/u', function ($m) use (&$cards, $defaultTitle) {
    $name = trim($m[1]);
    $low = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
    $looksCard = streampedia_is_card_keyword($low);
    // эвристика: ≥2 полей key=value и есть Название/тип/логотип/основан — тоже карточка
    $params = [];
    foreach (preg_split('/\|/', $m[2]) as $part) {
      $part = trim($part);
      if ($part === '' || strpos($part, '=') === false) continue;
      [$k, $v] = array_map('trim', explode('=', $part, 2));
      if ($k !== '') $params[$k] = $v;
    }
    if (!$looksCard && count($params) >= 2) {
      $keys = mb_strtolower(implode(' ', array_keys($params)), 'UTF-8');
      if (preg_match('/назван|logo|лого|тип|основа|располож|страна|сайт|жанр|статус|владел|директор|адрес/u', $keys)) {
        $looksCard = true;
      }
    }
    if (!$looksCard || !$params) return $m[0];
    $title = $name !== '' ? $name : $defaultTitle;
    if (isset($params['Название'])) $title = $params['Название'];
    if (isset($params['название'])) $title = $params['название'];
    $cards .= streampedia_card_html($title, $params);
    return '';
  }, $html);

  // wikitext-таблица {|\n|-\n! Карточка
  return [$html, $cards];
}

function streampedia_clean_cell(string $v): string {
  $v = html_entity_decode($v, ENT_QUOTES | ENT_HTML5, 'UTF-8');
  $v = preg_replace('/<\s*br\s*\/?\s*>/iu', '', $v);
  $v = preg_replace('/&lt;\s*br\s*\/?\s*&gt;/iu', '', $v);
  $v = preg_replace('/\bBR\b/u', '', $v);
  $v = strip_tags($v);
  $v = preg_replace('/\s+/u', ' ', trim($v));
  return $v;
}

function streampedia_card_html(string $title, array $params): string {
  $title = streampedia_clean_cell($title);
  $out = '<aside class="sp-infobox"><div class="sp-infobox-title">' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</div><table>';
  foreach ($params as $k => $v) {
    $k = streampedia_clean_cell((string)$k);
    $v = streampedia_clean_cell((string)$v);
    $lk = function_exists('mb_strtolower') ? mb_strtolower($k, 'UTF-8') : strtolower($k);
    if (in_array($lk, ['название', 'title', 'name'], true)) continue;
    if ($v === '') continue;
    if (preg_match('/лого|logo|image|изображ|фото|картинк/u', $lk) && preg_match('#https?://#i', $v)) {
      $out .= '<tr><td colspan="2" style="text-align:center"><img src="' . htmlspecialchars($v, ENT_QUOTES, 'UTF-8') . '" alt="" style="max-width:100%;border-radius:8px"></td></tr>';
      continue;
    }
    $vHtml = streampedia_apply_flags(htmlspecialchars($v, ENT_QUOTES, 'UTF-8'));
    $out .= '<tr><th>' . htmlspecialchars($k, ENT_QUOTES, 'UTF-8') . '</th><td>' . $vHtml . '</td></tr>';
  }
  $out .= '</table></aside>';
  return $out;
}

function streampedia_render(string $html, int $wikiId = 0, string $cardTitle = 'Карточка'): string {
  $html = trim($html);
  if ($html === '') return '';
  $html = preg_replace('/&lt;\s*br\s*\/?\s*&gt;/iu', "\n", $html);
  $html = preg_replace('/<\s*br\s*\/?\s*>/iu', "\n", $html);
  if ($wikiId > 0) {
    $html = streampedia_apply_templates($wikiId, $html);
  }
  $html = streampedia_apply_flags($html);

  $looksWiki = (strpos($html, '{{') !== false)
    || (bool)preg_match('/^={2,}.+={2,}/m', $html)
    || (strpos($html, '[[') !== false)
    || (strpos($html, '<p') === false && strpos($html, '<h') === false && strpos($html, '<div') === false);
  if ($looksWiki) {
    $html = streampedia_wikitext_to_html($html);
  }

  [$html, $cards] = streampedia_extract_cards($html, $cardTitle);

  // 1) Явное текстовое «Содержание» (как пишут люди) → настоящий TOC
  $html = streampedia_replace_textual_toc($html);

  // 2) Авто-TOC по h2/h3, если явного ещё нет
  $toc = [];
  $html = preg_replace_callback('/<h([23])([^>]*)>(.*?)<\/h\1>/iu', function ($m) use (&$toc) {
    $level = $m[1];
    $inner = strip_tags($m[3]);
    $id = streampedia_slug($inner);
    if ($id === '') $id = 's' . count($toc);
    $toc[] = ['level' => (int)$level, 'id' => $id, 'title' => $inner];
    return '<h' . $level . $m[2] . ' id="' . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . '">' . $m[3] . '</h' . $level . '>';
  }, $html);

  $tocHtml = '';
  if (strpos($html, 'class="sp-toc"') === false && count($toc) >= 2) {
    $tocHtml = streampedia_toc_html($toc);
  }

  $html = streampedia_sanitize_output($html);
  $cards = streampedia_sanitize_output($cards);
  return $cards . $tocHtml . '<div class="sp-article-body">' . $html . '</div>';
}

/** Строит HTML блока содержания */
function streampedia_toc_html(array $toc): string {
  $tocHtml = '<div class="sp-toc"><div class="sp-toc-title">Содержание</div><ol>';
  foreach ($toc as $t) {
    $pad = (($t['level'] ?? 2) === 3) ? ' class="sp-toc-sub"' : '';
    $tocHtml .= '<li' . $pad . '><a href="#' . htmlspecialchars($t['id'], ENT_QUOTES, 'UTF-8') . '">'
      . htmlspecialchars($t['title'], ENT_QUOTES, 'UTF-8') . '</a></li>';
  }
  $tocHtml .= '</ol></div>';
  return $tocHtml;
}

/**
 * Если в тексте есть блок:
 *   Содержание
 *   1. Введение
 *   2. История
 *   — или список после слова «Содержание» —
 * превращаем в кликабельный TOC и вешаем id на заголовки.
 */
function streampedia_replace_textual_toc(string $html): string {
  // уже есть готовый TOC
  if (strpos($html, 'class="sp-toc"') !== false) return $html;

  $patterns = [
    // <p>Содержание</p><ol>...</ol> или <ul>
    '/<(?:p|h[1-4]|div)[^>]*>\s*Содержание\s*<\/(?:p|h[1-4]|div)>\s*<(ol|ul)([^>]*)>([\s\S]*?)<\/\1>/iu',
    // просто строка Содержание\n1. ...
  ];

  $html2 = preg_replace_callback(
    '/<(?:p|h[1-4]|div)[^>]*>\s*Содержание\s*<\/(?:p|h[1-4]|div)>\s*<(ol|ul)([^>]*)>([\s\S]*?)<\/\1>/iu',
    function ($m) {
      $inner = $m[3];
      $items = [];
      if (preg_match_all('/<li[^>]*>([\s\S]*?)<\/li>/iu', $inner, $lis)) {
        foreach ($lis[1] as $li) {
          $title = trim(html_entity_decode(strip_tags($li), ENT_QUOTES, 'UTF-8'));
          $title = preg_replace('/^\d+[\.\)]\s*/u', '', $title);
          if ($title === '') continue;
          $items[] = ['level' => 2, 'id' => streampedia_slug($title), 'title' => $title];
        }
      }
      if (count($items) < 1) return $m[0];
      return streampedia_toc_html($items);
    },
    $html,
    1
  );
  if ($html2 !== null && $html2 !== $html) {
    $html = $html2;
  }

  // Plain text / wikitext block after "Содержание"
  $html = preg_replace_callback(
    '/(?:^|<p[^>]*>|<div[^>]*>)\s*Содержание\s*(?:<\/p>|<\/div>)?\s*([\s\S]{0,1200}?)(?=<h[12]|<p>\s*==|$)/iu',
    function ($m) {
      $block = $m[1];
      // не трогаем если уже ссылки toc
      if (strpos($block, 'sp-toc') !== false) return $m[0];
      $items = [];
      // 1. Title  or - Title or * Title
      if (preg_match_all('/(?:^|<br\s*\/?>|\n)\s*(?:\d+[\.)]|[-*•])\s*([^\n\r<]+)/u', "\n" . strip_tags(str_replace(['<br>','<br/>','<br />'], "\n", $block)), $mm)) {
        foreach ($mm[1] as $title) {
          $title = trim(html_entity_decode($title, ENT_QUOTES, 'UTF-8'));
          $title = trim($title, " 	.-");
          if (mb_strlen($title) < 2) continue;
          $items[] = ['level' => 2, 'id' => streampedia_slug($title), 'title' => $title];
        }
      }
      if (count($items) < 1) return $m[0];
      return streampedia_toc_html($items);
    },
    $html,
    1
  );

  // Marker {{содержание}} or __TOC__
  $html = preg_replace('/\{\{\s*содержание\s*\}\}|__TOC__/iu', '<!--SP_TOC_PLACEHOLDER-->', $html);

  return $html;
}


function streampedia_wikitext_to_html(string $t): string {
  $t = str_replace(["\r\n", "\r"], "\n", $t);
  $t = preg_replace('/&lt;\s*br\s*\/?\s*&gt;/iu', "\n", $t);
  $t = preg_replace('/<\s*br\s*\/?\s*>/iu', "\n", $t);

  $blocks = [];
  $t = preg_replace_callback('/\{\{[\s\S]*?\}\}/u', function ($m) use (&$blocks) {
    $k = '%%BLK' . count($blocks) . '%%';
    $blocks[$k] = $m[0];
    return $k;
  }, $t);

  $t = htmlspecialchars($t, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
  foreach ($blocks as $k => $v) {
    $t = str_replace(htmlspecialchars($k, ENT_QUOTES, 'UTF-8'), $v, $t);
  }

  $t = preg_replace('/^====\s*(.+?)\s*====\s*$/mu', '<h4>$1</h4>', $t);
  $t = preg_replace('/^===\s*(.+?)\s*===\s*$/mu', '<h3>$1</h3>', $t);
  $t = preg_replace('/^==\s*(.+?)\s*==\s*$/mu', '<h2>$1</h2>', $t);
  $t = preg_replace("/\'\'\'(.+?)\'\'\'/u", '<b>$1</b>', $t);
  $t = preg_replace("/\'\'(.+?)\'\'/u", '<i>$1</i>', $t);
  $t = preg_replace('/\[\[([^\]|]+)\|([^\]]+)\]\]/u', '<a class="sp-wikilink" data-page="$1" href="#">$2</a>', $t);
  $t = preg_replace('/\[\[([^\]]+)\]\]/u', '<a class="sp-wikilink" data-page="$1" href="#">$1</a>', $t);

  $parts = preg_split('/\n\s*\n/', $t);
  $out = '';
  foreach ($parts as $p) {
    $p = trim($p);
    if ($p === '') continue;
    if (preg_match('/^<h[2-4]>/', $p) || strpos($p, '{{') === 0) {
      $out .= $p;
    } else {
      $p = str_replace("\n", '<br>', $p);
      $out .= '<p>' . $p . '</p>';
    }
  }
  return $out;
}

function streampedia_sanitize_output(string $html): string {
  for ($i = 0; $i < 3; $i++) {
    if (strpos($html, '&lt;') === false && strpos($html, '&amp;lt;') === false) break;
    $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
  }
  $html = preg_replace('/&lt;\s*br\s*\/?\s*&gt;/iu', '', $html);
  $html = preg_replace('/<\s*br\s*\/?\s*>/iu', '', $html);
  $html = preg_replace('/\s*\|\s*BR\s*/u', ' ', $html);
  $html = preg_replace("/\'\'\'(.+?)\'\'\'/u", '<b>$1</b>', $html);
  $html = preg_replace("/\'\'(.+?)\'\'/u", '<i>$1</i>', $html);
  return $html;
}

function streampedia_detect_event(?string $content): ?string {
  if (!$content) return null;
  if (preg_match('/\b(20\d{2})[.\-\/](\d{1,2})[.\-\/](\d{1,2})(?:\s+(\d{1,2}):(\d{2}))?/u', $content, $m)) {
    $y = (int)$m[1]; $mo = (int)$m[2]; $d = (int)$m[3];
    $h = isset($m[4]) ? (int)$m[4] : 0;
    $i = isset($m[5]) ? (int)$m[5] : 0;
    if (checkdate($mo, $d, $y)) {
      return sprintf('%04d-%02d-%02d %02d:%02d:00', $y, $mo, $d, $h, $i);
    }
  }
  return null;
}

function streampedia_import_wikipedia(string $url): ?array {
  if (!preg_match('#https?://([^/]+)/wiki/(.+)#i', $url, $g)) return null;
  $host = $g[1];
  $title = urldecode(str_replace('_', ' ', $g[2]));
  $api = 'https://' . $host . '/w/api.php?action=parse&page=' . rawurlencode($title) . '&prop=text|displaytitle&format=json';
  $ctx = stream_context_create(['http' => ['timeout' => 12, 'header' => "User-Agent: StreamPedia/1.0\r\n"]]);
  $json = @file_get_contents($api, false, $ctx);
  if (!$json) return null;
  $data = json_decode($json, true);
  if (empty($data['parse']['text']['*'])) return null;
  $body = $data['parse']['text']['*'];
  $disp = html_entity_decode(strip_tags($data['parse']['displaytitle'] ?? $title), ENT_QUOTES, 'UTF-8');
  return ['title' => $disp, 'content' => $body, 'source' => $url];
}

/** Вклад пользователя: число правок и sum delta chars */
function streampedia_user_contribs(int $userId, int $limit = 50): array {
  try {
    $st = db()->prepare(
      "SELECT r.id, r.page_id, r.title, r.summary, r.mod_status, r.created_at,
              p.slug AS page_slug, w.slug AS wiki_slug, w.title AS wiki_title,
              CHAR_LENGTH(COALESCE(r.content,'')) AS len
       FROM streampedia_revisions r
       JOIN streampedia_pages p ON p.id=r.page_id
       JOIN streampedia_wikis w ON w.id=p.wiki_id
       WHERE r.editor_id=?
       ORDER BY r.id DESC LIMIT " . (int)$limit
    );
    $st->execute([$userId]);
    $rows = $st->fetchAll() ?: [];
    // delta vs previous revision
    foreach ($rows as &$r) {
      $prev = 0;
      try {
        $st2 = db()->prepare('SELECT CHAR_LENGTH(COALESCE(content,\'\')) FROM streampedia_revisions WHERE page_id=? AND id<? ORDER BY id DESC LIMIT 1');
        $st2->execute([(int)$r['page_id'], (int)$r['id']]);
        $prev = (int)($st2->fetchColumn() ?: 0);
      } catch (Throwable $e) {}
      $r['delta'] = (int)$r['len'] - $prev;
    }
    unset($r);
    return $rows;
  } catch (Throwable $e) {
    return [];
  }
}


function streampedia_suspend_ensure(): void {
  static $done = false;
  if ($done) return;
  $done = true;
  try {
    db()->exec("ALTER TABLE streampedia_wikis ADD COLUMN is_suspended TINYINT(1) NOT NULL DEFAULT 0");
  } catch (Throwable $e) {}
  try {
    db()->exec("ALTER TABLE streampedia_wikis ADD COLUMN suspended_reason VARCHAR(255) NULL");
  } catch (Throwable $e) {}
  try {
    db()->exec("ALTER TABLE streampedia_wikis ADD COLUMN suspended_at DATETIME NULL");
  } catch (Throwable $e) {}
  try {
    db()->exec("ALTER TABLE streampedia_wikis ADD COLUMN last_activity_at DATETIME NULL");
  } catch (Throwable $e) {}
}

/** Авто-стоп вики без активности 30 дней */
function streampedia_auto_suspend_inactive(): void {
  streampedia_suspend_ensure();
  try {
    db()->exec(
      "UPDATE streampedia_wikis SET is_suspended=1, suspended_reason='Нет активности 30 дней', suspended_at=NOW()
       WHERE is_deleted=0 AND is_suspended=0 AND mod_status='approved'
         AND COALESCE(last_activity_at, updated_at, created_at) < (NOW() - INTERVAL 30 DAY)"
    );
  } catch (Throwable $e) {}
}

function streampedia_touch_activity(int $wikiId): void {
  streampedia_suspend_ensure();
  try {
    db()->prepare('UPDATE streampedia_wikis SET last_activity_at=NOW() WHERE id=?')->execute([$wikiId]);
  } catch (Throwable $e) {}
}

function streampedia_is_suspended(array $wiki): bool {
  return !empty($wiki['is_suspended']);
}

function streampedia_suspend_wiki(int $wikiId, string $reason, int $byUserId): bool {
  streampedia_suspend_ensure();
  try {
    db()->prepare('UPDATE streampedia_wikis SET is_suspended=1, suspended_reason=?, suspended_at=NOW() WHERE id=?')
      ->execute([mb_substr($reason, 0, 255), $wikiId]);
    return true;
  } catch (Throwable $e) { return false; }
}

function streampedia_unsuspend_wiki(int $wikiId): bool {
  streampedia_suspend_ensure();
  try {
    db()->prepare('UPDATE streampedia_wikis SET is_suspended=0, suspended_reason=NULL, suspended_at=NULL, last_activity_at=NOW() WHERE id=?')
      ->execute([$wikiId]);
    return true;
  } catch (Throwable $e) { return false; }
}
