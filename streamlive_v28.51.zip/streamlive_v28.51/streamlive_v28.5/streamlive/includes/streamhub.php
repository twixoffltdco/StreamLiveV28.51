<?php
function streamhub_ensure(): void {
  static $d = false;
  if ($d) return;
  $d = true;
  $f = __DIR__ . '/../sql/migrations/072_streamhub_github.sql';
  if (is_file($f)) {
    try {
      foreach (array_filter(array_map('trim', explode(';', file_get_contents($f)))) as $q) {
        if ($q !== '') {
          try { db()->exec($q); } catch (Throwable $e) {}
        }
      }
    } catch (Throwable $e) {}
  }
}

function streamhub_slug(string $name): string {
  $s = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
  $s = preg_replace('/[^a-z0-9]+/i', '-', $s);
  $s = trim($s, '-');
  return $s !== '' ? substr($s, 0, 100) : ('repo-' . substr(md5($name . microtime(true)), 0, 8));
}

function streamhub_can_edit(?array $user, array $repo): bool {
  if (!$user) return false;
  if ((int)$user['id'] === (int)$repo['owner_id']) return true;
  if (($user['role'] ?? '') === 'admin') return true;
  if (!empty($repo['org_id'])) {
    try {
      $st = db()->prepare('SELECT role FROM streamhub_org_members WHERE org_id=? AND user_id=?');
      $st->execute([(int)$repo['org_id'], (int)$user['id']]);
      $r = $st->fetchColumn();
      return in_array($r, ['owner', 'admin', 'write'], true);
    } catch (Throwable $e) {}
  }
  return false;
}
