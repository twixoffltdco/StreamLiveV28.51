<?php
/**
 * Два режима расписания на канале:
 * 1) Как задал автор (передать $authorSchedule HTML/массив)
 * 2) Живое расписание — epg_live
 */
if (!function_exists('channel_schedule_widget')) {
  function channel_schedule_widget(string $channelTitle, $authorSchedule = null): void {
    if (!is_file(__DIR__ . '/epg_live.php')) {
      return;
    }
    require_once __DIR__ . '/epg_live.php';
    $uid = 'epg' . substr(md5($channelTitle), 0, 8);
    ?>
    <div class="sm-live-epg" data-channel="<?= htmlspecialchars($channelTitle, ENT_QUOTES, 'UTF-8') ?>">
      <div class="sm-epg-tabs">
        <button type="button" class="active" data-tab="author" data-uid="<?= $uid ?>">Расписание автора</button>
        <button type="button" data-tab="live" data-uid="<?= $uid ?>">Живое расписание</button>
      </div>
      <div id="<?= $uid ?>-author">
        <?php if (is_array($authorSchedule) && $authorSchedule): ?>
          <?php foreach ($authorSchedule as $row): ?>
            <div class="epg-item">
              <span class="epg-time"><?= htmlspecialchars((string)($row['time'] ?? $row['start'] ?? ''), ENT_QUOTES, 'UTF-8') ?></span>
              <span><?= htmlspecialchars((string)($row['title'] ?? $row['name'] ?? ''), ENT_QUOTES, 'UTF-8') ?></span>
            </div>
          <?php endforeach; ?>
        <?php elseif (is_string($authorSchedule) && $authorSchedule !== ''): ?>
          <?= $authorSchedule ?>
        <?php else: ?>
          <p style="opacity:.7;font-size:13px;margin:0">Автор пока не задал расписание.</p>
        <?php endif; ?>
      </div>
      <div id="<?= $uid ?>-live" style="display:none">
        <p style="opacity:.7;font-size:13px" id="<?= $uid ?>-live-status">Загрузка…</p>
        <div id="<?= $uid ?>-live-list"></div>
      </div>
    </div>
    <script>
    (function(){
      var uid = <?= json_encode($uid) ?>;
      var ch = <?= json_encode($channelTitle, JSON_UNESCAPED_UNICODE) ?>;
      document.querySelectorAll('.sm-epg-tabs button[data-uid="'+uid+'"]').forEach(function(btn){
        btn.addEventListener('click', function(){
          document.querySelectorAll('.sm-epg-tabs button[data-uid="'+uid+'"]').forEach(function(b){ b.classList.remove('active'); });
          btn.classList.add('active');
          var tab = btn.getAttribute('data-tab');
          document.getElementById(uid+'-author').style.display = tab==='author'?'block':'none';
          document.getElementById(uid+'-live').style.display = tab==='live'?'block':'none';
          if (tab==='live' && !window['__'+uid+'_loaded']) {
            window['__'+uid+'_loaded'] = true;
            var st = document.getElementById(uid+'-live-status');
            var list = document.getElementById(uid+'-live-list');
            fetch('/api/epg_live.php?channel='+encodeURIComponent(ch)).then(function(r){ return r.json(); }).then(function(d){
              if (!d || !d.ok || !d.items || !d.items.length) {
                st.textContent = (d && d.error) ? d.error : 'Расписание не найдено';
                return;
              }
              st.textContent = 'Источник: ' + (d.source || 'EPG');
              list.innerHTML = d.items.map(function(it){
                var t = (it.start||'').toString();
                var time = t.length>=12 ? t.substr(8,2)+':'+t.substr(10,2) : t;
                return '<div class="epg-item"><span class="epg-time">'+time+'</span><span>'+ (it.title||'') +'</span></div>';
              }).join('');
            }).catch(function(){ st.textContent = 'Ошибка загрузки'; });
          }
        });
      });
    })();
    </script>
    <?php
  }
}
