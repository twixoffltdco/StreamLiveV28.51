<?php
/** В footer или header: <?php if (is_file(__DIR__.'/keepalive_head.php')) require __DIR__.'/keepalive_head.php'; ?> */
?>
<script src="/assets/js/sl-keepalive.js?v=1" defer></script>
