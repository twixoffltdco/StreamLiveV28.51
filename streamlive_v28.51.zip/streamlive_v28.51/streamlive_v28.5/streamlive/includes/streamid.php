<?php
function streamid_ensure(): void {
  static $d = false; if ($d) return; $d = true;
  $f = __DIR__ . '/../sql/migrations/074_streamid.sql';
  if (!is_file($f)) return;
  try {
    foreach (array_filter(array_map('trim', explode(';', file_get_contents($f)))) as $q) {
      if ($q !== '') { try { db()->exec($q); } catch (Throwable $e) {} }
    }
  } catch (Throwable $e) {}
}

function streamid_looks_fake_name(string $first, string $last): bool {
  $f = mb_strtolower(trim($first));
  $l = mb_strtolower(trim($last));
  if ($f === '' || $l === '') return true;
  $fake = ['test', 'asdf', 'qwer', 'null', 'none', 'admin', 'user', 'имя', 'фамилия', 'xxx', 'asd', 'aaa', 'bbb', 'testov', 'ivan', 'иван'];
  // single letter / digits only
  if (preg_match('/^\d+$/u', $f) || preg_match('/^\d+$/u', $l)) return true;
  if (mb_strlen($f) < 2 || mb_strlen($l) < 2) return true;
  foreach ($fake as $w) {
    if ($f === $w || $l === $w) return true;
  }
  // keyboard smash
  if (preg_match('/(.)\1{3,}/u', $f . $l)) return true;
  return false;
}

function streamid_get(int $userId): array {
  streamid_ensure();
  try {
    $st = db()->prepare('SELECT * FROM streamid_profiles WHERE user_id=?');
    $st->execute([$userId]);
    $r = $st->fetch();
    if ($r) return $r;
  } catch (Throwable $e) {}
  try {
    db()->prepare('INSERT INTO streamid_profiles (user_id) VALUES (?)')->execute([$userId]);
  } catch (Throwable $e) {}
  return [
    'user_id' => $userId, 'first_name' => '', 'last_name' => '', 'name_changed_at' => null,
    'phone' => null, 'phone_confirmed' => 0, 'data_quality' => 'unknown',
  ];
}

function streamid_touch_service(int $userId, string $key, string $name): void {
  streamid_ensure();
  try {
    db()->prepare(
      'INSERT INTO streamid_services (user_id, service_key, service_name, last_login_at) VALUES (?,?,?,NOW())
       ON DUPLICATE KEY UPDATE service_name=VALUES(service_name), last_login_at=NOW()'
    )->execute([$userId, $key, $name]);
  } catch (Throwable $e) {}
}

function streamid_services(int $userId): array {
  streamid_ensure();
  try {
    $st = db()->prepare('SELECT * FROM streamid_services WHERE user_id=? ORDER BY last_login_at DESC');
    $st->execute([$userId]);
    return $st->fetchAll() ?: [];
  } catch (Throwable $e) {
    return [];
  }
}
