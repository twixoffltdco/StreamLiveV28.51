<?php
/** Универсальный учёт: 1 просмотр = 1 IP на объект */
function views_ip_hit(string $table, string $idColumn, int $objectId, string $counterTable, string $counterIdCol, string $counterField = 'views_count'): void {
  if ($objectId <= 0) return;
  try {
    $ip = function_exists('antibot_client_ip') ? antibot_client_ip() : ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    $uid = $_SESSION['user_id'] ?? null;
    // table: video_views(video_id, ip), etc — create if needed is caller's job
    $st = db()->prepare("INSERT IGNORE INTO {$table} ({$idColumn}, ip, user_id) VALUES (?,?,?)");
    $st->execute([$objectId, $ip, $uid]);
    if ($st->rowCount() > 0) {
      db()->prepare("UPDATE {$counterTable} SET {$counterField} = {$counterField} + 1 WHERE {$counterIdCol} = ?")
        ->execute([$objectId]);
    }
  } catch (Throwable $e) {}
}
