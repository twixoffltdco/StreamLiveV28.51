<?php
/** Подключить в header перед </head> если нужно Organization schema */
$__seo_base = (defined('SITE_URL') && SITE_URL) ? rtrim((string)SITE_URL, '/') : '';
if ($__seo_base === '' && !empty($_SERVER['HTTP_HOST'])) {
  $h = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  $__seo_base = $h . '://' . $_SERVER['HTTP_HOST'];
}
$name = defined('SITE_NAME') ? SITE_NAME : 'StreamLive';
$json = [
  '@context' => 'https://schema.org',
  '@type' => 'WebSite',
  'name' => $name,
  'url' => $__seo_base . '/',
  'potentialAction' => [
    '@type' => 'SearchAction',
    'target' => $__seo_base . '/search.php?q={search_term_string}',
    'query-input' => 'required name=search_term_string',
  ],
];
echo '<script type="application/ld+json">' . json_encode($json, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
