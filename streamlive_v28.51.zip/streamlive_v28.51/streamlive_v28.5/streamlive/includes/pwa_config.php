<?php
function pwa_app_name(): string {
  if (defined('SITE_NAME') && SITE_NAME) return (string)SITE_NAME;
  if (defined('APP_NAME') && APP_NAME) return (string)APP_NAME;
  return preg_replace('/^www\./', '', $_SERVER['HTTP_HOST'] ?? 'App');
}
function pwa_theme_color(): string { return '#0d0d0d'; }
