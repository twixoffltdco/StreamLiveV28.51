<?php
/** Подключить в header при активной теме smotrim / cookie site_theme=smotrim */
if (!function_exists('theme_smotrim_is_active')) {
  function theme_smotrim_is_active(): bool {
    $slug = (string)($_COOKIE['site_theme'] ?? '');
    return $slug === 'smotrim' || $slug === 'Смотрим';
  }
}
if (!function_exists('theme_smotrim_register')) {
  function theme_smotrim_register(): void {
    if (!function_exists('themes_all') || !function_exists('themes_save_all')) return;
    $all = themes_all();
    foreach ($all as $t) {
      if (($t['slug'] ?? '') === 'smotrim') return;
    }
    $all[] = [
      'slug' => 'smotrim',
      'name' => 'Смотрим',
      'css' => '/assets/themes/smotrim.css',
      'header' => null,
      'footer' => null,
    ];
    try { themes_save_all($all); } catch (Throwable $e) {}
  }
}
try { theme_smotrim_register(); } catch (Throwable $e) {}
