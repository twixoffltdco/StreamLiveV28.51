<?php
if (!function_exists('prefix_pawno_seed_list')) {
  function prefix_pawno_seed_list(): array {
    return [
      ['Администратор', '#dc2626', '#ffffff'],
      ['Гл. Администратор', '#991b1b', '#ffffff'],
      ['Модератор', '#2563eb', '#ffffff'],
      ['Ст. Модератор', '#1d4ed8', '#ffffff'],
      ['Хелпер', '#0891b2', '#ffffff'],
      ['Разработчик', '#7c3aed', '#ffffff'],
      ['Кодер', '#6d28d9', '#ffffff'],
      ['Маппер', '#0d9488', '#ffffff'],
      ['Скриптер', '#4f46e5', '#ffffff'],
      ['Продавец', '#16a34a', '#ffffff'],
      ['Покупатель', '#65a30d', '#ffffff'],
      ['VIP', '#eab308', '#000000'],
      ['Premium', '#f59e0b', '#000000'],
      ['Sponsor', '#db2777', '#ffffff'],
      ['Партнёр', '#c026d3', '#ffffff'],
      ['Верифицирован', '#0ea5e9', '#ffffff'],
      ['Заблокирован', '#1f2937', '#f87171'],
      ['Предупреждение', '#ea580c', '#ffffff'],
      ['Новичок', '#64748b', '#ffffff'],
      ['Активный', '#22c55e', '#ffffff'],
      ['Легенда', '#f97316', '#ffffff'],
      ['Тех. поддержка', '#0284c7', '#ffffff'],
      ['Контент-мейкер', '#a855f7', '#ffffff'],
      ['Стример', '#e11d48', '#ffffff'],
    ];
  }
}

if (!function_exists('prefix_table_ensure')) {
  function prefix_table_ensure(): void {
    try {
      db()->exec(
        "CREATE TABLE IF NOT EXISTS user_prefixes (
          id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
          title VARCHAR(80) NOT NULL,
          css TEXT NULL,
          text_color VARCHAR(32) DEFAULT '#ffffff',
          bg_color VARCHAR(32) DEFAULT '#6366f1',
          color VARCHAR(32) NULL,
          sort_order INT NOT NULL DEFAULT 0,
          is_active TINYINT(1) NOT NULL DEFAULT 1,
          is_system TINYINT(1) NOT NULL DEFAULT 0,
          is_personal TINYINT(1) NOT NULL DEFAULT 0,
          owner_user_id INT UNSIGNED NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
      );
    } catch (Throwable $e) {}
    foreach ([
      'ALTER TABLE user_prefixes ADD COLUMN text_color VARCHAR(32) NULL',
      'ALTER TABLE user_prefixes ADD COLUMN bg_color VARCHAR(32) NULL',
      'ALTER TABLE user_prefixes ADD COLUMN css TEXT NULL',
      'ALTER TABLE user_prefixes ADD COLUMN color VARCHAR(32) NULL',
      'ALTER TABLE user_prefixes ADD COLUMN is_active TINYINT(1) DEFAULT 1',
      'ALTER TABLE user_prefixes ADD COLUMN is_system TINYINT(1) DEFAULT 0',
      'ALTER TABLE user_prefixes ADD COLUMN is_personal TINYINT(1) DEFAULT 0',
      'ALTER TABLE user_prefixes ADD COLUMN sort_order INT DEFAULT 0',
      'ALTER TABLE user_prefixes ADD COLUMN owner_user_id INT UNSIGNED NULL',
    ] as $sql) {
      try { db()->exec($sql); } catch (Throwable $e) {}
    }
  }
}

if (!function_exists('prefix_pawno_seed_run')) {
  function prefix_pawno_seed_run(): array {
    prefix_table_ensure();
    $created = 0;
    $skipped = 0;
    $existing = [];
    try {
      foreach (db()->query('SELECT title FROM user_prefixes')->fetchAll() ?: [] as $r) {
        $t = trim((string)$r['title']);
        $key = function_exists('mb_strtolower') ? mb_strtolower($t) : strtolower($t);
        $existing[$key] = true;
      }
    } catch (Throwable $e) {
      return ['created' => 0, 'skipped' => 0, 'error' => $e->getMessage()];
    }
    $sort = 0;
    foreach (prefix_pawno_seed_list() as $item) {
      [$title, $bg, $tc] = $item;
      $key = function_exists('mb_strtolower') ? mb_strtolower($title) : strtolower($title);
      if (isset($existing[$key])) {
        $skipped++;
        $sort += 10;
        continue;
      }
      $css = "background:{$bg};color:{$tc};border-radius:4px;padding:2px 6px;font-weight:700;font-size:11px;display:inline-block";
      try {
        db()->prepare(
          'INSERT INTO user_prefixes (title, css, text_color, bg_color, color, sort_order, is_active, is_system, is_personal, owner_user_id)
           VALUES (?,?,?,?,?,?,1,1,0,NULL)'
        )->execute([$title, $css, $tc, $bg, $bg, $sort]);
        $created++;
        $existing[$key] = true;
      } catch (Throwable $e) {
        try {
          db()->prepare('INSERT INTO user_prefixes (title, color, is_active) VALUES (?,?,1)')->execute([$title, $bg]);
          $created++;
        } catch (Throwable $e2) {}
      }
      $sort += 10;
    }
    return ['created' => $created, 'skipped' => $skipped, 'error' => ''];
  }
}

/** Все строки префиксов без фильтров */
if (!function_exists('prefix_fetch_all')) {
  function prefix_fetch_all(): array {
    prefix_table_ensure();
    try {
      return db()->query('SELECT * FROM user_prefixes ORDER BY id ASC')->fetchAll() ?: [];
    } catch (Throwable $e) {
      return [];
    }
  }
}
