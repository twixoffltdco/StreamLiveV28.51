<?php
/**
 * StreamLive Vibe Pack:
 * - сезонные рамки ника (все основные праздники RU/мир)
 * - ачивки
 * - реакции на посты форума
 * - QR-шаринг
 * Без тяжёлого polling.
 */

function vibe_ensure_schema(): void {
  static $done = false;
  if ($done) return;
  $done = true;
  try {
    $pdo = db();
  } catch (Throwable $e) {
    return;
  }
  try {
    $pdo->exec(
      "CREATE TABLE IF NOT EXISTS forum_post_reactions (
        post_id INT UNSIGNED NOT NULL,
        user_id INT UNSIGNED NOT NULL,
        emoji VARCHAR(16) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (post_id, user_id),
        KEY idx_post (post_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
  } catch (Throwable $e) {}
  try {
    $pdo->exec(
      "CREATE TABLE IF NOT EXISTS user_achievements (
        user_id INT UNSIGNED NOT NULL,
        code VARCHAR(40) NOT NULL,
        unlocked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (user_id, code)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
  } catch (Throwable $e) {}
  try {
    $pdo->exec(
      "CREATE TABLE IF NOT EXISTS channel_watching (
        channel_id INT UNSIGNED NOT NULL,
        user_id INT UNSIGNED NOT NULL DEFAULT 0,
        session_key VARCHAR(64) NOT NULL,
        last_seen DATETIME NOT NULL,
        PRIMARY KEY (channel_id, session_key),
        KEY idx_seen (channel_id, last_seen)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
  } catch (Throwable $e) {}
  try {
    $pdo->exec("ALTER TABLE users ADD COLUMN vibe_frame_override VARCHAR(40) NULL");
  } catch (Throwable $e) {}
}

/** Каталог праздничных рамок (месяц-день окна) */
function vibe_frame_catalog(): array {
  return [
    // Мем Шуфутинского — ВЕЧНАЯ рамка (календарь снова 3 сентября)
    'sept3' => [
      'title' => '3 сентября',
      'emoji' => '📅',
      'class' => 'vibe-frame-sept3',
      'eternal' => true,
      'months' => [[1, 1, 12, 31]], // весь год
    ],

    // зима
    'new_year' => [
      'title' => 'Новый год', 'emoji' => '🎄', 'class' => 'vibe-frame-newyear',
      'months' => [[12, 20, 12, 31], [1, 1, 1, 10]],
    ],
    'christmas' => [
      'title' => 'Рождество', 'emoji' => '✨', 'class' => 'vibe-frame-xmas',
      'months' => [[1, 6, 1, 8]],
    ],
    'valentine' => [
      'title' => 'День влюблённых', 'emoji' => '💖', 'class' => 'vibe-frame-valentine',
      'months' => [[2, 10, 2, 15]],
    ],
    'defender' => [
      'title' => '23 февраля', 'emoji' => '🛡️', 'class' => 'vibe-frame-defender',
      'months' => [[2, 20, 2, 24]],
    ],
    'women' => [
      'title' => '8 марта', 'emoji' => '🌸', 'class' => 'vibe-frame-women',
      'months' => [[3, 5, 3, 10]],
    ],
    'april_fools' => [
      'title' => '1 апреля', 'emoji' => '🤡', 'class' => 'vibe-frame-april',
      'months' => [[4, 1, 4, 2]],
    ],
    'cosmonautics' => [
      'title' => 'День космонавтики', 'emoji' => '🚀', 'class' => 'vibe-frame-space',
      'months' => [[4, 11, 4, 13]],
    ],
    'easter' => [
      'title' => 'Пасхальный сезон', 'emoji' => '🥚', 'class' => 'vibe-frame-easter',
      // приближённо апрель–начало мая
      'months' => [[4, 15, 5, 10]],
    ],
    'victory' => [
      'title' => 'День Победы', 'emoji' => '🎖', 'class' => 'vibe-frame-victory',
      'months' => [[5, 7, 5, 10]],
    ],
    'russia_day' => [
      'title' => 'День России', 'emoji' => '🇷🇺', 'class' => 'vibe-frame-russia',
      'months' => [[6, 10, 6, 13]],
    ],
    'ivan_kupala' => [
      'title' => 'Иван Купала', 'emoji' => '🔥', 'class' => 'vibe-frame-kupala',
      'months' => [[7, 5, 7, 8]],
    ],
    'knowledge' => [
      'title' => '1 сентября', 'emoji' => '📚', 'class' => 'vibe-frame-school',
      'months' => [[8, 30, 9, 3]],
    ],
    'teacher' => [
      'title' => 'День учителя', 'emoji' => '🍎', 'class' => 'vibe-frame-teacher',
      'months' => [[10, 4, 10, 6]],
    ],
    'halloween' => [
      'title' => 'Хеллоуин', 'emoji' => '🎃', 'class' => 'vibe-frame-halloween',
      'months' => [[10, 25, 11, 2]],
    ],
    'unity' => [
      'title' => 'День народного единства', 'emoji' => '🤝', 'class' => 'vibe-frame-unity',
      'months' => [[11, 3, 11, 5]],
    ],
    'mother' => [
      'title' => 'День матери', 'emoji' => '💐', 'class' => 'vibe-frame-mother',
      // последнее воскресенье ноября ≈ 22–30
      'months' => [[11, 22, 11, 30]],
    ],
    'summer' => [
      'title' => 'Летний вайб', 'emoji' => '☀️', 'class' => 'vibe-frame-summer',
      'months' => [[6, 1, 8, 20]],
    ],
  ];
}

function vibe_in_window(int $m, int $d, array $win): bool {
  // win: [m1,d1,m2,d2]
  [$m1, $d1, $m2, $d2] = $win;
  $cur = $m * 100 + $d;
  $a = $m1 * 100 + $d1;
  $b = $m2 * 100 + $d2;
  if ($a <= $b) return $cur >= $a && $cur <= $b;
  // через год (дек–янв)
  return $cur >= $a || $cur <= $b;
}

function vibe_active_frame(?DateTimeInterface $now = null): ?array {
  $now = $now ?: new DateTime('now', new DateTimeZone('Europe/Moscow'));
  $m = (int)$now->format('n');
  $d = (int)$now->format('j');
  $cat = vibe_frame_catalog();

  // 1) Сначала «настоящие» праздники по дате (узкие окна)
  $priority = [
    'new_year','christmas','valentine','defender','women','april_fools','cosmonautics',
    'easter','victory','russia_day','ivan_kupala','knowledge','teacher','halloween','unity','mother','summer'
  ];
  foreach ($priority as $code) {
    if (empty($cat[$code])) continue;
    foreach ($cat[$code]['months'] as $win) {
      if (vibe_in_window($m, $d, $win)) {
        return array_merge(['code' => $code], $cat[$code]);
      }
    }
  }

  // 2) Вечные мемы — всегда, если нет другого праздника
  // «Я календарь переверну… и снова 3 сентября»
  if (!empty($cat['sept3'])) {
    return array_merge(['code' => 'sept3'], $cat['sept3']);
  }
  foreach ($cat as $code => $def) {
    if (!empty($def['eternal'])) {
      return array_merge(['code' => $code], $def);
    }
  }
  return null;
}

/** CSS-класс рамки для ника */
function vibe_nick_frame_class(?array $user = null): string {
  vibe_ensure_schema();
  if ($user && !empty($user['vibe_frame_override'])) {
    $code = preg_replace('/[^a-z0-9_]/', '', (string)$user['vibe_frame_override']);
    $cat = vibe_frame_catalog();
    if ($code && isset($cat[$code])) return $cat[$code]['class'];
  }
  $f = vibe_active_frame();
  return $f ? $f['class'] : '';
}

function vibe_nick_wrap(string $htmlNick, ?array $user = null): string {
  $cls = vibe_nick_frame_class($user);
  if ($cls === '') return $htmlNick;
  $f = vibe_active_frame();
  $emoji = $f['emoji'] ?? '✨';
  return '<span class="vibe-nick-frame ' . htmlspecialchars($cls, ENT_QUOTES) . '" title="' . htmlspecialchars($f['title'] ?? '', ENT_QUOTES) . '">'
    . '<span class="vibe-nick-emoji" aria-hidden="true">' . $emoji . '</span>'
    . $htmlNick
    . '</span>';
}

/** Ачивки */
function vibe_achievement_defs(): array {
  return [
    'first_post' => ['title' => 'Первый пост', 'emoji' => '✍️', 'desc' => 'Написал сообщение на форуме'],
    'likes_10' => ['title' => 'Вкусный контент', 'emoji' => '❤️', 'desc' => '10 лайков на постах'],
    'week_here' => ['title' => 'Неделя с нами', 'emoji' => '📅', 'desc' => '7 дней на платформе'],
    'month_here' => ['title' => 'Свой человек', 'emoji' => '🏠', 'desc' => '30 дней на платформе'],
    'verified_vibe' => ['title' => 'Проверенный', 'emoji' => '✅', 'desc' => 'Получил галочку'],
    'channel_fan' => ['title' => 'Фанат эфира', 'emoji' => '📺', 'desc' => 'Добавил канал в избранное'],
    'first_video' => ['title' => 'Автор', 'emoji' => '🎬', 'desc' => 'Опубликовал видео'],
  ];
}

function vibe_unlock(int $userId, string $code): void {
  if ($userId <= 0) return;
  vibe_ensure_schema();
  $defs = vibe_achievement_defs();
  if (!isset($defs[$code])) return;
  try {
    db()->prepare('INSERT IGNORE INTO user_achievements (user_id, code) VALUES (?,?)')->execute([$userId, $code]);
  } catch (Throwable $e) {}
}

function vibe_user_achievements(int $userId): array {
  vibe_ensure_schema();
  if ($userId <= 0) return [];
  try {
    $st = db()->prepare('SELECT code, unlocked_at FROM user_achievements WHERE user_id = ?');
    $st->execute([$userId]);
    $have = [];
    foreach ($st->fetchAll() ?: [] as $r) $have[$r['code']] = $r['unlocked_at'];
  } catch (Throwable $e) {
    return [];
  }
  $out = [];
  foreach (vibe_achievement_defs() as $code => $def) {
    if (isset($have[$code])) {
      $out[] = array_merge($def, ['code' => $code, 'unlocked_at' => $have[$code]]);
    }
  }
  return $out;
}

function vibe_check_time_based(array $user): void {
  $uid = (int)($user['id'] ?? 0);
  if ($uid <= 0) return;
  $created = strtotime((string)($user['created_at'] ?? '')) ?: 0;
  if ($created <= 0) return;
  $days = (time() - $created) / 86400;
  if ($days >= 7) vibe_unlock($uid, 'week_here');
  if ($days >= 30) vibe_unlock($uid, 'month_here');
  if (!empty($user['is_verified'])) vibe_unlock($uid, 'verified_vibe');
}

/** Реакции форума */
function vibe_reaction_toggle(int $postId, int $userId, string $emoji): array {
  vibe_ensure_schema();
  $allowed = ['🔥','😂','👏','❤️','😮','😢','🎉','👍'];
  if (!in_array($emoji, $allowed, true) || $postId <= 0 || $userId <= 0) {
    return ['ok' => false, 'error' => 'bad'];
  }
  try {
    $st = db()->prepare('SELECT emoji FROM forum_post_reactions WHERE post_id=? AND user_id=?');
    $st->execute([$postId, $userId]);
    $cur = $st->fetchColumn();
    if ($cur === $emoji) {
      db()->prepare('DELETE FROM forum_post_reactions WHERE post_id=? AND user_id=?')->execute([$postId, $userId]);
      $mine = null;
    } else {
      db()->prepare(
        'INSERT INTO forum_post_reactions (post_id, user_id, emoji) VALUES (?,?,?)
         ON DUPLICATE KEY UPDATE emoji=VALUES(emoji), created_at=CURRENT_TIMESTAMP'
      )->execute([$postId, $userId, $emoji]);
      $mine = $emoji;
    }
    $counts = vibe_reaction_counts($postId);
    return ['ok' => true, 'my' => $mine, 'counts' => $counts];
  } catch (Throwable $e) {
    return ['ok' => false, 'error' => $e->getMessage()];
  }
}

function vibe_reaction_counts(int $postId): array {
  try {
    $st = db()->prepare('SELECT emoji, COUNT(*) c FROM forum_post_reactions WHERE post_id=? GROUP BY emoji');
    $st->execute([$postId]);
    $out = [];
    foreach ($st->fetchAll() ?: [] as $r) $out[$r['emoji']] = (int)$r['c'];
    return $out;
  } catch (Throwable $e) {
    return [];
  }
}

function vibe_reactions_for_posts(array $postIds): array {
  $postIds = array_values(array_filter(array_map('intval', $postIds)));
  if (!$postIds) return [];
  try {
    $in = implode(',', $postIds);
    $rows = db()->query("SELECT post_id, emoji, COUNT(*) c FROM forum_post_reactions WHERE post_id IN ($in) GROUP BY post_id, emoji")->fetchAll() ?: [];
    $out = [];
    foreach ($rows as $r) $out[(int)$r['post_id']][$r['emoji']] = (int)$r['c'];
    return $out;
  } catch (Throwable $e) {
    return [];
  }
}

/** Watching — редкий heartbeat */
function vibe_watching_ping(int $channelId, string $sessionKey, int $userId = 0): int {
  vibe_ensure_schema();
  if ($channelId <= 0 || $sessionKey === '') return 0;
  $sessionKey = substr(preg_replace('/[^a-zA-Z0-9_-]/', '', $sessionKey), 0, 64);
  try {
    db()->prepare(
      'INSERT INTO channel_watching (channel_id, user_id, session_key, last_seen) VALUES (?,?,?,NOW())
       ON DUPLICATE KEY UPDATE last_seen=NOW(), user_id=VALUES(user_id)'
    )->execute([$channelId, $userId, $sessionKey]);
    // чистка старше 5 мин
    db()->exec('DELETE FROM channel_watching WHERE last_seen < (NOW() - INTERVAL 5 MINUTE)');
    $st = db()->prepare('SELECT COUNT(*) FROM channel_watching WHERE channel_id=? AND last_seen >= (NOW() - INTERVAL 3 MINUTE)');
    $st->execute([$channelId]);
    return (int)$st->fetchColumn();
  } catch (Throwable $e) {
    return 0;
  }
}

function vibe_qr_url(string $url): string {
  // клиентский QR через API-less canvas в JS; сервер только отдаёт URL
  return $url;
}
