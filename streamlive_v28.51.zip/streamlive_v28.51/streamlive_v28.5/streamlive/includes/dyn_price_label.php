<?php
/**
 * echo dyn_price_label_html($row, 'video'|'channel'|'article');
 */
if (!function_exists('dyn_price_label_html')) {
  function dyn_price_label_html(array $row, string $type = 'video'): string {
    if (!function_exists('dyn_price_calc')) {
      if (is_file(__DIR__ . '/dynamic_price.php')) require_once __DIR__ . '/dynamic_price.php';
    }
    if (!function_exists('dyn_price_calc')) return '';
    $c = dyn_price_calc($row, $type);
    if ($c['base'] <= 0) return '';
    $cur = htmlspecialchars((string)($row['premium_currency'] ?? $row['currency'] ?? 'RUB'), ENT_QUOTES);
    $html = '<span class="sl-dyn-price">';
    if ($c['enabled'] && $c['multiplier'] > 1.001) {
      $html .= '<span style="text-decoration:line-through;opacity:.55;margin-right:6px">' .
        number_format($c['base'], 2) . ' ' . $cur . '</span>';
      $html .= '<b style="color:#fbbf24">' . number_format($c['price'], 2) . ' ' . $cur . '</b>';
      $html .= ' <small style="opacity:.7">(×' . rtrim(rtrim(number_format($c['multiplier'], 2), '0'), '.') .
        ' · ' . (int)$c['views'] . ' просм.)</small>';
    } else {
      $html .= '<b>' . number_format($c['price'], 2) . ' ' . $cur . '</b>';
    }
    return $html . '</span>';
  }
}
