<?php
/**
 * Смайл строго по тексту названия. Свой CSS = только свой стиль + смайл.
 */
if (!function_exists('prefix_emoji_by_title')) {
  function prefix_emoji_by_title(string $title): string {
    $t = function_exists('mb_strtolower') ? mb_strtolower(trim($title)) : strtolower(trim($title));
    if ($t === '') return '🏷️';
    $list = [
      ['media partner', '📺'],
      ['media-partner', '📺'],
      ['mediapartner', '📺'],
      ['медиа партнёр', '📺'],
      ['медиа партнер', '📺'],
      ['медиапартнёр', '📺'],
      ['content maker', '🎬'],
      ['content-maker', '🎬'],
      ['contentmaker', '🎬'],
      ['контент-мейкер', '🎬'],
      ['контент мейкер', '🎬'],
      ['контентмейкер', '🎬'],
      ['гл. администратор', '👑'],
      ['главный администратор', '👑'],
      ['администратор', '🛡️'],
      ['admin', '🛡️'],
      ['ст. модератор', '🔨'],
      ['старший модератор', '🔨'],
      ['модератор', '⚖️'],
      ['moderator', '⚖️'],
      ['хелпер', '💬'],
      ['helper', '💬'],
      ['тех. поддержка', '🎧'],
      ['тех поддержка', '🎧'],
      ['поддержка', '🎧'],
      ['официальный автор', '✅'],
      ['официальный', '✅'],
      ['официал', '✅'],
      ['автор', '📝'],
      ['разработчик', '💻'],
      ['кодер', '⌨️'],
      ['скриптер', '📜'],
      ['маппер', '🗺️'],
      ['редактор', '✏️'],
      ['стример', '📡'],
      ['продавец', '🛒'],
      ['seller', '🛒'],
      ['покупатель', '🛍️'],
      ['vip', '⭐'],
      ['premium', '💎'],
      ['sponsor', '💰'],
      ['партнёр', '🤝'],
      ['партнер', '🤝'],
      ['partner', '🤝'],
      ['верифицирован', '✅'],
      ['заблокирован', '🔒'],
      ['бан', '🔒'],
      ['предупреждение', '⚠️'],
      ['новичок', '🌱'],
      ['активный', '⚡'],
      ['легенда', '🏆'],
      ['команда проекта', '👥'],
      ['команда', '👥'],
      ['team', '👥'],
      ['ticket', '🎫'],
      ['билет', '🎫'],
    ];
    usort($list, static fn($a, $b) => mb_strlen($b[0]) <=> mb_strlen($a[0]));
    foreach ($list as [$n, $e]) {
      if ($n !== '' && mb_strpos($t, $n) !== false) return $e;
    }
    return '🏷️';
  }
}

if (!function_exists('prefix_class_by_title')) {
  function prefix_class_by_title(string $title): string {
    $t = function_exists('mb_strtolower') ? mb_strtolower(trim($title)) : strtolower(trim($title));
    $pairs = [
      ['media partner', 'content'], ['mediapartner', 'content'], ['медиа', 'content'],
      ['content maker', 'content'], ['contentmaker', 'content'], ['контент', 'content'],
      ['админ', 'admin'], ['admin', 'admin'],
      ['мод', 'moder'], ['moderator', 'moder'],
      ['хелпер', 'helper'], ['helper', 'helper'],
      ['поддерж', 'staff'], ['staff', 'staff'], ['команда', 'staff'], ['team', 'staff'],
      ['официал', 'professional'], ['автор', 'editor'],
      ['разработ', 'dev'], ['кодер', 'dev'], ['скрипт', 'dev'],
      ['маппер', 'editor'], ['редактор', 'editor'],
      ['продав', 'seller'], ['seller', 'seller'], ['покупат', 'buyer'],
      ['vip', 'vip'], ['premium', 'premium'], ['sponsor', 'partner'], ['партн', 'partner'], ['partner', 'partner'],
      ['вериф', 'professional'], ['блок', 'banned'], ['бан', 'banned'],
      ['предуп', 'warn'], ['нович', 'user'], ['актив', 'active'], ['легенд', 'legend'],
      ['стрим', 'stream'], ['билет', 'user'], ['ticket', 'user'],
    ];
    foreach ($pairs as [$n, $c]) {
      if (mb_strpos($t, $n) !== false) return $c;
    }
    return 'user';
  }
}

if (!function_exists('prefix_pawno_css_for_class')) {
  function prefix_pawno_css_for_class(string $class): string {
    $g = [
      'admin' => 'linear-gradient(270deg,#fb0,#f00)',
      'moder' => 'linear-gradient(90deg,#4b6cb7,#182848)',
      'staff' => 'linear-gradient(90deg,#1ba39c,#23ccc4)',
      'seller' => 'linear-gradient(315deg,#ff294d,#ff5c77)',
      'legend' => 'linear-gradient(315deg,#ccad00,#ffd700)',
      'professional' => 'linear-gradient(315deg,#008000,#00b300)',
      'editor' => 'linear-gradient(315deg,#5f72be,#9921e8)',
      'active' => 'linear-gradient(315deg,#06f,#39f)',
      'user' => 'linear-gradient(90deg,#62cff4,#2c67f2)',
      'banned' => 'linear-gradient(90deg,#7f7f7f,#2f2f2f)',
      'vip' => 'linear-gradient(90deg,#f59e0b,#eab308)',
      'premium' => 'linear-gradient(90deg,#a855f7,#6366f1)',
      'dev' => 'linear-gradient(90deg,#7c3aed,#4c1d95)',
      'helper' => 'linear-gradient(90deg,#0891b2,#0e7490)',
      'warn' => 'linear-gradient(90deg,#ea580c,#c2410c)',
      'partner' => 'linear-gradient(90deg,#db2777,#9d174d)',
      'stream' => 'linear-gradient(90deg,#e11d48,#be123c)',
      'content' => 'linear-gradient(90deg,#a855f7,#7e22ce)',
      'buyer' => 'linear-gradient(90deg,#65a30d,#3f6212)',
    ];
    $bg = $g[$class] ?? $g['user'];
    $color = in_array($class, ['legend', 'vip'], true) ? '#111' : '#fff';
    return 'display:inline-flex;align-items:center;gap:5px;padding:3px 8px;border-radius:3px;font-size:11px;font-weight:600;text-transform:uppercase;color:'.$color.';background-image:'.$bg.';background-size:200% 100%;animation:AnimBanner 10s ease infinite;line-height:1.35;margin-right:4px;vertical-align:middle';
  }
}

if (!function_exists('prefix_has_own_css')) {
  function prefix_has_own_css(?array $prefix): bool {
    $css = trim((string)($prefix['css'] ?? ''));
    if ($css === '') return false;
    if (stripos($css, 'AnimBanner') !== false) return false;
    return true;
  }
}

if (!function_exists('prefix_pawno_render_html')) {
  function prefix_pawno_render_html(?array $prefix): string {
    if (!$prefix) return '';
    $title = trim((string)($prefix['title'] ?? ''));
    if ($title === '') return '';
    $emoji = prefix_emoji_by_title($title);
    $safeTitle = htmlspecialchars($title, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $css = trim((string)($prefix['css'] ?? ''));
    $css = preg_replace('/[<>]|expression\s*\(|javascript\s*:/i', '', $css) ?? '';

    if (prefix_has_own_css($prefix)) {
      $style = 'display:inline-flex;align-items:center;gap:5px;vertical-align:middle;' . $css;
      return '<span class="user-prefix user-prefix--custom" style="'.htmlspecialchars($style, ENT_QUOTES, 'UTF-8').'">'
        .'<span class="ub-ico" aria-hidden="true">'.$emoji.'</span><strong>'.$safeTitle.'</strong></span>';
    }
    $class = prefix_class_by_title($title);
    $safeClass = preg_replace('/[^a-z0-9_-]/i', '', $class) ?: 'user';
    $style = prefix_pawno_css_for_class($safeClass);
    return '<span class="userBanner userBannerLight userBanner--'.$safeClass.' user-prefix" style="'.htmlspecialchars($style, ENT_QUOTES, 'UTF-8').'">'
      .'<span class="ub-ico" aria-hidden="true">'.$emoji.'</span><strong>'.$safeTitle.'</strong></span>';
  }
}

if (!function_exists('prefix_pawno_meta')) {
  function prefix_pawno_meta(string $title): array {
    return [prefix_class_by_title($title), prefix_emoji_by_title($title)];
  }
}
