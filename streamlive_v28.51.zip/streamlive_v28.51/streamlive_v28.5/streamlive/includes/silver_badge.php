<?php
/**
 * Серебряная галочка пользователя приложения (расширение StreamLife App).
 * В render username: if (user_has_silver_app_badge($userId)) echo silver html
 */
if (!function_exists('user_has_silver_app_badge')) {
  function user_has_silver_app_badge(?int $userId = null): bool {
    if (isset($_COOKIE['sl_native_app']) && $_COOKIE['sl_native_app'] === '1') {
      // для текущего посетителя
      if ($userId === null) return true;
    }
    try {
      if (!function_exists('db') || !$userId) return !empty($_COOKIE['sl_native_app']);
      // optional table native_app_sessions
      $st = db()->prepare('SELECT 1 FROM native_app_devices WHERE user_id = ? AND last_seen > DATE_SUB(NOW(), INTERVAL 14 DAY) LIMIT 1');
      $st->execute([$userId]);
      return (bool)$st->fetchColumn();
    } catch (Throwable $e) {
      return !empty($_COOKIE['sl_native_app']);
    }
  }
}
if (!function_exists('render_silver_check')) {
  function render_silver_check(): string {
    return '<span class="sl-silver-check" title="StreamLife App" style="display:inline-flex;width:16px;height:16px;border-radius:50%;background:linear-gradient(135deg,#e2e8f0,#94a3b8);color:#0f172a;font-size:10px;font-weight:900;align-items:center;justify-content:center;margin-left:4px">✓</span>';
  }
}
