<?php
/**
 * Галочка (is_verified):
 *  - новый контент ВСЕГДА на модерации (pending), кроме admin
 *  - при ЗАХОДЕ на сайт: свой pending старше 24ч → approve
 *  - не зашёл — так и висит на модерации
 * Без галочки: pending навсегда (пока модератор не одобрит)
 * Лимит создания: 1 канал / 1 тема / 1 ответ на форуме за 24ч (не admin)
 * Платные каналы/видео не трогаем.
 */
if (!function_exists('user_has_verified_badge')) {
  function user_has_verified_badge(?array $user): bool {
    if (!$user) return false;
    if (!empty($user['role']) && $user['role'] === 'admin') return true;
    return !empty($user['is_verified']);
  }
}

if (!function_exists('user_is_admin')) {
  function user_is_admin(?array $user): bool {
    return $user && !empty($user['role']) && $user['role'] === 'admin';
  }
}

if (!function_exists('verified_video_status')) {
  /** admin → published; все остальные → pending */
  function verified_video_status(?array $user): string {
    return user_is_admin($user) ? 'published' : 'pending';
  }
}

if (!function_exists('verified_channel_status')) {
  function verified_channel_status(?array $user): string {
    return user_is_admin($user) ? 'approved' : 'pending';
  }
}

if (!function_exists('verified_mod_status')) {
  function verified_mod_status(?array $user): string {
    return user_is_admin($user) ? 'approved' : 'pending';
  }
}

if (!function_exists('verified_rate_limit_ok')) {
  /**
   * Лимит 24ч на создание.
   * $kind: channel | forum_thread | forum_post | video | article
   * @return array{ok:bool,error?:string,wait_hours?:float}
   */
  function verified_rate_limit_ok(?array $user, string $kind): array {
    if (!$user || empty($user['id'])) {
      return ['ok' => false, 'error' => 'Войдите в аккаунт'];
    }
    if (user_is_admin($user)) {
      return ['ok' => true];
    }
    $uid = (int)$user['id'];
    $since = date('Y-m-d H:i:s', time() - 86400);
    $map = [
      'channel' => ["SELECT created_at FROM channels WHERE owner_id = ? AND created_at >= ? ORDER BY created_at DESC LIMIT 1", 'канал'],
      'forum_thread' => ["SELECT created_at FROM forum_threads WHERE user_id = ? AND created_at >= ? ORDER BY created_at DESC LIMIT 1", 'тему'],
      'forum_post' => ["SELECT created_at FROM forum_posts WHERE user_id = ? AND created_at >= ? ORDER BY created_at DESC LIMIT 1", 'ответ'],
      'video' => ["SELECT created_at FROM videos WHERE user_id = ? AND created_at >= ? ORDER BY created_at DESC LIMIT 1", 'видео'],
      'article' => ["SELECT created_at FROM content_articles WHERE user_id = ? AND created_at >= ? ORDER BY created_at DESC LIMIT 1", 'статью'],
    ];
    if (!isset($map[$kind])) {
      return ['ok' => true];
    }
    try {
      $st = db()->prepare($map[$kind][0]);
      $st->execute([$uid, $since]);
      $row = $st->fetch();
      if ($row && !empty($row['created_at'])) {
        $ts = strtotime($row['created_at']);
        $left = 86400 - (time() - $ts);
        if ($left > 0) {
          $h = round($left / 3600, 1);
          return [
            'ok' => false,
            'error' => 'Лимит 24 часа: следующее создание «' . $map[$kind][1] . '» через ~' . $h . ' ч.',
            'wait_hours' => $h,
          ];
        }
      }
    } catch (Throwable $e) {
      // таблицы может не быть — не блокируем
    }
    return ['ok' => true];
  }
}

if (!function_exists('verified_flush_pending_for_user')) {
  /**
   * Только для is_verified (или admin):
   * pending/created_at <= now-24h → approved/published.
   * Старые и новые — все, что старше суток.
   * Вызов при заходе на сайт. Не зашёл — висит.
   */
  function verified_flush_pending_for_user(int $userId): int {
    if ($userId <= 0) return 0;

    try {
      if (session_status() === PHP_SESSION_ACTIVE) {
        $last = (int)($_SESSION['_vf_flush_at'] ?? 0);
        // не чаще раза в 5 минут
        if ($last && (time() - $last) < 60) return 0;
        $_SESSION['_vf_flush_at'] = time();
      }
    } catch (Throwable $e) {}

    try {
      $st = db()->prepare('SELECT is_verified, role FROM users WHERE id = ? LIMIT 1');
      $st->execute([$userId]);
      $u = $st->fetch();
      if (!$u) return 0;
      $ok = !empty($u['is_verified']) || (($u['role'] ?? '') === 'admin');
      if (!$ok) return 0;
    } catch (Throwable $e) {
      return 0;
    }

    $n = 0;
    $dayAgo = date('Y-m-d H:i:s', time() - 86400);

    $jobs = [
      ["UPDATE videos SET status='published' WHERE user_id=? AND status='pending' AND created_at<=?", [$userId, $dayAgo]],
      ["UPDATE channels SET status='approved' WHERE owner_id=? AND status='pending' AND created_at<=?", [$userId, $dayAgo]],
    ];
    foreach ($jobs as $job) {
      try {
        $q = db()->prepare($job[0]);
        $q->execute($job[1]);
        $n += $q->rowCount();
      } catch (Throwable $e) {}
    }

    // forum
    try {
      if (function_exists('table_column_exists') && table_column_exists('forum_threads', 'mod_status')) {
        $q = db()->prepare(
          "UPDATE forum_threads SET mod_status='approved'
           WHERE user_id=? AND mod_status='pending' AND created_at<=?"
        );
        $q->execute([$userId, $dayAgo]);
        $n += $q->rowCount();
      }
    } catch (Throwable $e) {}
    try {
      if (function_exists('table_column_exists') && table_column_exists('forum_posts', 'mod_status')) {
        $q = db()->prepare(
          "UPDATE forum_posts SET mod_status='approved'
           WHERE user_id=? AND mod_status='pending' AND created_at<=?"
        );
        $q->execute([$userId, $dayAgo]);
        $n += $q->rowCount();
      }
    } catch (Throwable $e) {}

    try {
      if (is_file(__DIR__ . '/content_articles.php')) {
        require_once __DIR__ . '/content_articles.php';
        if (function_exists('content_articles_ensure_table')) content_articles_ensure_table();
      }
      $q = db()->prepare(
        "UPDATE content_articles SET status='published'
         WHERE user_id=? AND (status='pending' OR status='' OR status IS NULL) AND created_at<=?"
      );
      $q->execute([$userId, $dayAgo]);
      $n += $q->rowCount();
    } catch (Throwable $e) {}

    return $n;
  }
}

if (!function_exists('verified_moderation_boot')) {
  function verified_moderation_boot(): void {
    try {
      $uid = 0;
      if (function_exists('current_user')) {
        $u = current_user();
        if ($u && !empty($u['id'])) $uid = (int)$u['id'];
      }
      if (!$uid && !empty($_SESSION['user_id'])) {
        $uid = (int)$_SESSION['user_id'];
      }
      if ($uid > 0) {
        verified_flush_pending_for_user($uid);
      }
    } catch (Throwable $e) {}
  }
}


if (!function_exists('verified_try_flush_current_user')) {
  /** Для embed/страниц без полного header */
  function verified_try_flush_current_user(): int {
    try {
      if (!function_exists('verified_flush_pending_for_user')) return 0;
      $uid = 0;
      if (function_exists('current_user')) {
        $u = current_user();
        if ($u && !empty($u['id'])) $uid = (int)$u['id'];
      }
      if (!$uid && !empty($_SESSION['user_id'])) $uid = (int)$_SESSION['user_id'];
      if ($uid <= 0) return 0;
      return verified_flush_pending_for_user($uid);
    } catch (Throwable $e) {
      return 0;
    }
  }
}
