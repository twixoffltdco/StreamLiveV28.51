<?php
/**
 * Баланс StreamLive (рубли на счёте).
 * Новым и старым без баланса — 22 ₽.
 * За каждый день сессии (вход/активность) — +1 ₽ один раз в сутки.
 */
function wallet_ensure(): void {
  static $done = false;
  if ($done) return;
  $done = true;
  try {
    db()->exec(
      "CREATE TABLE IF NOT EXISTS user_wallets (
        user_id INT UNSIGNED NOT NULL PRIMARY KEY,
        balance DECIMAL(12,2) NOT NULL DEFAULT 0,
        last_daily_at DATE NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
    db()->exec(
      "CREATE TABLE IF NOT EXISTS wallet_ledger (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        amount DECIMAL(12,2) NOT NULL,
        reason VARCHAR(64) NOT NULL DEFAULT '',
        meta VARCHAR(255) NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_user (user_id),
        KEY idx_created (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
  } catch (Throwable $e) {}
}

function wallet_get(int $userId): array {
  wallet_ensure();
  if ($userId <= 0) return ['balance' => 0.0, 'last_daily_at' => null];
  try {
    $st = db()->prepare('SELECT balance, last_daily_at FROM user_wallets WHERE user_id=?');
    $st->execute([$userId]);
    $r = $st->fetch();
    if ($r) {
      return ['balance' => (float)$r['balance'], 'last_daily_at' => $r['last_daily_at']];
    }
    // Стартовый грант 22 ₽
    db()->prepare('INSERT INTO user_wallets (user_id, balance, last_daily_at) VALUES (?,?,NULL)')
      ->execute([$userId, 22.00]);
    try {
      db()->prepare('INSERT INTO wallet_ledger (user_id, amount, reason, meta) VALUES (?,?,?,?)')
        ->execute([$userId, 22.00, 'welcome_grant', 'Стартовый баланс 22 ₽']);
    } catch (Throwable $e) {}
    return ['balance' => 22.0, 'last_daily_at' => null];
  } catch (Throwable $e) {
    return ['balance' => 0.0, 'last_daily_at' => null];
  }
}

function wallet_balance(int $userId): float {
  return (float)(wallet_get($userId)['balance'] ?? 0);
}

function wallet_ledger(int $userId, float $amount, string $reason, string $meta = ''): bool {
  wallet_ensure();
  try {
    db()->prepare('INSERT INTO wallet_ledger (user_id, amount, reason, meta) VALUES (?,?,?,?)')
      ->execute([$userId, $amount, mb_substr($reason, 0, 64), mb_substr($meta, 0, 255)]);
    return true;
  } catch (Throwable $e) {
    return false;
  }
}

function wallet_credit(int $userId, float $amount, string $reason, string $meta = ''): bool {
  if ($userId <= 0 || $amount <= 0) return false;
  wallet_get($userId); // ensure row
  try {
    db()->prepare('UPDATE user_wallets SET balance = balance + ? WHERE user_id=?')->execute([$amount, $userId]);
    wallet_ledger($userId, $amount, $reason, $meta);
    return true;
  } catch (Throwable $e) {
    return false;
  }
}

function wallet_debit(int $userId, float $amount, string $reason, string $meta = ''): array {
  if ($userId <= 0 || $amount <= 0) return ['ok' => false, 'error' => 'Сумма некорректна'];
  $w = wallet_get($userId);
  if ((float)$w['balance'] + 0.0001 < $amount) {
    return ['ok' => false, 'error' => 'Недостаточно средств (баланс ' . number_format((float)$w['balance'], 2, '.', '') . ' ₽)'];
  }
  try {
    $st = db()->prepare('UPDATE user_wallets SET balance = balance - ? WHERE user_id=? AND balance >= ?');
    $st->execute([$amount, $userId, $amount]);
    if ($st->rowCount() < 1) {
      return ['ok' => false, 'error' => 'Недостаточно средств'];
    }
    wallet_ledger($userId, -$amount, $reason, $meta);
    return ['ok' => true, 'error' => ''];
  } catch (Throwable $e) {
    return ['ok' => false, 'error' => $e->getMessage()];
  }
}

/** +1 ₽ раз в календарный день при активности (сессия/вход) */
function wallet_daily_tick(int $userId): void {
  if ($userId <= 0) return;
  $w = wallet_get($userId);
  $today = date('Y-m-d');
  if (($w['last_daily_at'] ?? '') === $today) return;
  try {
    $st = db()->prepare('UPDATE user_wallets SET last_daily_at=?, balance = balance + 1 WHERE user_id=? AND (last_daily_at IS NULL OR last_daily_at < ?)');
    $st->execute([$today, $userId, $today]);
    if ($st->rowCount() > 0) {
      wallet_ledger($userId, 1.0, 'daily_login', 'Ежедневный бонус +1 ₽');
    }
  } catch (Throwable $e) {}
}

/** Выдать 22 ₽ всем, у кого ещё нет кошелька (разово из админки или cron) */
function wallet_grant_missing_users(int $limit = 500): int {
  wallet_ensure();
  $n = 0;
  try {
    $ids = db()->query(
      "SELECT u.id FROM users u
       LEFT JOIN user_wallets w ON w.user_id = u.id
       WHERE w.user_id IS NULL
       ORDER BY u.id ASC LIMIT " . (int)$limit
    )->fetchAll(PDO::FETCH_COLUMN) ?: [];
    foreach ($ids as $id) {
      wallet_get((int)$id);
      $n++;
    }
  } catch (Throwable $e) {}
  return $n;
}
