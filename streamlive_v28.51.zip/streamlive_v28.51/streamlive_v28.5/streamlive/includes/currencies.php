<?php
/** Валюты как в статьях + курс к ₽ для списания с кошелька (кошелёк в RUB). */
if (!function_exists('wallet_currencies')) {
  function wallet_currencies(): array {
    return [
      'RUB' => ['name' => 'Рубль', 'symbol' => '₽', 'rate' => 1.0],
      'USD' => ['name' => 'Доллар', 'symbol' => '$', 'rate' => 90.0],
      'EUR' => ['name' => 'Евро', 'symbol' => '€', 'rate' => 98.0],
      'UAH' => ['name' => 'Гривна', 'symbol' => '₴', 'rate' => 2.4],
      'KZT' => ['name' => 'Тенге', 'symbol' => '₸', 'rate' => 0.18],
      'BYN' => ['name' => 'Бел. рубль', 'symbol' => 'Br', 'rate' => 28.0],
    ];
  }
}
if (!function_exists('wallet_to_rub')) {
  function wallet_to_rub(float $amount, string $currency = 'RUB'): float {
    $c = strtoupper(trim($currency) ?: 'RUB');
    $list = wallet_currencies();
    $rate = (float)($list[$c]['rate'] ?? 1.0);
    return round($amount * $rate, 2);
  }
}
if (!function_exists('wallet_currency_select_html')) {
  function wallet_currency_select_html(string $name = 'currency', string $selected = 'RUB'): string {
    $html = '<select name="' . htmlspecialchars($name, ENT_QUOTES) . '">';
    foreach (wallet_currencies() as $code => $meta) {
      $sel = strtoupper($selected) === $code ? ' selected' : '';
      $html .= '<option value="' . $code . '"' . $sel . '>' . $code . ' (' . $meta['symbol'] . ')</option>';
    }
    return $html . '</select>';
  }
}
