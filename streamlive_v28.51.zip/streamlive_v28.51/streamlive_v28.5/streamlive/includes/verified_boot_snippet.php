<?php
/**
 * Вставить в includes/header.php СРАЗУ после подключения auth / current_user:
 *
 *   if (is_file(__DIR__ . '/verified_moderation.php')) {
 *     require_once __DIR__ . '/verified_moderation.php';
 *     if (function_exists('verified_moderation_boot')) verified_moderation_boot();
 *   }
 */
if (is_file(__DIR__ . '/verified_moderation.php')) {
  require_once __DIR__ . '/verified_moderation.php';
  if (function_exists('verified_moderation_boot')) {
    verified_moderation_boot();
  }
}
