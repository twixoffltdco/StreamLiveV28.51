<?php
if (!isset($profileUser) || empty($profileUser['id'])) {
  echo '<div class="pg-empty">Нет данных</div>';
  return;
}
if (!is_file(__DIR__ . '/streampedia.php')) {
  echo '<div class="pg-empty">StreamPedia не подключена</div>';
  return;
}
require_once __DIR__ . '/streampedia.php';
try { streampedia_ensure(); } catch (Throwable $e) {}
$contribs = function_exists('streampedia_user_contribs') ? streampedia_user_contribs((int)$profileUser['id'], 40) : [];
if (!$contribs) {
  echo '<div class="pg-empty">Пока нет вклада в вики-проекты</div>';
  return;
}
echo '<p style="font-size:13px;opacity:.7;margin:0 0 10px">Правок: ' . count($contribs) . '</p><div class="pg-list">';
foreach ($contribs as $c) {
  $d = (int)($c['delta'] ?? 0);
  $dTxt = ($d >= 0 ? '+' : '') . $d;
  $cls = $d >= 0 ? '#4ade80' : '#f87171';
  echo '<a href="/streampedia/page.php?wiki=' . urlencode($c['wiki_slug']) . '&page=' . urlencode($c['page_slug']) . '" style="display:flex;justify-content:space-between;gap:12px;padding:10px 12px;border-radius:12px;background:rgba(255,255,255,.04);margin-bottom:6px;text-decoration:none;color:inherit">';
  echo '<span><b>' . htmlspecialchars($c['title'], ENT_QUOTES, 'UTF-8') . '</b>';
  echo '<span style="opacity:.55;font-size:12px"> · ' . htmlspecialchars($c['wiki_title'], ENT_QUOTES, 'UTF-8') . '</span></span>';
  echo '<span style="font-weight:700;color:' . $cls . '">' . htmlspecialchars($dTxt, ENT_QUOTES, 'UTF-8') . '</span></a>';
}
echo '</div>';
