<?php
if (!isset($video) || !is_array($video)) return;
$uid = isset($user['id']) ? (int)$user['id'] : 0;
$price = (float)($video['price'] ?? $video['premium_price'] ?? 0);
if ($price <= 0 && empty($video['is_premium']) && empty($video['is_paid'])) return;
if ($uid && function_exists('wallet_has_video_access') && wallet_has_video_access($uid, (int)$video['id'])) return;
if ($uid && (int)($video['user_id'] ?? 0) === $uid) return;
$cur = htmlspecialchars((string)($video['currency'] ?? 'RUB'), ENT_QUOTES);
$bal = ($uid && function_exists('wallet_balance')) ? wallet_balance($uid) : 0;
?>
<div class="sl-paywall" style="padding:20px;border-radius:14px;background:#1a1a22;border:1px solid rgba(251,191,36,.3);text-align:center;margin:12px 0">
  <h3>🔒 Платное видео</h3>
  <p>Цена: <b><?= number_format($price, 2) ?> <?= $cur ?></b>
    <?php if ($uid): ?> · баланс: <b><?= number_format($bal, 2) ?> ₽</b><?php endif; ?></p>
  <?php if ($uid): ?>
  <form method="post" action="/video_pay.php">
    <input type="hidden" name="video_id" value="<?= (int)$video['id'] ?>">
    <button type="submit" class="btn btn-primary">Оплатить с баланса</button>
  </form>
  <?php else: ?>
  <a href="/auth/login.php">Войдите</a>
  <?php endif; ?>
</div>
<?php
