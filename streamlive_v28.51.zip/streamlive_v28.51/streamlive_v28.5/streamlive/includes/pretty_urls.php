<?php
/**
 * Красивые ссылки без .php
 * Подключать после functions.php при необходимости.
 */
if (!function_exists('sl_pretty')) {
  function sl_pretty(string $path): string {
    $path = '/' . ltrim($path, '/');
    // /channel.php?slug=x → /channel/x
    if (preg_match('#^/channel(?:-pc)?\.php\?slug=([^&]+)#i', $path, $m)) {
      $base = (stripos($path, 'channel-pc') !== false) ? 'channel-pc' : 'channel';
      return '/' . $base . '/' . rawurlencode(urldecode($m[1]));
    }
    if (preg_match('#^/video\.php\?slug=([^&]+)#i', $path, $m)) {
      return '/video/' . rawurlencode(urldecode($m[1]));
    }
    // /catalog.php → /catalog
    $path = preg_replace('#\.php(\?|$)#', '$1', $path);
    return $path;
  }
}
