<?php
/**
 * В video_import.php ПОСЛЕ fetch_video_meta / oembed_fetch_meta:
 *
 * require_once __DIR__.'/includes/thumbnail_proxy_fix.php';
 * $meta = fetch_video_meta($url, $platform);
 * $meta = sl_enrich_meta_thumbnail($meta, $url);
 * $thumbnail = $meta['thumbnail_url'] ?? '';
 *
 * В шаблоне превью:
 * <img src="<?= htmlspecialchars(video_thumb_url($video)) ?>" alt="">
 */
