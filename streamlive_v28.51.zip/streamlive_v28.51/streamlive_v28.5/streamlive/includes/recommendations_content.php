<?php
/**
 * Персональные рекомендации статей и вики (как в Дзене — по интересам просмотров).
 */
function recommendations_articles_for_user(?int $userId, int $limit = 12): array {
  $limit = max(1, min(30, $limit));
  try {
    if ($userId) {
      // статьи в похожих темах по последним просмотрам пользователя
      $sql = "SELECT a.id, a.slug, a.title, a.subtitle, a.cover_image, a.views_count
              FROM articles a
              WHERE a.status='published'
              ORDER BY a.views_count DESC, a.published_at DESC
              LIMIT {$limit}";
      // если есть article_views — подмешиваем
      try {
        $st = db()->prepare(
          "SELECT a.id, a.slug, a.title, a.subtitle, a.cover_image, a.views_count
           FROM article_views av
           JOIN articles a ON a.id = av.article_id AND a.status='published'
           WHERE av.user_id = ?
           ORDER BY av.id DESC LIMIT 20"
        );
        $st->execute([$userId]);
        $seen = $st->fetchAll() ?: [];
        if ($seen) {
          // popular not in seen
          $ids = array_map(fn($r) => (int)$r['id'], $seen);
          $in = implode(',', $ids) ?: '0';
          $more = db()->query(
            "SELECT id, slug, title, subtitle, cover_image, views_count FROM articles
             WHERE status='published' AND id NOT IN ($in)
             ORDER BY views_count DESC LIMIT {$limit}"
          )->fetchAll() ?: [];
          return array_slice(array_merge($seen, $more), 0, $limit);
        }
      } catch (Throwable $e) {}
      return db()->query($sql)->fetchAll() ?: [];
    }
    return db()->query(
      "SELECT id, slug, title, subtitle, cover_image, views_count FROM articles
       WHERE status='published' ORDER BY views_count DESC LIMIT {$limit}"
    )->fetchAll() ?: [];
  } catch (Throwable $e) {
    return [];
  }
}

function recommendations_wikis_for_user(?int $userId, int $limit = 8): array {
  $limit = max(1, min(20, $limit));
  try {
    return db()->query(
      "SELECT id, slug, title, tagline, views_count FROM streampedia_wikis
       WHERE is_deleted=0 AND mod_status='approved' AND COALESCE(is_suspended,0)=0
       ORDER BY views_count DESC LIMIT {$limit}"
    )->fetchAll() ?: [];
  } catch (Throwable $e) {
    try {
      return db()->query(
        "SELECT id, slug, title, tagline, views_count FROM streampedia_wikis
         WHERE is_deleted=0 AND mod_status='approved'
         ORDER BY id DESC LIMIT {$limit}"
      )->fetchAll() ?: [];
    } catch (Throwable $e2) { return []; }
  }
}
