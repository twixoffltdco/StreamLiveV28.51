<?php
/**
 * Префиксы тем в стиле XenForo/Pawno-Help.
 * echo forum_prefix_html($thread);
 */
if (!function_exists('forum_prefix_html')) {
  function forum_prefix_html($thread): string {
    if (is_array($thread)) {
      $pid = (int)($thread['prefix_id'] ?? 0);
      $label = (string)($thread['prefix_title'] ?? $thread['prefix_name'] ?? '');
      $color = (string)($thread['prefix_color'] ?? '#3b82f6');
      $bg = (string)($thread['prefix_bg'] ?? $color);
    } else {
      return '';
    }
    if ($label === '' && $pid > 0) {
      try {
        $st = db()->prepare('SELECT title, color, bg_color FROM forum_prefixes WHERE id=?');
        $st->execute([$pid]);
        $p = $st->fetch();
        if ($p) {
          $label = (string)($p['title'] ?? '');
          $color = (string)($p['color'] ?? '#fff');
          $bg = (string)($p['bg_color'] ?? $p['color'] ?? '#3b82f6');
        }
      } catch (Throwable $e) {
        try {
          $st = db()->prepare('SELECT name AS title, color FROM prefixes WHERE id=?');
          $st->execute([$pid]);
          $p = $st->fetch();
          if ($p) {
            $label = (string)$p['title'];
            $bg = (string)($p['color'] ?? '#3b82f6');
            $color = '#fff';
          }
        } catch (Throwable $e2) {}
      }
    }
    if ($label === '') return '';
    $label = htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
    $color = htmlspecialchars($color, ENT_QUOTES, 'UTF-8');
    $bg = htmlspecialchars($bg, ENT_QUOTES, 'UTF-8');
    return '<span class="xf-prefix" style="display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:700;margin-right:6px;vertical-align:middle;background:'
      . $bg . ';color:' . $color . '">' . $label . '</span>';
  }
}
