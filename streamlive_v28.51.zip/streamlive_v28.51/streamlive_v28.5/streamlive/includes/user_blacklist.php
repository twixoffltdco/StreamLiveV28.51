<?php
/**
 * Чёрный список пользователей (игнор), в духе форумных сливов.
 */
if (!function_exists('blacklist_ensure')) {
  function blacklist_ensure(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
      db()->exec("CREATE TABLE IF NOT EXISTS user_blacklist (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        blocked_id INT UNSIGNED NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_block (user_id, blocked_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }
}
if (!function_exists('blacklist_add')) {
  function blacklist_add(int $userId, int $blockedId): bool {
    if ($userId <= 0 || $blockedId <= 0 || $userId === $blockedId) return false;
    blacklist_ensure();
    try {
      db()->prepare('INSERT IGNORE INTO user_blacklist (user_id, blocked_id) VALUES (?,?)')->execute([$userId, $blockedId]);
      return true;
    } catch (Throwable $e) { return false; }
  }
}
if (!function_exists('blacklist_remove')) {
  function blacklist_remove(int $userId, int $blockedId): bool {
    blacklist_ensure();
    try {
      db()->prepare('DELETE FROM user_blacklist WHERE user_id=? AND blocked_id=?')->execute([$userId, $blockedId]);
      return true;
    } catch (Throwable $e) { return false; }
  }
}
if (!function_exists('blacklist_has')) {
  function blacklist_has(int $userId, int $blockedId): bool {
    blacklist_ensure();
    try {
      $st = db()->prepare('SELECT 1 FROM user_blacklist WHERE user_id=? AND blocked_id=?');
      $st->execute([$userId, $blockedId]);
      return (bool)$st->fetchColumn();
    } catch (Throwable $e) { return false; }
  }
}
if (!function_exists('blacklist_ids')) {
  function blacklist_ids(int $userId): array {
    blacklist_ensure();
    try {
      $st = db()->prepare('SELECT blocked_id FROM user_blacklist WHERE user_id=?');
      $st->execute([$userId]);
      return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN) ?: []);
    } catch (Throwable $e) { return []; }
  }
}
