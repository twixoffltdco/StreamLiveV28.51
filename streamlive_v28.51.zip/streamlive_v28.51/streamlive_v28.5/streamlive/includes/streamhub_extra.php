<?php
/** PR / Wiki / CI helpers — подключать после streamhub.php */
function streamhub_extra_ensure(): void {
  static $d = false;
  if ($d) return;
  $d = true;
  if (function_exists('streamhub_ensure')) streamhub_ensure();
  $f = __DIR__ . '/../sql/migrations/073_streamhub_pr_wiki_ci.sql';
  if (!is_file($f)) return;
  try {
    foreach (array_filter(array_map('trim', explode(';', file_get_contents($f)))) as $q) {
      if ($q === '') continue;
      try { db()->exec($q); } catch (Throwable $e) {}
    }
  } catch (Throwable $e) {}
}

function streamhub_next_pull_number(int $repoId): int {
  try {
    $st = db()->prepare('SELECT COALESCE(MAX(number),0)+1 FROM streamhub_pulls WHERE repo_id=?');
    $st->execute([$repoId]);
    return (int)$st->fetchColumn();
  } catch (Throwable $e) {
    return 1;
  }
}

/** Простой «CI»: симуляция пайплайна (queued → running → success/fail) */
function streamhub_ci_start(int $repoId, ?int $pullId = null, string $name = 'build'): int {
  streamhub_extra_ensure();
  $log = '[' . date('H:i:s') . "] Workflow started\n";
  $log .= "Runner: StreamHub CI (PHP shared)\n";
  $log .= "Repo #$repoId" . ($pullId ? " PR #$pullId" : '') . "\n";
  try {
    db()->prepare(
      'INSERT INTO streamhub_ci_runs (repo_id, pull_id, name, status, log_text, started_at) VALUES (?,?,?,?,?,NOW())'
    )->execute([$repoId, $pullId, $name, 'running', $log]);
    $id = (int)db()->lastInsertId();
    // deterministic demo result
    $ok = (($repoId + (int)$id) % 7) !== 0;
    $log .= $ok
      ? "[ok] lint passed\n[ok] tests passed\n[ok] pipeline success\n"
      : "[fail] step test_unit\nError: assertion failed (demo)\n";
    db()->prepare(
      'UPDATE streamhub_ci_runs SET status=?, log_text=?, finished_at=NOW() WHERE id=?'
    )->execute([$ok ? 'success' : 'failure', $log, $id]);
    return $id;
  } catch (Throwable $e) {
    return 0;
  }
}

function streamhub_ci_badge(int $repoId): string {
  try {
    $st = db()->prepare('SELECT status FROM streamhub_ci_runs WHERE repo_id=? ORDER BY id DESC LIMIT 1');
    $st->execute([$repoId]);
    $s = (string)($st->fetchColumn() ?: 'unknown');
  } catch (Throwable $e) {
    $s = 'unknown';
  }
  $colors = [
    'success' => '#3fb950',
    'failure' => '#f85149',
    'running' => '#d29922',
    'queued' => '#8b949e',
    'unknown' => '#8b949e',
  ];
  $c = $colors[$s] ?? $colors['unknown'];
  return '<span style="display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:700;background:' . $c . '22;color:' . $c . ';border:1px solid ' . $c . '55">' . htmlspecialchars($s, ENT_QUOTES, 'UTF-8') . '</span>';
}
