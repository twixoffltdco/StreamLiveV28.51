<?php
require_once __DIR__ . '/../config/streamlive_vpn.php';

function slvpn_b64url_encode(string $value): string {
  return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
}
function slvpn_b64url_decode(string $value): ?string {
  $pad = strlen($value) % 4;
  if ($pad) $value .= str_repeat('=', 4 - $pad);
  $raw = base64_decode(strtr($value, '-_', '+/'), true);
  return $raw === false ? null : $raw;
}
function slvpn_signing_secret(): string {
  $secret = get_setting('streamlive_vpn_signing_secret_v2');
  if (!$secret) {
    $secret = bin2hex(random_bytes(32));
    set_setting('streamlive_vpn_signing_secret_v2', $secret);
  }
  return $secret;
}
function slvpn_session_user_id(): int {
  return (int)($_SESSION['user_id'] ?? 0);
}
function slvpn_token_make_official(int $userId, string $sessionId, int $exp): string {
  $payload = [
    'v' => 2,
    'uid' => $userId,
    'sid' => hash('sha256', $sessionId),
    'iat' => time(),
    'exp' => $exp,
    'aud' => 'streamlive-vpn-official',
    'jti' => bin2hex(random_bytes(12)),
  ];
  $body = slvpn_b64url_encode(json_encode($payload, JSON_UNESCAPED_SLASHES));
  $sig = hash_hmac('sha256', $body, slvpn_signing_secret(), true);
  return $body . '.' . slvpn_b64url_encode($sig);
}
function slvpn_verify_official_token(?string $token, ?int $sessionUserId = null): bool {
  if (!$token || !$sessionUserId) return false;
  $parts = explode('.', $token, 2);
  if (count($parts) !== 2) return false;
  [$body, $sig] = $parts;
  $sigRaw = slvpn_b64url_decode($sig);
  $payloadRaw = slvpn_b64url_decode($body);
  if ($sigRaw === null || $payloadRaw === null) return false;
  $expected = hash_hmac('sha256', $body, slvpn_signing_secret(), true);
  if (!hash_equals($expected, $sigRaw)) return false;
  $payload = json_decode($payloadRaw, true);
  if (!is_array($payload)) return false;
  if (($payload['v'] ?? 0) !== 2 || ($payload['aud'] ?? '') !== 'streamlive-vpn-official') return false;
  if ((int)($payload['uid'] ?? 0) !== $sessionUserId) return false;
  if ((int)($payload['exp'] ?? 0) < time()) return false;
  $sidHash = hash('sha256', session_id());
  return hash_equals($sidHash, (string)($payload['sid'] ?? ''));
}
function slvpn_official_authorized_from_request(): bool {
  $uid = slvpn_session_user_id();
  if (!$uid) return false;
  $token = (string)($_SERVER['HTTP_X_STREAMLIVE_VPN_TOKEN'] ?? '');
  return slvpn_verify_official_token($token, $uid);
}
