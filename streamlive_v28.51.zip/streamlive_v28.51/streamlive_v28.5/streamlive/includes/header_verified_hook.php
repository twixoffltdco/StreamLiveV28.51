<?php
if (is_file(__DIR__ . '/verified_moderation.php')) {
  require_once __DIR__ . '/verified_moderation.php';
  if (function_exists('verified_moderation_boot')) {
    verified_moderation_boot();
  }
}
