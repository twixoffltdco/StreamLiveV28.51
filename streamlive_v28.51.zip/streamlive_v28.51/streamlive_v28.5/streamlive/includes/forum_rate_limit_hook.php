<?php
/**
 * Перед созданием темы / ответа на форуме:
 *
 *   require_once __DIR__ . '/verified_moderation.php';
 *   $rl = verified_rate_limit_ok($__user, 'forum_thread'); // или forum_post
 *   if (!$rl['ok']) { flash_set('error', $rl['error']); redirect(...); }
 *
 * И статус:
 *   $mod = verified_mod_status($__user); // pending|approved (admin only approved)
 */
