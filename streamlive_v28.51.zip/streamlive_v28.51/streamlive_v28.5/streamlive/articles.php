<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/content_articles.php';
content_articles_ensure_table();
$list = content_articles_list(null, null, 40);
$pageTitle = 'Статьи';
require_once __DIR__ . '/includes/header.php';
?>
<div class="container">
  <h1>Статьи</h1>
  <p style="color:var(--text-dim);font-size:14px">Материалы авторов каналов и видео — лента в духе Дзена.</p>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px;margin-top:20px">
    <?php foreach ($list as $a): ?>
      <a href="/article.php?id=<?= (int)$a['id'] ?>" style="text-decoration:none;color:inherit;background:var(--card, #1a1f2a);border-radius:14px;overflow:hidden;border:1px solid rgba(255,255,255,.06);display:block">
        <?php if (!empty($a['cover_url'])): ?>
          <img src="<?= e($a['cover_url']) ?>" alt="" style="width:100%;height:140px;object-fit:cover;display:block">
        <?php endif; ?>
        <div style="padding:14px">
          <h3 style="margin:0 0 8px;font-size:16px"><?= e($a['title']) ?></h3>
          <p style="margin:0;font-size:12px;color:var(--text-dim)"><?= e($a['username']) ?> · <?= e(substr($a['created_at'],0,10)) ?></p>
        </div>
      </a>
    <?php endforeach; ?>
    <?php if (!$list): ?>
      <p style="color:var(--text-dim)">Пока пусто.</p>
    <?php endif; ?>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
