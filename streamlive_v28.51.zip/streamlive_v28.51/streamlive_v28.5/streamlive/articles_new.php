<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/articles.php';

$__user = require_login();

$pageTitle = 'Написать статью';
$seoDescription = 'Создать новую статью на StreamLive — как в Dzen.ru';
require_once __DIR__ . '/includes/header.php';

$error = null;
$success = null;

// Получаем каналы пользователя (опционально)
$channels = [];
try {
  $stmt = db()->prepare('SELECT id, title FROM channels WHERE owner_id = ? ORDER BY id DESC');
  $stmt->execute([(int)$__user['id']]);
  $channels = $stmt->fetchAll() ?: [];
} catch (\Throwable $e) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (function_exists("csrf_verify")) { try { csrf_verify(); } catch (Throwable $e) {} }
  
  $title = trim($_POST['title'] ?? '');
  $subtitle = trim($_POST['subtitle'] ?? '');
  $content = trim($_POST['content'] ?? '');
  $coverImage = trim($_POST['cover_image'] ?? '');
  $channelId = !empty($_POST['channel_id']) ? (int)$_POST['channel_id'] : null;
  $status = $_POST['status'] ?? 'published';
  $isPremium = isset($_POST['is_premium']) && $_POST['is_premium'] === '1';
  $premiumPrice = $isPremium ? (float)($_POST['premium_price'] ?? 0) : 0;
  $premiumCurrency = $_POST['premium_currency'] ?? 'RUB';
  
  if ($title === '') {
    $error = 'Введите название статьи';
  } elseif ($content === '') {
    $error = 'Введите текст статьи';
  } else {
    $articleId = articles_create(
      (int)$__user['id'],
      $channelId,
      $title,
      $subtitle,
      $content,
      $coverImage ?: null,
      in_array($status, ['published', 'draft', 'pending'], true) ? $status : 'published',
      $isPremium ? 1 : 0,
      $premiumPrice,
      $premiumCurrency
    );
    
    if ($articleId) {
      $slug = '';
      try {
        $st = db()->prepare('SELECT slug FROM articles WHERE id = ?');
        $st->execute([$articleId]);
        $slug = (string)($st->fetchColumn() ?: '');
      } catch (Throwable $e) {}
      flash_set('success', 'Статья успешно создана!' . ($isPremium ? ' Это платная статья за ' . number_format($premiumPrice, 2) . ' ' . $premiumCurrency : ''));
      if ($status === 'draft') {
        flash_set('success', 'Черновик сохранён — виден только вам');
        redirect('/articles.php');
      }
      if ($slug !== '') redirect('/article.php?slug=' . urlencode($slug));
      redirect('/articles.php');
    } else {
      $error = 'Не удалось создать статью. Попробуйте позже.';
    }
  }
}

// Генерируем slug из заголовка для превью
$slugPreview = '';
if (!empty($_POST['title'])) {
  $slugPreview = articles_make_slug($_POST['title']);
}
?>
<div class="container" style="max-width:800px;padding-top:24px">
  <h1 style="margin-bottom:24px">📝 Написать статью</h1>
  
  <?php if ($error): ?>
    <div class="alert alert-error" style="margin-bottom:20px"><?= e($error) ?></div>
  <?php endif; ?>
  
  <?php if (flash_get('success')): ?>
    <div class="alert alert-success" style="margin-bottom:20px"><?= e(flash_get('success')) ?></div>
  <?php endif; ?>
  
  <form method="post" class="form-card" style="padding:24px">
    <?= csrf_field() ?>
    
    <div style="margin-bottom:20px">
      <label style="display:block;font-weight:600;margin-bottom:8px">Название *</label>
      <input type="text" name="title" id="articleTitle" value="<?= e($_POST['title'] ?? '') ?>" required 
             style="width:100%;padding:12px;border-radius:12px;border:1px solid rgba(255,255,255,0.15);background:rgba(0,0,0,0.3);color:inherit;font-size:16px"
             placeholder="Как в Dzen — цепляющий заголовок"
             oninput="document.getElementById('slugPreview').textContent = this.value ? 'URL: /article.php?slug=' + generateSlug(this.value) : ''">
      <div id="slugPreview" style="font-size:12px;color:var(--text-dim);margin-top:6px"></div>
    </div>
    
    <div style="margin-bottom:20px">
      <label style="display:block;font-weight:600;margin-bottom:8px">Подзаголовок (краткое описание)</label>
      <input type="text" name="subtitle" value="<?= e($_POST['subtitle'] ?? '') ?>" 
             style="width:100%;padding:12px;border-radius:12px;border:1px solid rgba(255,255,255,0.15);background:rgba(0,0,0,0.3);color:inherit;font-size:14px"
             placeholder="Коротко о чём статья (видно в ленте)">
    </div>
    
    <div style="margin-bottom:20px">
      <label style="display:block;font-weight:600;margin-bottom:8px">Обложка (URL картинки)</label>
      <input type="url" name="cover_image" value="<?= e($_POST['cover_image'] ?? '') ?>" 
             style="width:100%;padding:12px;border-radius:12px;border:1px solid rgba(255,255,255,0.15);background:rgba(0,0,0,0.3);color:inherit;font-size:14px"
             placeholder="https://... (скопируйте ссылку на картинку и вставьте)">
      <p style="font-size:12px;color:var(--text-dim);margin-top:6px">💡 Копируйте картинку из интернета и вставляйте ссылку сюда — как в Dzen</p>
    </div>
    
    <div style="margin-bottom:20px">
      <label style="display:block;font-weight:600;margin-bottom:8px">Текст статьи *</label>
      <textarea name="content" rows="15" required 
                style="width:100%;padding:12px;border-radius:12px;border:1px solid rgba(255,255,255,0.15);background:rgba(0,0,0,0.3);color:inherit;font-size:14px;resize:vertical;font-family:monospace"
                placeholder="Пишите текст здесь...&#10;&#10;💡 Копируйте текст с картинками из Dzen или другого источника и вставляйте сюда&#10;Картинки можно копировать и вставлять прямо в текст (Ctrl+V)&#10;&#10;Форматирование поддерживается:&#10;- Заголовки&#10;- Списки&#10;- Выделения&#10;- И т.д."></textarea>
    </div>
    
    <?php if ($channels): ?>
      <div style="margin-bottom:20px">
        <label style="display:block;font-weight:600;margin-bottom:8px">Привязать к каналу (необязательно)</label>
        <select name="channel_id" style="width:100%;padding:12px;border-radius:12px;border:1px solid rgba(255,255,255,0.15);background:rgba(0,0,0,0.3);color:inherit;font-size:14px">
          <option value="">Не привязывать</option>
          <?php foreach ($channels as $ch): ?>
            <option value="<?= (int)$ch['id'] ?>" <?= ((int)($_POST['channel_id'] ?? 0) === (int)$ch['id']) ? 'selected' : '' ?>><?= e($ch['title']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    <?php endif; ?>
    
    <div style="margin-bottom:20px">
      <label style="display:block;font-weight:600;margin-bottom:8px">Статус</label>
      <select name="status" style="width:100%;padding:12px;border-radius:12px;border:1px solid rgba(255,255,255,0.15);background:rgba(0,0,0,0.3);color:inherit;font-size:14px">
        <option value="published" <?= (($_POST['status'] ?? '') === 'published') ? 'selected' : '' ?>>Опубликовано сразу</option>
        <option value="draft" <?= (($_POST['status'] ?? '') === 'draft') ? 'selected' : '' ?>>Черновик</option>
        <option value="pending" <?= (($_POST['status'] ?? '') === 'pending') ? 'selected' : '' ?>>На модерацию</option>
      </select>
    </div>
    
    <div style="margin-bottom:20px;padding:16px;border-radius:12px;background:rgba(167,139,250,0.08);border:1px solid rgba(167,139,250,0.3)">
      <label style="display:flex;align-items:center;gap:10px;font-weight:600;margin-bottom:12px;cursor:pointer">
        <input type="checkbox" name="is_premium" value="1" id="isPremiumCheck" <?= !empty($_POST['is_premium']) ? 'checked' : '' ?> 
               style="width:18px;height:18px;accent-color:#a78bfa"
               onchange="document.getElementById('premiumBlock').style.display = this.checked ? 'block' : 'none'">
        💰 Платная статья (как в Dzen Premium)
      </label>
      <div id="premiumBlock" style="<?= !empty($_POST['is_premium']) ? '' : 'display:none;' ?>">
        <div style="display:flex;gap:12px;margin-top:12px">
          <div style="flex:1">
            <label style="display:block;font-size:12px;color:var(--text-dim);margin-bottom:6px">Цена</label>
            <input type="number" name="premium_price" value="<?= e($_POST['premium_price'] ?? '99') ?>" min="0" step="0.01"
                   style="width:100%;padding:10px;border-radius:8px;border:1px solid rgba(255,255,255,0.15);background:rgba(0,0,0,0.3);color:inherit;font-size:14px"
                   placeholder="99">
          </div>
          <div style="width:120px">
            <label style="display:block;font-size:12px;color:var(--text-dim);margin-bottom:6px">Валюта</label>
            <select name="premium_currency" style="width:100%;padding:10px;border-radius:8px;border:1px solid rgba(255,255,255,0.15);background:rgba(0,0,0,0.3);color:inherit;font-size:14px">
              <option value="RUB" <?= (($_POST['premium_currency'] ?? '') !== 'USD' && ($_POST['premium_currency'] ?? '') !== 'EUR') ? 'selected' : '' ?>>₽ RUB</option>
              <option value="USD" <?= (($_POST['premium_currency'] ?? '') === 'USD') ? 'selected' : '' ?>>$ USD</option>
              <option value="EUR" <?= (($_POST['premium_currency'] ?? '') === 'EUR') ? 'selected' : '' ?>>€ EUR</option>
            </select>
          </div>
        </div>
        <p style="font-size:12px;color:var(--text-dim);margin-top:8px">Читатели смогут купить статью и получить доступ навсегда. Вы получаете 100% дохода.</p>
      </div>
    </div>
    
    <input type="hidden" name="slug_preview" id="slugPreviewInput" value="">
    
    <div style="display:flex;gap:12px;justify-content:flex-end">
      <a href="/articles.php" class="btn btn-outline">Отмена</a>
      <button type="submit" name="status" value="draft" class="btn btn-outline">Сохранить черновик</button>
      <button type="submit" name="status" value="published" class="btn btn-primary">Опубликовать статью</button>
    </div>
  </form>
</div>

<script>
function generateSlug(text) {
  return text.toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, '-')
    .replace(/^-+|-+$/g, '')
    .substring(0, 60) + '-' + Math.random().toString(36).substring(2, 8);
}

// Автогенерация slug при загрузке если есть заголовок
document.addEventListener('DOMContentLoaded', function() {
  var titleInput = document.getElementById('articleTitle');
  if (titleInput && titleInput.value) {
    var slug = generateSlug(titleInput.value);
    document.getElementById('slugPreview').textContent = 'URL: /article.php?slug=' + slug;
    document.getElementById('slugPreviewInput').value = slug;
  }
});
</script>

<style>
.form-card textarea {
  white-space: pre-wrap;
  word-wrap: break-word;
}
</style>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
