<?php
/**
 * Админ-префиксы: не отдаём 500 — ошибка печатается на странице.
 */
http_response_code(200);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

$__err = '';
$__msg = '';
$__rows = [];
$__users = [];
$__layout = false;

try {
  $__root = dirname(__DIR__);
  if (!function_exists('db')) {
    if (!is_file($__root . '/includes/functions.php')) {
      throw new RuntimeException('нет includes/functions.php');
    }
    require_once $__root . '/includes/functions.php';
  }
  if (!function_exists('current_user') && is_file($__root . '/includes/auth.php')) {
    require_once $__root . '/includes/auth.php';
  }

  // доступ
  $__u = function_exists('current_user') ? current_user() : null;
  $role = strtolower((string)($__u['role'] ?? ''));
  $isAdm = $__u && (
    $role === 'admin'
    || !empty($__u['is_admin'])
    || (int)($__u['id'] ?? 0) === 1
  );
  if (!$isAdm) {
    if (function_exists('require_admin')) {
      try {
        require_admin();
        $isAdm = true;
      } catch (Throwable $e) {
        http_response_code(403);
        echo 'Admin only';
        exit;
      }
    }
  }
  if (!$isAdm) {
    http_response_code(403);
    echo 'Admin only';
    exit;
  }

  // soft user_display — только если файл есть, без фатала
  foreach ([
    $__root . '/includes/user_display.php',
    $__root . '/includes/includes/user_display.php',
  ] as $__f) {
    if (is_file($__f)) {
      try {
        require_once $__f;
      } catch (Throwable $e) {
        $__err .= 'user_display: ' . $e->getMessage() . ' ';
      }
      break;
    }
  }

  // schema soft
  try {
    db()->exec(
      "CREATE TABLE IF NOT EXISTS user_prefixes (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(80) NOT NULL,
        css TEXT NULL,
        text_color VARCHAR(32) DEFAULT '#ffffff',
        bg_color VARCHAR(32) DEFAULT '#6366f1',
        color VARCHAR(32) NULL,
        sort_order INT NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        is_system TINYINT(1) NOT NULL DEFAULT 0,
        is_personal TINYINT(1) NOT NULL DEFAULT 0,
        owner_user_id INT UNSIGNED NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
  } catch (Throwable $e) {
  }
  foreach ([
    'ALTER TABLE user_prefixes ADD COLUMN text_color VARCHAR(32) NULL',
    'ALTER TABLE user_prefixes ADD COLUMN bg_color VARCHAR(32) NULL',
    'ALTER TABLE user_prefixes ADD COLUMN css TEXT NULL',
    'ALTER TABLE user_prefixes ADD COLUMN color VARCHAR(32) NULL',
    'ALTER TABLE user_prefixes ADD COLUMN is_active TINYINT(1) DEFAULT 1',
    'ALTER TABLE user_prefixes ADD COLUMN is_system TINYINT(1) DEFAULT 0',
    'ALTER TABLE user_prefixes ADD COLUMN is_personal TINYINT(1) DEFAULT 0',
    'ALTER TABLE user_prefixes ADD COLUMN sort_order INT DEFAULT 0',
    'ALTER TABLE user_prefixes ADD COLUMN owner_user_id INT UNSIGNED NULL',
  ] as $__sql) {
    try {
      db()->exec($__sql);
    } catch (Throwable $e) {
    }
  }

  $pawno = [
    ['Администратор', '#dc2626', '#fff'],
    ['Гл. Администратор', '#991b1b', '#fff'],
    ['Модератор', '#2563eb', '#fff'],
    ['Ст. Модератор', '#1d4ed8', '#fff'],
    ['Хелпер', '#0891b2', '#fff'],
    ['Разработчик', '#7c3aed', '#fff'],
    ['Кодер', '#6d28d9', '#fff'],
    ['Маппер', '#0d9488', '#fff'],
    ['Скриптер', '#4f46e5', '#fff'],
    ['Продавец', '#16a34a', '#fff'],
    ['Покупатель', '#65a30d', '#fff'],
    ['VIP', '#eab308', '#000'],
    ['Premium', '#f59e0b', '#000'],
    ['Sponsor', '#db2777', '#fff'],
    ['Партнёр', '#c026d3', '#fff'],
    ['Верифицирован', '#0ea5e9', '#fff'],
    ['Заблокирован', '#1f2937', '#f87171'],
    ['Предупреждение', '#ea580c', '#fff'],
    ['Новичок', '#64748b', '#fff'],
    ['Активный', '#22c55e', '#fff'],
    ['Легенда', '#f97316', '#fff'],
    ['Тех. поддержка', '#0284c7', '#fff'],
    ['Контент-мейкер', '#a855f7', '#fff'],
    ['Стример', '#e11d48', '#fff'],
  ];

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
      if (function_exists('csrf_verify')) {
        try {
          csrf_verify();
        } catch (Throwable $e) {
        }
      }
      $act = (string)($_POST['action'] ?? '');
      if ($act === 'seed_pawno') {
        $have = [];
        try {
          foreach (db()->query('SELECT title FROM user_prefixes')->fetchAll() ?: [] as $r) {
            $have[strtolower(trim((string)$r['title']))] = true;
          }
        } catch (Throwable $e) {
        }
        $n = 0;
        $sort = 0;
        foreach ($pawno as $it) {
          $key = strtolower($it[0]);
          if (isset($have[$key])) {
            $sort += 10;
            continue;
          }
          $css = 'background:' . $it[1] . ';color:' . $it[2] . ';border-radius:4px;padding:2px 6px;font-weight:700;font-size:11px;display:inline-block';
          try {
            db()->prepare(
              'INSERT INTO user_prefixes (title,css,text_color,bg_color,color,sort_order,is_active,is_system,is_personal) VALUES (?,?,?,?,?,?,1,1,0)'
            )->execute([$it[0], $css, $it[2], $it[1], $it[1], $sort]);
            $n++;
          } catch (Throwable $e) {
            try {
              db()->prepare('INSERT INTO user_prefixes (title,color,is_active) VALUES (?,?,1)')->execute([$it[0], $it[1]]);
              $n++;
            } catch (Throwable $e2) {
            }
          }
          $sort += 10;
        }
        $__msg = 'Pawno добавлено: ' . $n;
      } elseif ($act === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $title = trim((string)($_POST['title'] ?? ''));
        $bg = trim((string)($_POST['bg_color'] ?? '#6366f1'));
        $tc = trim((string)($_POST['text_color'] ?? '#ffffff'));
        $css = trim((string)($_POST['css'] ?? ''));
        if ($title === '') {
          throw new RuntimeException('Пустое название');
        }
        if ($css === '') {
          $css = 'background:' . $bg . ';color:' . $tc . ';border-radius:4px;padding:2px 6px;font-weight:700;font-size:11px;display:inline-block';
        }
        if ($id > 0) {
          try {
            db()->prepare('UPDATE user_prefixes SET title=?,css=?,text_color=?,bg_color=?,color=?,is_active=1 WHERE id=?')
              ->execute([$title, $css, $tc, $bg, $bg, $id]);
          } catch (Throwable $e) {
            db()->prepare('UPDATE user_prefixes SET title=?,color=? WHERE id=?')->execute([$title, $bg, $id]);
          }
        } else {
          try {
            db()->prepare(
              'INSERT INTO user_prefixes (title,css,text_color,bg_color,color,is_active,is_system,is_personal,sort_order) VALUES (?,?,?,?,?,1,0,0,0)'
            )->execute([$title, $css, $tc, $bg, $bg]);
          } catch (Throwable $e) {
            db()->prepare('INSERT INTO user_prefixes (title,color,is_active) VALUES (?,?,1)')->execute([$title, $bg]);
          }
        }
        $__msg = 'Сохранено';
      } elseif ($act === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        try {
          db()->prepare('DELETE FROM user_prefix_map WHERE prefix_id=?')->execute([$id]);
        } catch (Throwable $e) {
        }
        try {
          db()->prepare('UPDATE users SET prefix_id=NULL WHERE prefix_id=?')->execute([$id]);
        } catch (Throwable $e) {
        }
        db()->prepare('DELETE FROM user_prefixes WHERE id=?')->execute([$id]);
        $__msg = 'Удалено';
      } elseif ($act === 'assign') {
        $uid = (int)($_POST['user_id'] ?? 0);
        $pids = [];
        if (!empty($_POST['prefix_ids']) && is_array($_POST['prefix_ids'])) {
          foreach ($_POST['prefix_ids'] as $p) {
            $p = (int)$p;
            if ($p > 0) {
              $pids[] = $p;
            }
          }
        }
        $pids = array_slice(array_values(array_unique($pids)), 0, 3);
        if ($uid <= 0) {
          throw new RuntimeException('user_id');
        }
        if (function_exists('user_set_prefixes')) {
          user_set_prefixes($uid, $pids);
        } else {
          db()->prepare('UPDATE users SET prefix_id=? WHERE id=?')->execute([$pids[0] ?? null, $uid]);
          try {
            db()->exec(
              "CREATE TABLE IF NOT EXISTS user_prefix_map (
                user_id INT UNSIGNED NOT NULL,
                prefix_id INT UNSIGNED NOT NULL,
                sort_order INT NOT NULL DEFAULT 0,
                PRIMARY KEY (user_id, prefix_id)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
            db()->prepare('DELETE FROM user_prefix_map WHERE user_id=?')->execute([$uid]);
            foreach ($pids as $i => $pid) {
              db()->prepare('INSERT INTO user_prefix_map (user_id,prefix_id,sort_order) VALUES (?,?,?)')
                ->execute([$uid, $pid, $i]);
            }
          } catch (Throwable $e) {
          }
        }
        $__msg = 'Выдано #' . $uid;
      }
    } catch (Throwable $e) {
      $__err .= $e->getMessage();
    }
  }

  // список — ВСЕ строки
  try {
    $__rows = db()->query('SELECT * FROM user_prefixes ORDER BY id ASC')->fetchAll() ?: [];
  } catch (Throwable $e) {
    $__err .= ' SELECT: ' . $e->getMessage();
    $__rows = [];
  }

  // авто-seed если пусто
  if (!$__rows) {
    $n = 0;
    $sort = 0;
    foreach ($pawno as $it) {
      $css = 'background:' . $it[1] . ';color:' . $it[2] . ';border-radius:4px;padding:2px 6px;font-weight:700;font-size:11px;display:inline-block';
      try {
        db()->prepare(
          'INSERT INTO user_prefixes (title,css,text_color,bg_color,color,sort_order,is_active,is_system,is_personal) VALUES (?,?,?,?,?,?,1,1,0)'
        )->execute([$it[0], $css, $it[2], $it[1], $it[1], $sort]);
        $n++;
      } catch (Throwable $e) {
      }
      $sort += 10;
    }
    try {
      $__rows = db()->query('SELECT * FROM user_prefixes ORDER BY id ASC')->fetchAll() ?: [];
    } catch (Throwable $e) {
    }
    if ($n > 0) {
      $__msg = 'Авто-seed Pawno: +' . $n;
    }
  }

  try {
    $__users = db()->query('SELECT id, username FROM users ORDER BY id DESC LIMIT 200')->fetchAll() ?: [];
  } catch (Throwable $e) {
  }

  // layout optional
  if (is_file(__DIR__ . '/_layout_start.php')) {
    try {
      ob_start();
      include __DIR__ . '/_layout_start.php';
      $__layoutHead = ob_get_clean();
      $__layout = true;
      echo $__layoutHead;
    } catch (Throwable $e) {
      $__layout = false;
      $__err .= ' layout: ' . $e->getMessage();
    }
  }
} catch (Throwable $e) {
  $__err .= $e->getMessage();
}

if (!$__layout) {
  if (!headers_sent()) {
    header('Content-Type: text/html; charset=utf-8');
  }
  echo '<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
  echo '<title>Префиксы</title>';
  echo '<style>body{font-family:system-ui,sans-serif;background:#0f0f12;color:#e5e7eb;margin:16px;line-height:1.45}';
  echo 'a{color:#93c5fd}table{border-collapse:collapse;width:100%;margin-top:12px}td,th{border:1px solid #333;padding:8px;text-align:left}';
  echo 'button,.btn{padding:8px 12px;border:0;border-radius:8px;background:#2563eb;color:#fff;cursor:pointer;margin:2px}';
  echo 'input,select,textarea{background:#1e293b;color:#fff;border:1px solid #334155;padding:6px;border-radius:6px}';
  echo '.ok{color:#4ade80}.err{color:#f87171;white-space:pre-wrap}</style></head><body>';
  echo '<p><a href="/admin/index.php">← Админка</a></p>';
}

$pfx = static function ($r) {
  $t = htmlspecialchars((string)($r['title'] ?? ''), ENT_QUOTES, 'UTF-8');
  if (function_exists('user_render_prefix_html')) {
    try {
      $h = user_render_prefix_html($r);
      if ($h !== '') {
        return $h;
      }
    } catch (Throwable $e) {
    }
  }
  $bg = htmlspecialchars((string)($r['bg_color'] ?? $r['color'] ?? '#6366f1'), ENT_QUOTES, 'UTF-8');
  $tc = htmlspecialchars((string)($r['text_color'] ?? '#ffffff'), ENT_QUOTES, 'UTF-8');
  $css = trim((string)($r['css'] ?? ''));
  if ($css !== '') {
    $css = preg_replace('/[<>]/', '', $css);
    return '<span style="' . htmlspecialchars($css, ENT_QUOTES, 'UTF-8') . '">' . $t . '</span>';
  }
  return '<span style="display:inline-block;padding:2px 7px;border-radius:6px;font-size:11px;font-weight:700;background:'
    . $bg . ';color:' . $tc . '">' . $t . '</span>';
};
?>
<h1>Префиксы</h1>
<?php if ($__err !== ''): ?><p class="err">Ошибка (страница жива): <?= htmlspecialchars($__err, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
<?php if ($__msg !== ''): ?><p class="ok"><?= htmlspecialchars($__msg, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
<p>Всего в БД: <b><?= count($__rows) ?></b></p>

<form method="post" style="margin:10px 0">
  <?= function_exists('csrf_field') ? csrf_field() : '' ?>
  <button type="submit" name="action" value="seed_pawno">Добавить недостающие Pawno Help</button>
</form>

<form method="post" style="border:1px solid #333;border-radius:12px;padding:12px;margin:12px 0;max-width:520px">
  <?= function_exists('csrf_field') ? csrf_field() : '' ?>
  <input type="hidden" name="action" value="save">
  <input type="hidden" name="id" value="0">
  <p>Новый префикс<br><input name="title" required placeholder="Название" style="width:100%"></p>
  <p>Фон <input type="color" name="bg_color" value="#6366f1"> Текст <input type="color" name="text_color" value="#ffffff"></p>
  <p>CSS<br><textarea name="css" rows="2" style="width:100%"></textarea></p>
  <button type="submit">Создать</button>
</form>

<table>
  <tr><th>ID</th><th>Превью</th><th>Название</th><th></th></tr>
  <?php foreach ($__rows as $r): ?>
    <tr>
      <td><?= (int)$r['id'] ?></td>
      <td><?= $pfx($r) ?></td>
      <td><?= htmlspecialchars((string)($r['title'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
      <td>
        <form method="post" style="display:inline" onsubmit="return confirm('Удалить?')">
          <?= function_exists('csrf_field') ? csrf_field() : '' ?>
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
          <button type="submit">удал</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$__rows): ?>
    <tr><td colspan="4">Пусто</td></tr>
  <?php endif; ?>
</table>

<form method="post" style="border:1px solid #333;border-radius:12px;padding:12px;margin:20px 0;max-width:520px">
  <?= function_exists('csrf_field') ? csrf_field() : '' ?>
  <input type="hidden" name="action" value="assign">
  <h3>Выдать (до 3)</h3>
  <p>User
    <select name="user_id" required>
      <option value="">—</option>
      <?php foreach ($__users as $u): ?>
        <option value="<?= (int)$u['id'] ?>">#<?= (int)$u['id'] ?> @<?= htmlspecialchars((string)$u['username'], ENT_QUOTES, 'UTF-8') ?></option>
      <?php endforeach; ?>
    </select>
  </p>
  <?php for ($i = 0; $i < 3; $i++): ?>
    <p>Префикс <?= $i + 1 ?>
      <select name="prefix_ids[]">
        <option value="0">—</option>
        <?php foreach ($__rows as $r): ?>
          <option value="<?= (int)$r['id'] ?>"><?= htmlspecialchars((string)$r['title'], ENT_QUOTES, 'UTF-8') ?></option>
        <?php endforeach; ?>
      </select>
    </p>
  <?php endfor; ?>
  <button type="submit">Назначить</button>
</form>
<?php
if ($__layout && is_file(__DIR__ . '/_layout_end.php')) {
  try {
    include __DIR__ . '/_layout_end.php';
  } catch (Throwable $e) {
    echo '</body></html>';
  }
} else {
  echo '</body></html>';
}
