<?php
echo '</div></div>'; // admin-content + admin-shell
$__root = dirname(__DIR__);
try {
  if (is_file($__root . '/includes/footer.php')) {
    require $__root . '/includes/footer.php';
  } else {
    echo '</body></html>';
  }
} catch (Throwable $e) {
  echo '</body></html>';
}
