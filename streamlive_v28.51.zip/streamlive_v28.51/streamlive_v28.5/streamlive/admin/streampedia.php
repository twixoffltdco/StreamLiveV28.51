<?php
/**
 * Модерация вики-проектов и правок StreamPedia (панель модератора платформы).
 */
require_once __DIR__ . '/_layout_start.php';
require_once dirname(__DIR__) . '/includes/streampedia.php';
streampedia_ensure();

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (function_exists('csrf_verify')) { try { csrf_verify(); } catch (Throwable $e) {} }
  $type = $_POST['type'] ?? '';
  $id = (int)($_POST['id'] ?? 0);
  $act = $_POST['action'] ?? '';
  if ($type === 'wiki' && $id > 0) {
    if ($act === 'approve') {
      db()->prepare("UPDATE streampedia_wikis SET mod_status='approved', is_deleted=0 WHERE id=?")->execute([$id]);
      $msg = "Вики #$id одобрен";
    } elseif ($act === 'reject') {
      db()->prepare("UPDATE streampedia_wikis SET mod_status='rejected' WHERE id=?")->execute([$id]);
      $msg = "Вики #$id отклонён";
    } elseif ($act === 'delete') {
      db()->prepare("UPDATE streampedia_wikis SET is_deleted=1, mod_status='rejected' WHERE id=?")->execute([$id]);
      $msg = "Вики #$id скрыт";
    }
  }
  if ($type === 'page' && $id > 0) {
    if ($act === 'approve') {
      db()->prepare("UPDATE streampedia_pages SET mod_status='approved', is_deleted=0 WHERE id=?")->execute([$id]);
      $msg = "Страница #$id одобрена";
    } elseif ($act === 'reject') {
      db()->prepare("UPDATE streampedia_pages SET mod_status='rejected' WHERE id=?")->execute([$id]);
      $msg = "Страница #$id отклонена";
    }
  }
  if ($type === 'rev' && $id > 0) {
    $st = db()->prepare('SELECT * FROM streampedia_revisions WHERE id=?');
    $st->execute([$id]);
    $rev = $st->fetch();
    if ($rev && $act === 'approve') {
      db()->prepare("UPDATE streampedia_revisions SET mod_status='approved' WHERE id=?")->execute([$id]);
      db()->prepare("UPDATE streampedia_pages SET title=?, content=?, mod_status='approved', updated_at=NOW() WHERE id=?")
        ->execute([$rev['title'], $rev['content'], (int)$rev['page_id']]);
      $msg = "Правка #$id применена";
    } elseif ($rev && $act === 'reject') {
      db()->prepare("UPDATE streampedia_revisions SET mod_status='rejected' WHERE id=?")->execute([$id]);
      $msg = "Правка #$id отклонена";
    }
  }
}

$pendingWikis = $pendingPages = $pendingRevs = [];
try {
  $pendingWikis = db()->query(
    "SELECT w.*, u.username FROM streampedia_wikis w LEFT JOIN users u ON u.id=w.owner_id
     WHERE w.mod_status='pending' AND w.is_deleted=0 ORDER BY w.id ASC LIMIT 50"
  )->fetchAll() ?: [];
} catch (Throwable $e) {}
try {
  $pendingPages = db()->query(
    "SELECT p.*, w.slug AS wiki_slug, w.title AS wiki_title, u.username
     FROM streampedia_pages p
     JOIN streampedia_wikis w ON w.id=p.wiki_id
     LEFT JOIN users u ON u.id=p.author_id
     WHERE p.mod_status='pending' AND p.is_deleted=0 ORDER BY p.id ASC LIMIT 50"
  )->fetchAll() ?: [];
} catch (Throwable $e) {}
try {
  $pendingRevs = db()->query(
    "SELECT r.*, p.slug AS page_slug, w.slug AS wiki_slug, u.username
     FROM streampedia_revisions r
     JOIN streampedia_pages p ON p.id=r.page_id
     JOIN streampedia_wikis w ON w.id=p.wiki_id
     LEFT JOIN users u ON u.id=r.editor_id
     WHERE r.mod_status='pending' ORDER BY r.id ASC LIMIT 50"
  )->fetchAll() ?: [];
} catch (Throwable $e) {}
?>
<h1>StreamPedia — модерация</h1>
<?php if ($msg): ?><p style="color:#4ade80"><?= htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>

<h2>Вики-проекты (<?= count($pendingWikis) ?>)</h2>
<?php foreach ($pendingWikis as $w): ?>
  <div class="form-card" style="padding:12px;margin-bottom:8px">
    <b><?= htmlspecialchars($w['title'], ENT_QUOTES, 'UTF-8') ?></b>
    · @<?= htmlspecialchars($w['username'] ?? '?', ENT_QUOTES, 'UTF-8') ?>
    · <code><?= htmlspecialchars($w['slug'], ENT_QUOTES, 'UTF-8') ?></code>
    <div style="font-size:13px;opacity:.7"><?= htmlspecialchars($w['tagline'] ?? '', ENT_QUOTES, 'UTF-8') ?></div>
    <form method="post" style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">
      <?= function_exists('csrf_field') ? csrf_field() : '' ?>
      <input type="hidden" name="type" value="wiki">
      <input type="hidden" name="id" value="<?= (int)$w['id'] ?>">
      <button name="action" value="approve" class="btn btn-primary" type="submit">Одобрить</button>
      <button name="action" value="reject" class="btn btn-outline" type="submit">Отклонить</button>
      <a class="btn btn-outline" href="/streampedia/wiki.php?slug=<?= urlencode($w['slug']) ?>" target="_blank">Открыть</a>
    </form>
  </div>
<?php endforeach; ?>
<?php if (!$pendingWikis): ?><p style="opacity:.6">Нет вики на модерации</p><?php endif; ?>

<h2 style="margin-top:24px">Новые страницы (<?= count($pendingPages) ?>)</h2>
<?php foreach ($pendingPages as $p): ?>
  <div class="form-card" style="padding:12px;margin-bottom:8px">
    <b><?= htmlspecialchars($p['title'], ENT_QUOTES, 'UTF-8') ?></b>
    · вики «<?= htmlspecialchars($p['wiki_title'], ENT_QUOTES, 'UTF-8') ?>»
    · @<?= htmlspecialchars($p['username'] ?? '', ENT_QUOTES, 'UTF-8') ?>
    <form method="post" style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">
      <?= function_exists('csrf_field') ? csrf_field() : '' ?>
      <input type="hidden" name="type" value="page">
      <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
      <button name="action" value="approve" class="btn btn-primary" type="submit">Одобрить</button>
      <button name="action" value="reject" class="btn btn-outline" type="submit">Отклонить</button>
      <a class="btn btn-outline" href="/streampedia/page.php?wiki=<?= urlencode($p['wiki_slug']) ?>&page=<?= urlencode($p['slug']) ?>" target="_blank">Открыть</a>
    </form>
  </div>
<?php endforeach; ?>
<?php if (!$pendingPages): ?><p style="opacity:.6">Нет страниц</p><?php endif; ?>

<h2 style="margin-top:24px">Правки (<?= count($pendingRevs) ?>)</h2>
<?php foreach ($pendingRevs as $r): ?>
  <div class="form-card" style="padding:12px;margin-bottom:8px">
    <b><?= htmlspecialchars($r['title'], ENT_QUOTES, 'UTF-8') ?></b>
    · @<?= htmlspecialchars($r['username'] ?? '', ENT_QUOTES, 'UTF-8') ?>
    · <?= htmlspecialchars($r['summary'] ?? '', ENT_QUOTES, 'UTF-8') ?>
    <form method="post" style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">
      <?= function_exists('csrf_field') ? csrf_field() : '' ?>
      <input type="hidden" name="type" value="rev">
      <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
      <button name="action" value="approve" class="btn btn-primary" type="submit">Применить</button>
      <button name="action" value="reject" class="btn btn-outline" type="submit">Отклонить</button>
    </form>
  </div>
<?php endforeach; ?>
<?php if (!$pendingRevs): ?><p style="opacity:.6">Нет правок</p><?php endif; ?>

<?php require_once __DIR__ . '/_layout_end.php'; ?>
