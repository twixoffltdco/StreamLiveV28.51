<?php
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';
$u = current_user();
if (!$u || (($u['role'] ?? '') !== 'admin' && empty($u['is_admin']))) {
  http_response_code(403);
  exit('admin');
}
if (is_file(dirname(__DIR__) . '/includes/dynamic_price.php')) {
  require_once dirname(__DIR__) . '/includes/dynamic_price.php';
}

$keys = [
  'enabled' => '1',
  'views_step' => '1000',
  'views_pct' => '5',
  'likes_step' => '100',
  'likes_pct' => '3',
  'subs_step' => '50',
  'subs_pct' => '4',
  'max_multiplier' => '3',
  'min_multiplier' => '1',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  foreach ($keys as $k => $def) {
    $v = $_POST[$k] ?? $def;
    try {
      db()->prepare("INSERT INTO options (k, v) VALUES (?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)")
        ->execute(['dyn_price_' . $k, (string)$v]);
    } catch (Throwable $e) {
      try {
        db()->prepare("REPLACE INTO settings (name, value) VALUES (?,?)")
          ->execute(['dyn_price_' . $k, (string)$v]);
      } catch (Throwable $e2) {}
    }
  }
  header('Location: /admin/dyn_price.php?ok=1');
  exit;
}

$cur = function_exists('dyn_price_settings') ? dyn_price_settings() : $keys;
$pageTitle = 'Динамическая цена';
require dirname(__DIR__) . '/includes/header.php';
?>
<div class="container" style="max-width:640px;margin:24px auto">
  <h1>Динамическая цена</h1>
  <p>Базовая цена автора × рост от просмотров / лайков / подписчиков.</p>
  <?php if (!empty($_GET['ok'])): ?><p style="color:#86efac">Сохранено</p><?php endif; ?>
  <form method="post" style="display:grid;gap:10px">
    <label>Включено <input type="number" name="enabled" value="<?= (int)$cur['enabled'] ?>" min="0" max="1"></label>
    <label>Каждые N просмотров <input type="number" name="views_step" value="<?= (int)$cur['views_step'] ?>"></label>
    <label>+% за шаг просмотров <input type="number" step="0.1" name="views_pct" value="<?= htmlspecialchars((string)$cur['views_pct']) ?>"></label>
    <label>Каждые N лайков <input type="number" name="likes_step" value="<?= (int)$cur['likes_step'] ?>"></label>
    <label>+% за шаг лайков <input type="number" step="0.1" name="likes_pct" value="<?= htmlspecialchars((string)$cur['likes_pct']) ?>"></label>
    <label>Каждые N подписчиков (каналы) <input type="number" name="subs_step" value="<?= (int)$cur['subs_step'] ?>"></label>
    <label>+% за шаг подписчиков <input type="number" step="0.1" name="subs_pct" value="<?= htmlspecialchars((string)$cur['subs_pct']) ?>"></label>
    <label>Мин. множитель <input type="number" step="0.1" name="min_multiplier" value="<?= htmlspecialchars((string)$cur['min_multiplier']) ?>"></label>
    <label>Макс. множитель <input type="number" step="0.1" name="max_multiplier" value="<?= htmlspecialchars((string)$cur['max_multiplier']) ?>"></label>
    <button type="submit">Сохранить</button>
  </form>
  <p style="opacity:.7;margin-top:16px">Пример: база 100 ₽, 3000 просмотров, step 1000, +5% → ×1.15 → <b>115 ₽</b></p>
</div>
<?php require dirname(__DIR__) . '/includes/footer.php'; ?>
