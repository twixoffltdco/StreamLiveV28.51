<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
if (is_file(__DIR__ . '/includes/content_articles.php')) {
  require_once __DIR__ . '/includes/content_articles.php';
}
content_articles_ensure_table();
$id = (int)($_GET['id'] ?? 0);
$st = db()->prepare(
  "SELECT a.*, u.username FROM content_articles a
   JOIN users u ON u.id = a.user_id WHERE a.id = ? LIMIT 1"
);
$st->execute([$id]);
$a = $st->fetch();
if (!$a || ($a['status'] !== 'published' && (empty(current_user()) || (int)current_user()['id'] !== (int)$a['user_id']))) {
  http_response_code(404);
  require_once __DIR__ . '/includes/header.php';
  echo '<div class="container"><p>Статья не найдена</p></div>';
  require_once __DIR__ . '/includes/footer.php';
  exit;
}
try {
  if (is_file(__DIR__ . '/includes/content_views.php')) require_once __DIR__ . '/includes/content_views.php';
if (function_exists('content_view_register')) {
  content_view_register('article', (int)$id);
} else {
  try { db()->prepare('UPDATE content_articles SET views = COALESCE(views,0) + 1 WHERE id = ?')->execute([$id]); } catch (Throwable $e) {}
}
} catch (Throwable $e) {}
$pageTitle = $a['title'];
require_once __DIR__ . '/includes/header.php';
?>
<div class="container" style="max-width:720px">
  <?php if (!empty($a['cover_url'])): ?>
    <img src="<?= e($a['cover_url']) ?>" alt="" style="width:100%;border-radius:14px;margin-bottom:16px;max-height:360px;object-fit:cover">
  <?php endif; ?>
  <h1><?= e($a['title']) ?></h1>
  <p style="color:var(--text-dim);font-size:13px"><?= e($a['username']) ?> · <?= e(substr($a['created_at'], 0, 16)) ?> · <?= (int)$a['views'] ?> просм.</p>
  <div style="line-height:1.7;margin-top:20px;white-space:pre-wrap"><?= e($a['body']) ?></div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
