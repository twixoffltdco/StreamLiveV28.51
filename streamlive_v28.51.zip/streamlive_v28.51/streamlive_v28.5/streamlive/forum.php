<?php
/**
 * Форум — устойчивый к 500/пустым категориям. Не отдаёт 403 сам.
 */
if (session_status() === PHP_SESSION_NONE) {
  @session_start();
}

try {
  require_once __DIR__ . '/includes/functions.php';
} catch (Throwable $e) {
  http_response_code(500);
  header('Content-Type: text/html; charset=utf-8');
  echo '<h1>Форум временно недоступен</h1><p>Ошибка подключения ядра. Попробуйте позже.</p>';
  exit;
}

try {
  require_once __DIR__ . '/includes/auth.php';
} catch (Throwable $e) {}

$__user = function_exists('current_user') ? current_user() : null;
$pageTitle = 'Форум';

$categories = [];
$dbError = null;
try {
  if (function_exists('db')) {
    $categories = db()->query(
      "SELECT fc.*,
         (SELECT COUNT(*) FROM forum_threads t WHERE t.category_id = fc.id AND t.is_deleted = 0) AS thread_count,
         (SELECT COUNT(*) FROM forum_posts p JOIN forum_threads t ON t.id = p.thread_id
           WHERE t.category_id = fc.id AND t.is_deleted = 0 AND p.is_deleted = 0) AS post_count
       FROM forum_categories fc ORDER BY fc.sort_order ASC, fc.id ASC"
    )->fetchAll() ?: [];

    foreach ($categories as &$cat) {
      try {
        $stmt = db()->prepare(
          "SELECT t.id, t.title, t.last_post_at, u.username FROM forum_threads t
           JOIN users u ON u.id = t.user_id
           WHERE t.category_id = ? AND t.is_deleted = 0 ORDER BY t.last_post_at DESC LIMIT 1"
        );
        $stmt->execute([(int)$cat['id']]);
        $cat['last_thread'] = $stmt->fetch() ?: null;
      } catch (Throwable $e) {
        $cat['last_thread'] = null;
      }
    }
    unset($cat);
  }
} catch (Throwable $e) {
  $dbError = $e->getMessage();
  // fallback без подсчётов
  try {
    $categories = db()->query('SELECT * FROM forum_categories ORDER BY sort_order ASC, id ASC')->fetchAll() ?: [];
    foreach ($categories as &$cat) {
      $cat['thread_count'] = 0;
      $cat['post_count'] = 0;
      $cat['last_thread'] = null;
    }
    unset($cat);
  } catch (Throwable $e2) {
    $categories = [];
  }
}

try {
  require_once __DIR__ . '/includes/header.php';
} catch (Throwable $e) {
  header('Content-Type: text/html; charset=utf-8');
  echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Форум</title></head><body>';
}

$e = static function ($s) {
  return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
};
$site = defined('SITE_URL') ? SITE_URL : '';
?>
<div class="container">
  <div style="display:flex;align-items:center;justify-content:space-between;margin:24px 0 6px;flex-wrap:wrap;gap:10px">
    <h1 style="margin:0">Форум</h1>
    <div style="display:flex;gap:8px">
      <?php if ($site): ?>
        <button type="button" class="btn btn-outline btn-sm" onclick="navigator.clipboard&&navigator.clipboard.writeText('<?= $e($site) ?>/rss_forum.php')">📋 RSS</button>
      <?php endif; ?>
      <?php if ($__user && (($__user['role'] ?? '') === 'admin')): ?>
        <a href="/admin/forum.php" class="btn btn-outline btn-sm">Управление категориями</a>
      <?php endif; ?>
    </div>
  </div>
  <p style="color:var(--text-dim);font-size:13px;margin-bottom:20px">Обсуждения, BBCode, темы и ответы.</p>

  <?php if ($dbError && empty($categories)): ?>
    <div class="empty-state">
      <h2>Форум временно недоступен</h2>
      <p>Не удалось загрузить категории. Обновите страницу через минуту.</p>
    </div>
  <?php endif; ?>

  <div class="forum-cat-list">
    <?php foreach ($categories as $cat): ?>
      <div class="forum-cat-card">
        <div class="forum-cat-main">
          <a href="/forum_category.php?id=<?= (int)$cat['id'] ?>" class="forum-cat-title"><?= $e($cat['title'] ?? '') ?></a>
          <?php if (!empty($cat['description'])): ?><p class="forum-cat-desc"><?= $e($cat['description']) ?></p><?php endif; ?>
        </div>
        <div class="forum-cat-stats">
          <div><b><?= (int)($cat['thread_count'] ?? 0) ?></b><span>тем</span></div>
          <div><b><?= (int)($cat['post_count'] ?? 0) ?></b><span>сообщений</span></div>
        </div>
        <div class="forum-cat-last">
          <?php if (!empty($cat['last_thread'])): ?>
            <a href="/forum_thread.php?id=<?= (int)$cat['last_thread']['id'] ?>"><?= $e($cat['last_thread']['title']) ?></a>
            <span style="color:var(--text-dim)">от <?= $e($cat['last_thread']['username']) ?> · <?= $e($cat['last_thread']['last_post_at']) ?></span>
          <?php else: ?>
            <span style="color:var(--text-dim)">Пока нет тем</span>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
    <?php if (empty($categories) && !$dbError): ?>
      <div class="empty-state"><h2>Категорий пока нет</h2><p>Администратор ещё не создал категории форума.</p></div>
    <?php endif; ?>
  </div>
</div>
<?php
try {
  require_once __DIR__ . '/includes/footer.php';
} catch (Throwable $e) {
  echo '</body></html>';
}
