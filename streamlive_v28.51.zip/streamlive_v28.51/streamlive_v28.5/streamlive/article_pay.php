<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
if (is_file(__DIR__ . '/includes/wallet.php')) require_once __DIR__ . '/includes/wallet.php';
if (is_file(__DIR__ . '/includes/wallet_pay.php')) require_once __DIR__ . '/includes/wallet_pay.php';

$user = current_user();
if (!$user) {
  header('Location: /auth/login.php?next=' . urlencode('/article.php?id=' . (int)($_POST['article_id'] ?? 0)));
  exit;
}
$aid = (int)($_POST['article_id'] ?? $_GET['article_id'] ?? 0);
$r = wallet_pay_for_article((int)$user['id'], $aid);
$slug = '';
try {
  $st = db()->prepare('SELECT slug FROM articles WHERE id=?');
  $st->execute([$aid]);
  $slug = (string)($st->fetchColumn() ?: '');
} catch (Throwable $e) {}
$q = $r['ok'] ? 'paid=1' : ('pay_err=' . urlencode($r['error'] ?? 'error'));
header('Location: /article.php?' . ($slug ? 'slug=' . urlencode($slug) . '&' : 'id=' . $aid . '&') . $q);
exit;
